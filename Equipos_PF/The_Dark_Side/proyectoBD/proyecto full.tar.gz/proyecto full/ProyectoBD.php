
<html>
<head>
<title>Proyecto HTML </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
body,td,th {
	font-size: x-small;
	font-weight: bold;
	text-align: center;
	font-family: "Comic Sans MS", cursive;
	color: #FF0;
}
.B {
	font-family: Georgia, Times New Roman, Times, serif;
	font-size: 75px;
	color: #09F;
}
.a {
	font-size: medium;
}
.xx {
	font-family: Trebuchet MS, Arial, Helvetica, sans-serif;
	font-size: small;
}
.kjhgvbnji {
	color: #F00;
}
</style>
</head>
<center>
<center>

<body bgcolor="black" text="white" link="#003399" vlink="#FF9999" alink="#FFFF33" tracingsrc="fondos/10704299_321409068032653_2614215882419722678_o.jpg" tracingopacity="100">
<h1><span class="B">Bienvenidos: Servicio de Papeleria </span></h1>
<p>&nbsp;</p> 
        <br>
</li>



<form action="validar_usuario.php" method="post">
Usuario:<input type="text" name="usuario" size="20" maxlength="20" />
<br />
Password:<input type="password" name="password" size="10" maxlength="10" />
<br />
<input type="submit" value="Ingresar" />
</form>

</form>

</div>
</body>
</html>
