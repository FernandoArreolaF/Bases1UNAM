<html>
<head>
<title>Proyecto HTML </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
body,td,th {
	font-size: large;
	font-weight: bold;
	text-align: center;
	font-family: "Comic Sans MS", cursive;
	color: #FF0;
}
.B {
	font-family: Georgia, Times New Roman, Times, serif;
	font-size: 75px;
	color: #09F;
}
.a {
	font-size: medium;
}
.xx {
	font-family: Trebuchet MS, Arial, Helvetica, sans-serif;
	font-size: small;
}
.kjhgvbnji {
	color: #F00;
}
</style>
</head>
<center>
<center>

<body bgcolor="black" background="file:///C|/Users/ratot/Downloads/fondos/10704299_321409068032653_2614215882419722678_o.jpg" text="white" link="#003399" vlink="#FF9999" alink="#FFFF33" tracingsrc="fondos/10704299_321409068032653_2614215882419722678_o.jpg" tracingopacity="100">

<?php
echo 'BIENVENIDO, QUE VA A REALIZAR?';
 echo '<p><a href="cliente.php">cliente</a></p>';
 echo '<p><a href="producto.php">producto</a></p>'; 
 echo '<p><a href="ventas.php">ventas</a></p>';
 echo '<p><a href="logout.php"\n\n\n>salir</a></p>';

?>
