<html>
<head>
<title>Proyecto HTML </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
body,td,th {
	font-size: large;
	font-weight: bold;
	text-align: left;
}
.asas {
	font-size: xx-large;
}
.asas u em {
	text-align: center;
	color: #0F0;
}
.qwq {
	text-align: center;
}
.required_notification {
	color: #FF0;
}
</style>
</head>
<center>
<center>

<body bgcolor="black" background="fondos/10704299_321409068032653_2614215882419722678_o.jpg" text="white" link="#003399" vlink="#FF9999" alink="#FFFF33">
<br>
<strong class="asas"><u><em>Usuario</em></u></strong><br>
<br><!DOCTYPE html> <html xmlns="http://www.w3.org/1999/xhtml"> <head runat="server"> 

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<li><span class="required_notification"><span class="required_notification">&quot; Ingresa datos del Usuario</span></span> <span class="required_notification">&quot;</span></li>
<p>&nbsp;</p>
<li>Nombre
  <input name="checkbox3" type="text" id="checkbox" lang="es" maxlength="30">
    <label for="checkbox"></label>
</li>
<li>Password
  <input name="checkbox" type="password" id="checkbox2" lang="es">
</li>
<li> Confirmar Password
  <input name="checkbox5" type="password" id="checkbox5" lang="es">
</li>
<li>Supervisor
  <input name="checkbox2" type="radio" id="checkbox3" lang="es" value="">
</li>
<li>Vendedor
  <input name="checkbox4" type="radio" id="checkbox4" lang="es" value="">
  <br>
</li>
<body>
<form name="form1" method="post" action="">
  <label class="qwq">
    <input name="" type="submit" id="Aceptar" lang="es" value="Aceptar">
  </label>
</form>
<ul>
  <li><a href="P2.html">Regresar</a></li>
</ul>
<p>&nbsp;</p>
</body>
</html>
