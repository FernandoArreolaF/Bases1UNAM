<?php
$conectar = @mysql_connect('localhost','root','');
//Verificando conexion 
if(!$conectar){
	echo "No se pudo conectar con el servido";
}else{
	$base=mysql_select_db('prueba');
	if(*$base){
		echo"No se enocntro la base de datos";
	}
}
$nombre=$_POST['nom_cliente'];
//$correo=$_POST['correo'];
//$mensaje=$_POST['mensaje'];
$sql="INSERT INTO cliente VALUES('$nom_cliente')";
//ejecutamos sentencia
$ejecutar=mysql_query($sql);
//verificar ejecucion
if(!$ejecutar){
	echo="Hubo un error";
}else{
	echo"Datos guardados correctamente<br><a href='index.html'>Volver</a>"
}
?>