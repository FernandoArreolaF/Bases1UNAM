<?php
	$conexion = pg_connect("host=localhost dbname=PROYECTO user=postgres password=Americano76");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> 
        <title>Formulario De Registro</title>
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>
    <body>


	<div class="contenedor">

		<?php
		$query_cod_barras ="SELECT cod_barras, nom_prod FROM producto ";
		$resultado_cod_barras = pg_query($conexion,$query_cod_barras) or die ("Error en la consulta sql");
		$numReg=pg_num_rows($resultado_cod_barras);
		?>


		<form action="factura.php" class="formulario" id="formulario" name="formulario" method="POST">
			<div class="contenedor-inputs">

				

				<div class="tabla">
			<table>
				<tr>
					<th>Codigo de barras</th>
					<th>Producto</th>
				</tr>
					
					<?php
						$consulta = "SELECT cod_barras, nom_prod FROM producto";
						$ejecutarConsulta = pg_query($conexion, $consulta);
						$verFilas = pg_num_rows($ejecutarConsulta);
						$fila = pg_fetch_array($ejecutarConsulta);

						if(!$ejecutarConsulta){
							echo"Error en la consulta";
						}else{
							if($verFilas<1){
								echo"<tr><td>Sin registros</td></tr>";
							}else{
								for($i=0; $i<=$fila; $i++){
									echo'
										<tr>
											<td>'.$fila[0].'</td>
											<td>'.$fila[1].'</td>
											
										</tr>
									';
									$fila = pg_fetch_array($ejecutarConsulta);

								}

							}
						}


					?>

					<p>Utilidades</p>
				<br>
				<label for="cod_barras">Codigo de barras</label>
				<select name="cod_barras">

					<option value="ninguno">Eliga un producto</option>
					<option selected></option>
					<?php 
					if(isset($_POST['registrarse'])){
					$cod_barras=$_POST['cod_barras'];


					}


					
	



					while ($filaart=pg_fetch_array($resultado_cod_barras)) {
					echo "<option value".$filaart['nom_prod'].">".$filaart['cod_barras']."</option>";
					}
					?>
						
						
				
				
			</table>
		</div>


				<input type="submit" href="paginas/form.html" class="btn" name="registrarse" value="Ver utilidad">
			

			
			<br>
			<br>
			
		</form>
		
	</div>
	<script src="formulario.js"></script>
</body>
</html>

