<?php
$conexion = pg_connect("host=localhost dbname=PROYECTO user=postgres password=Americano76");
$cod_barras = $_POST['cod_barras'];

$insertarDatos9="SELECT utilidad('$cod_barras')";
					 	
					$ejecutarInsertar9 = pg_query($conexion,$insertarDatos9);

					while ($row = pg_fetch_row($ejecutarInsertar9)) {
					  echo "$row[0] ";
					  echo "<br />\n";
					}

					

					if(!$ejecutarInsertar9){
							echo"Error En la linea de sql";
					}

?>