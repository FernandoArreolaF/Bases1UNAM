<?php
	
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> 
        <title>Formulario De Registro</title>
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>
    <body>


	<div class="contenedor">


		<form action="index2.php" class="formulario" id="formulario" name="formulario" method="POST">
			<div class="contenedor-inputs">

				<input type="submit" class="btn" name="stock" value="Productos con menos de 3 en stock">

				<div class="tabla">
			<table>
				<tr>
					<th>Producto</th>
					<th>Cantidad</th>
				</tr>
					<?php
						$consulta1 = " SELECT nom_prod, stock_prod FROM PRODUCTO WHERE stock_prod < 20;";
						$ejecutarConsulta1 = pg_query($conexion, $consulta1);
						$verFilas1 = pg_num_rows($ejecutarConsulta1);
						$fila1 = pg_fetch_array($ejecutarConsulta1);
						$queryProducto="SELECT *from PRODUCTO";
						$resultado = pg_query($conexion,$queryProducto) or die ("Error en la consulta SQL");
						$numReg = pg_num_rows($resultado);
						$factura = "SELECT genera_num_factura()";





						if(!$ejecutarConsulta1){
							echo"Error en la consulta";
						}else{
							if($verFilas1<1){
								echo"<tr><td>Sin registros</td></tr>";
							}else{
								for($i=0; $i<=$fila1; $i++){
									echo'
										<tr>
											
											<td>'.$fila1[0].'</td>
											<td>'.$fila1[1].'</td>
										</tr>
									';
									$fila1 = pg_fetch_array($ejecutarConsulta1);

								}

							}
						}


					?>
						
						
				
				
			</table>
		</div>


		<input type="submit" class="btn" name="producto" value="Lista de productos">
			<br>
			<br>
			
		</form>
		<div class="tabla">
			<table>
				<tr>
					<th>Producto</th>
					<th>Precio</th>
					<th>Descripcion</th>
					<th>Marca</th>
				</tr>
					<?php
						$consulta = "SELECT * FROM PRODUCTO";
						$ejecutarConsulta = pg_query($conexion, $consulta);
						$verFilas = pg_num_rows($ejecutarConsulta);
						$fila = pg_fetch_array($ejecutarConsulta);

						if(!$ejecutarConsulta){
							echo"Error en la consulta";
						}else{
							if($verFilas<1){
								echo"<tr><td>Sin registros</td></tr>";
							}else{
								for($i=0; $i<=$fila; $i++){
									echo'
										<tr>
											<td>'.$fila[1].'</td>
											<td>'.$fila[3].'</td>
											<td>'.$fila[2].'</td>
											<td>'.$fila[5].'</td>
										</tr>
									';
									$fila = pg_fetch_array($ejecutarConsulta);

								}

							}
						}


					?>
						
						
				
				
			</table>
		</div>
				

				

				<p>Articulo 1</p>
				<br>
				<label for="nom_producto">Nombre</label>
				<select name="nom_producto">
					<option value="ninguno">Eliga un producto</option>
					<option selected></option>
					<?php 
					while ($filaart=pg_fetch_array($resultado)) {
					echo "<option value".$filaart['cod_barras'].">".$filaart['nom_prod']."</option>";
					}
					?>
					
				</select>
				<br>
				<br>
				<label for="cantidad_producto">Cantidad</label>
				<select name="cantidad_producto">
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
				</select>
				<br>
				<br>
				<br>
				<p>Articulo 2</p>
				<br>
				<label for="nom_producto1">Nombre</label>
				<select name="nom_producto1">
					<option value="ninguno">Eliga un producto</option>
					<option value="Plumas">Plumas</option>
					<option value="Peluche">Peluche</option>
					<option value="Mochila">Mochila</option>
				</select>
				<br>
				<br>
				<label for="cantidad_producto1">Cantidad</label>
				<select name="cantidad_producto1">
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="12">12</option>
				</select>
				<br>
				<br>
				<br>

				<p>Articulo 3</p>
				<br>
				<label for="nom_producto2">Nombre</label>
				<select name="nom_producto2">
					<option value="ninguno">Eliga un producto</option>
					<option value="Plumas">Plumas</option>
					<option value="Peluche">Peluche</option>
					<option value="Mochila">Mochila</option>
				</select>
				<br>
				<br>
				<label for="cantidad_producto2">Cantidad</label>
				<select name="cantidad_producto2">
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
				</select>
				<br>
				<br>
				<input type="submit" href="paginas/form.html" class="btn" name="registrarse" value="Finalizar compra">
			</div>

			
			<br>
			<br>
			
		</form>
		
	</div>
	<script src="formulario.js"></script>
</body>
</html>
<?php
	


	if(isset($_POST['registrarse'])){
		$nom_producto =$_POST['nom_producto'];
		$cantidad_producto =$_POST['cantidad_producto'];
		$nom_producto1 =$_POST['nom_producto1'];
		$cantidad_producto1 =$_POST['cantidad_producto1'];
		$nom_producto2 =$_POST['nom_producto2'];
		$cantidad_producto2 =$_POST['cantidad_producto2'];
		$rs_cliente =$_POST['rs_cliente'];

		$insertarDatos6="SELECT inserta_productos('$nom_producto','$cantidad_producto','$nom_producto1','$cantidad_producto1','$nom_producto2','$cantidad_producto2','$rs_cliente')";
		
			$ejecutarInsertar6 = pg_query($conexion, $insertarDatos6);


		if(!$ejecutarInsertar6){
			echo"Error En la linea de sql";
		}
	}




	

	
?>
