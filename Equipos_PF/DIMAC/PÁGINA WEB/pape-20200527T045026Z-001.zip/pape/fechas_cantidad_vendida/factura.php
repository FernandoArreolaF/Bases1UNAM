<?php
$conexion = pg_connect("host=localhost dbname=PROYECTO user=postgres password=Americano76");
$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$insertadato20 = "SELECT cantidad_vendida_por_fecha('$fecha1','$fecha2')";

	$ejecutarDato20 = pg_query($conexion,$insertadato20);

	while ($row = pg_fetch_row($ejecutarDato20)) {
  echo "$row[0]";
  echo "<br />\n";
}


?>