<?php
	$conexion = pg_connect("host=localhost dbname=PROYECTO user=postgres password=Americano76");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> 
        <title>Formulario De Registro</title>
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>
    <body>


	<div class="contenedor">


		<form action="factura.php" class="formulario" id="formulario" name="formulario" method="POST">
			<div class="contenedor-inputs">

				

				<div class="tabla">
					<h1>Ingresa aqui las fechas para saber la cantidad vendida <h1>
			<table>
				<tr>
					
				</tr>
					<?php
						







					?>
						
						
				
				
			</table>
		</div>


		
			<br>
			<br>
			
		</form>
		<div class="tabla">
			
		</div>
				

				<input onkeyup= "validar()" type="text" name="fecha1" placeholder="dd-mm-aaaa" required="Fecha1">
				<input onkeyup="validar()" type="text" name="fecha2" placeholder="dd-mm-aaaa" required="fecha2">
				<?php
				if(isset($_POST['registrarse'])){
					$fecha1=$_POST['fecha1'];
					$fecha2=$_POST['fecha2'];


					}
						
				?>
				<br>
				<br>
				<input type="submit" href="paginas/form.html" class="btn" name="registrarse" value="Consultar cantidad vendida">
			</div>

			
			<br>
			<br>
			
		</form>
		
	</div>
	<script src="formulario.js"></script>
</body>
</html>
