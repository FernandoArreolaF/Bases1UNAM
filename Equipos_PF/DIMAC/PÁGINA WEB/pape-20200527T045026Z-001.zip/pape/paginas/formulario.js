//(funcion)(){
    var formulario = document.getElementById('formulario'),
		nom_cliente = formulario.nom_cliente,
		apPat = formulario.apPat,
		apMat = formulario.apMat,
        email = formulario.email,
		rs_cliente = formulario.rs_cliente,
        cp_cliente = formulario.cp_cliente,
        estado_cliente = formulario.estado_cliente,
        colonia_cliente = formulario.colonia_cliente,
        calle_cliente = formulario.calle_cliente,
        num_calle_cliente = formulario.num_calle_cliente,
		error = document.getElementById('error');
function validarNombre(e){
    if(nom_cliente.value == '' || nom_cliente == null){
        console.log('Completa el nombre');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa Un Nombre</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validarApellido(e){
    if(apPat.value == '' || apPat == null){
        console.log('Completa el apellido');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa tu Apellido</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}


function validarRazon(e){
    if(rs_cliente.value == '' || rs_cliente == null){
        console.log('Completa la razon social');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa una razon social</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validarCP(e){
    if(cp_cliente.value == '' || cp_cliente == null){
        console.log('Completa el codigo postal');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa un codigo postal</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validarEstado(e){
    if(estado_cliente.value == '' || estado_cliente == null){
        console.log('Completa el estado');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa un estado</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validarColonia(e){
    if(colonia_cliente.value == '' || colonia_cliente == null){
        console.log('Completa la colonia');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa una colonia</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validarCalle_Cliente(e){
    if(calle_cliente.value == '' || calle_cliente == null){
        console.log('Completa la calle');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa la calle</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validar_num_Calle_Cliente(e){
    if(num_calle_cliente.value == '' || num_calle_cliente == null){
        console.log('Completa la calle');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa la calle</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validar_nom_Producto(e){
    if(nom_producto.value == '' || nom_producto == null){
        console.log('Completa la calle');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa el nombre del producto</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validar_Cantidad_Producto(e){
    if(cantidad_producto.value == '' || cantidad_producto == null){
        console.log('Completa la calle');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa el nombre del producto</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}





function validarForm(e){
   error.innerHTML = '';
   error.style.display = 'block';
   validarNombre(e);
   validarApellido(e);
   validarRazon(e);
   validarCP(e);
   validarEstado(e);
   validarColonia(e);
   validarCalle_Cliente(e);
   validar_num_Calle_Cliente(e);
   validar_nom_Producto(e);
   validar_Cantidad_Producto(e);
}


formulario.addEventListener('submit', validarForm);

//}())