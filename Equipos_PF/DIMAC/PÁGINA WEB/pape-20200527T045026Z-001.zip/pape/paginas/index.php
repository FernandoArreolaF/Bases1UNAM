<?php
	$conexion = pg_connect("host=localhost dbname=PROYECTO user=postgres password=Americano76");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> 
        <title>Formulario De Registro</title>
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>
    <body>


	<div class="contenedor">


		<form action="#" class="formulario" id="formulario" name="formulario" method="POST">
			<div class="contenedor-inputs">

				<input type="submit" class="btn" name="stock" value="Productos con menos de 3 en stock">

				<div class="tabla">
			<table>
				<tr>
					<th>Producto</th>
					<th>Cantidad</th>
				</tr>
					<?php
						$consulta1 = " SELECT nom_prod, stock_prod FROM PRODUCTO WHERE stock_prod < 3;";
						$ejecutarConsulta1 = pg_query($conexion, $consulta1);
						$verFilas1 = pg_num_rows($ejecutarConsulta1);
						$fila1 = pg_fetch_array($ejecutarConsulta1);
						$queryProducto="SELECT *from PRODUCTO";
						$resultado = pg_query($conexion,$queryProducto) or die ("Error en la consulta SQL");
						$numReg = pg_num_rows($resultado);
						$fila12 = pg_fetch_array($ejecutarConsulta1);
						$queryProducto2="SELECT *from PRODUCTO";
						$resultado2 = pg_query($conexion,$queryProducto) or die ("Error en la consulta SQL");
						$numReg2 = pg_num_rows($resultado);
						$fila3 = pg_fetch_array($ejecutarConsulta1);
						$queryProducto3="SELECT *from PRODUCTO";
						$resultado3 = pg_query($conexion,$queryProducto) or die ("Error en la consulta SQL");
						$numReg3 = pg_num_rows($resultado);
						$factura = "SELECT genera_num_factura()";





						if(!$ejecutarConsulta1){
							echo"Error en la consulta";
						}else{
							if($verFilas1<1){
								echo"<tr><td>Sin registros</td></tr>";
							}else{
								for($i=0; $i<=$fila1; $i++){
									echo'
										<tr>
											
											<td>'.$fila1[0].'</td>
											<td>'.$fila1[1].'</td>
										</tr>
									';
									$fila1 = pg_fetch_array($ejecutarConsulta1);

								}

							}
						}


					?>
						
						
				
				
			</table>
		</div>


		<input type="submit" class="btn" name="producto" value="Lista de productos">
			<br>
			<br>
			
		</form>
		<div class="tabla">
			<table>
				<tr>
					<th>Producto</th>
					<th>Precio</th>
					<th>Descripcion</th>
					<th>Marca</th>
				</tr>
					<?php
						$consulta = "SELECT * FROM PRODUCTO";
						$ejecutarConsulta = pg_query($conexion, $consulta);
						$verFilas = pg_num_rows($ejecutarConsulta);
						$fila = pg_fetch_array($ejecutarConsulta);

						if(!$ejecutarConsulta){
							echo"Error en la consulta";
						}else{
							if($verFilas<1){
								echo"<tr><td>Sin registros</td></tr>";
							}else{
								for($i=0; $i<=$fila; $i++){
									echo'
										<tr>
											<td>'.$fila[1].'</td>
											<td>'.$fila[3].'</td>
											<td>'.$fila[2].'</td>
											<td>'.$fila[5].'</td>
										</tr>
									';
									$fila = pg_fetch_array($ejecutarConsulta);

								}

							}
						}


					?>
						
						
				
				
			</table>
		</div>
				

				<input onkeyup= "validar()" type="text" name="nom_cliente" placeholder="Nombre" required="Nombre">
				<input onkeyup="validar()" type="text" name="apPat" placeholder="Apellido Paterno" required="Apellido Paterno">
				<input type="text" name="apMat" placeholder="Apellido Materno">
				<input onkeyup="validar()" type="text" name="email" placeholder="Correo" required="Correo">
				<input type="text" name="email2" placeholder="Correo" >
				<input type="text" name="email3" placeholder="Correo" >
				<input onkeyup="validar()" type="text" name="rs_cliente" placeholder="Razon Social" required="Razon Social">
				<input onkeyup="validar()" type="text" name="cp_cliente" placeholder="Codigo Postal" required="Codigo Postal">
				<input onkeyup="validar()" type="text" name="estado_cliente" placeholder="Estado" required="Estado">
				<input onkeyup="validar()" type="text" name="colonia_cliente" placeholder="Colonia"required="Colonia">
				<input onkeyup="validar()" type="text" name="calle_cliente" placeholder="Calle" required="Calle">
				<input onkeyup="validar()" type="text" name="num_calle_cliente" placeholder="Numero de Calle" required="Numero de Calle">

				<p>Articulo 1</p>
				<br>
				<label for="nom_producto">Nombre</label>
				<select name="nom_producto">
					<option value="ninguno">Eliga un producto</option>
					<option selected></option>
					<?php 
					while ($filaart=pg_fetch_array($resultado)) {
					echo "<option value".$filaart['cod_barras'].">".$filaart['nom_prod']."</option>";
					}
					?>
					
				</select>
				<br>
				<br>
				<label for="cantidad_producto">Cantidad</label>
				<select name="cantidad_producto">
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
				</select>
				<br>
				<br>
				<br>
				<p>Articulo 2</p>
				<br>
				<label for="nom_producto">Nombre</label>
				<select name="nom_producto">
					<option value="ninguno">Eliga un producto</option>
					<option selected></option>
					<?php 
					while ($filaart2=pg_fetch_array($resultado2)) {
					echo "<option value".$filaart2['cod_barras'].">".$filaart2['nom_prod']."</option>";
					}
					?>
					
				</select>
				<br>
				<br>
				<label for="cantidad_producto">Cantidad</label>
				<select name="cantidad_producto">
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
				</select>
				<br>
				<br>
				<br>

				<p>Articulo 3</p>
				<br>
				<label for="nom_producto">Nombre</label>
				<select name="nom_producto">
					<option value="ninguno">Eliga un producto</option>
					<option selected></option>
					<?php 
					while ($filaart3=pg_fetch_array($resultado3)) {
					echo "<option value".$filaart3['cod_barras'].">".$filaart3['nom_prod']."</option>";
					}
					?>
					
				</select>
				<br>
				<br>
				<label for="cantidad_producto">Cantidad</label>
				<select name="cantidad_producto">
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
				</select>
				<br>
				<br>
				<input type="submit" href="paginas/form.html" class="btn" name="registrarse" value="Finalizar compra">
			</div>

			
			<br>
			<br>
			
		</form>
		
	</div>
	<script src="formulario.js"></script>
</body>
</html>
<?php
	if(isset($_POST['registrarse'])){
		$rs_cliente=$_POST['rs_cliente'];
		$nom_cliente=$_POST['nom_cliente'];
		$apPat=$_POST['apPat'];
		$apMat=$_POST['apMat'];
		
		$insertarDatos = "INSERT INTO CLIENTE VALUES('$rs_cliente',
												   '$nom_cliente',
												   '$apPat',
												   '$apMat')";

		$ejecutarInsertar = pg_query($conexion, $insertarDatos);

		if(!$ejecutarInsertar){
			echo"Error En la linea de sql";
		}
	}

	


	if(isset($_POST['registrarse'])){
		$cp_cliente=$_POST['cp_cliente'];
		$estado_cliente =$_POST['estado_cliente'];
		$colonia_cliente =$_POST['colonia_cliente'];
		
		$insertarDatos1 = "INSERT INTO  ESTADO_COLONIA_CLIENTE VALUES('$cp_cliente',
																	 '$estado_cliente',
																	 '$colonia_cliente')";

		$ejecutarInsertar1 = pg_query($conexion, $insertarDatos1);

		if(!$ejecutarInsertar1){
			echo"Error En la linea de sql";
		}
	}

	

	if(isset($_POST['registrarse'])){
		$rs_cliente =$_POST['rs_cliente'];
		$cp_cliente  =$_POST['cp_cliente'];
		$calle_cliente  =$_POST['calle_cliente'];
		$num_calle_cliente   =$_POST['num_calle_cliente'];
		
		$insertarDatos2 = "INSERT INTO   CALLE_NUM_CLIENTE VALUES('$rs_cliente',
																	 '$cp_cliente',
																	 '$calle_cliente',
																	 '$num_calle_cliente')";

		$ejecutarInsertar2 = pg_query($conexion, $insertarDatos2);

		if(!$ejecutarInsertar2){
			echo"Error En la linea de sql(1)";
		}
	}

	if(isset($_POST['registrarse'])){
		$email =$_POST['email'];
		$email2 =$_POST['email2'];
		$email3 =$_POST['email3'];
		$rs_cliente =$_POST['rs_cliente'];

		$insertarDatos9="SELECT inserta_correos('$email','$email2','$email3','$rs_cliente')";
		
			$ejecutarInsertar9 = pg_query($conexion, $insertarDatos9);


		if(!$ejecutarInsertar9){
			echo"Error En la linea de sql";
		}

	}


	if(isset($_POST['registrarse'])){
		$nom_producto =$_POST['nom_producto'];
		$cantidad_producto =$_POST['cantidad_producto'];
		$nom_producto1 =$_POST['nom_producto1'];
		$cantidad_producto1 =$_POST['cantidad_producto1'];
		$nom_producto2 =$_POST['nom_producto2'];
		$cantidad_producto2 =$_POST['cantidad_producto2'];
		$rs_cliente =$_POST['rs_cliente'];

		$insertarDatos6="SELECT inserta_productos('$nom_producto','$cantidad_producto','$nom_producto1','$cantidad_producto1','$nom_producto2','$cantidad_producto2','$rs_cliente')";
		
			$ejecutarInsertar6 = pg_query($conexion, $insertarDatos6);


		if(!$ejecutarInsertar6){
			echo"Error En la linea de sql";
		}
	}




	

	
?>
