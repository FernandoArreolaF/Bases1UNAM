{
    "version": "0.2.0",
    "configurations": [
      {
        "name": "Python: Flask",
        "type": "python",
        "request": "launch",
        "module": "flask",
        "env": {
          "FLASK_APP": "app.py",
          "FLASK_ENV": "development"
        },
        "args": [
          "run"
        ],
        "jinja": true
      }
    ]
  }
  