<?php
    require 'header.php';

    require_once 'pdo.php';
    $sql = 'SELECT * FROM empleado;';
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();

?>
<style>
    .banner{
        padding-top: 300px;
        padding-bottom: 200px;
        background-image: linear-gradient(170deg, #B6C7E14D 33%, #0B44994D 82%), url("assets/imgs/chefs.jpg") ;
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        position: relative;
    }
    #tabla_imagenes > thead > tr > th{
        vertical-align: middle;
        text-align: center;
    }
    #tabla_imagenes > tbody > tr > td{
        vertical-align: middle;
    }

</style>

<div class="banner">
    <div class="container text-center">
        <h1 class="display-2 text-white">Informacion de los Empleados</h1>
        <br><br>

    </div>
</div>
<div class="container">
    <br><br>
    <h2 class="text-center">Empleados Registrados</h2>
    <br><br>
    <div class="container-fluid">
        <?php
        if($stmt->rowCount() > 0){
            echo '<div class="table-responsive-sm">
                    <table id="tabla_imagenes" class="table table-striped table-image">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">Fotografia</th>
                                <th scope="col">Numero Empleado</th>
                                <th scope="col">Nombre Completo</th>
                                <th scope="col">Edad</th>
                                <th scope="col">RFC</th>
                                <th scope="col">Fecha Nacimiento</th>
                                <th scope="col">Sueldo</th>
                                <th scope="col">Direccion</th>
                            </tr>
                        </thead>
                    <tbody>';
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $nombre = $row['ap_paterno'].' '.$row['ap_mateno'].' '.$row['nombre'];
                $direccion = $row['estado'].', '.$row['colonia'].', '.$row['calle'].' #'.$row['numero'].', CP:'.$row['cp'];
                $url_visualizar_empleado = 'empleado.php?id='.$row['num_empleado'];
                    echo'
                        <tr>
                            <td><a href="'.$url_visualizar_empleado.'"><img src="fotografias/'.$row['foto'].'" class="img-fluid img-thumbnail"></a></td>
                            <td><a href="'.$url_visualizar_empleado.'">' . $row['num_empleado'].'</a></td>
                            <td><a href="'.$url_visualizar_empleado.'">' . $nombre.'</a></td>
                            <td>' . $row["edad"] . '</td>
                            <td>' . $row["rfc"] . '</td>
                            <td>' . $row["fecha_nac"] . '</td>
                            <td>' . $row["sueldo"] . '</td>
                            <td>' . $direccion . '</td>
                        </tr>';
                }
            echo'</tbody>
                    </table>
                    </div>';
        }else{
            echo '<h2>No se tienen empleados registrados</h2>';
        }
        ?>
    </div>

</div>


<?php
require 'footer.php';
?>
