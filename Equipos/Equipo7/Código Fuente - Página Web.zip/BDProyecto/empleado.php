<?php
require 'header.php';

require_once 'pdo.php';
$sql = "SELECT * FROM empleado WHERE num_empleado = :num_empleado";
$stmt = $pdo->prepare($sql);
if(isset($_GET['id'])){
    $stmt->execute(array(':num_empleado' => $_GET['id']));
}else{
    $stmt->execute(array(':num_empleado' => ''));
}


?>
<style>
    .banner-txn{
        padding-top: 300px;
        padding-bottom: 200px;
        background-image: linear-gradient(170deg, #B6C7E14D 33%, #0B44994D 82%), url("assets/imgs/chefs.jpg") ;
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        position: relative;
    }
</style>

<div class="banner-txn">
    <div class="container text-center">
        <h1 class="display-4 text-white">Datos del Empleado</h1>
        <br><br>
        <div class="row">
            <div class="text-left text-white col-8 offset-2">
                <?php
                if($stmt->rowCount() > 0){
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $nombre = $row['ap_paterno'].' '.$row['ap_mateno'].' '.$row['nombre'];
                    $direccion = $row['estado'].', '.$row['colonia'].', '.$row['calle'].' #'.$row['numero'].', CP:'.$row['cp'];

                    echo'
                        <div class="row">
                        <div class="text-center offset-2 col-8">
                            <img src="fotografias/'. $row['foto'] .'" class="rounded img-fluid">
                        </div>
                        </div>
                        <br>
                        <h3>Numero Empleado: '. $row['num_empleado'] .'</h3>
                        <h3>Nombre Completo: '. $nombre .'</h3>
                        <h3>Edad: '. $row['edad'] .'</h3>
                        <h3>RFC: '. $row['rfc'] .'</h3>
                        <h3>Fecha Nacimiento: '. $row['fecha_nac'] .'</h3>
                        <h3>Sueldo: '. $row['sueldo'] .'</h3>
                        <h3>Direccion: '. $direccion .'</h3>
                    ';

                    if($row['admin_rol'] !== NULL || $row['cocin_especialidad'] !== NULL || $row['mesero_hora_inicio'] !== NULL){
                        $admin = $row['admin_rol'] === NULL ? '' : '<h3>Administrador</h3>
                            <h3>Rol: '.$row['admin_rol'].'</h3>
                            <br>';
                        $cocin = $row['cocin_especialidad'] === NULL ? '' : '<h3>Cocinero</h3>
                            <h3>Especialidad: '.$row['cocin_especialidad'].'</h3>
                            <br>';
                        $mesero = ($row['mesero_hora_inicio'] === NULL || $row['mesero_hora_fin'] === NULL) ? '' : '<h3>Mesero</h3>
                            <h3>Horario: '. $row['mesero_hora_inicio'] .'-'.$row['mesero_hora_fin'].'</h3>';
                        echo '<br><br>
                            <h2 class="text-center">Puestos</h2>
                            <br>'.$admin.$cocin.$mesero;
                    }


                }else{
                    echo '<h3>No se encontro o selecciono algun Empleado</h3>';
                }
                ?>
            </div>
        </div>
    </div>
</div>

