<?php
$pdo = new PDO('pgsql:host=localhost; port=5432; dbname=proyectoFinal','proytswb_equipo7','1*hjUjksO(74PL');
$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
?>

