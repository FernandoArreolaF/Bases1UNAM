<?php
    function flashMessages(){
        if(isset($_SESSION['error_msg'])){
            echo('<p class="font-weight-bold text-center" style="color:red; font-size:1.8em;">'.$_SESSION['error_msg'].'</p>');
            unset($_SESSION['error_msg']);
        }
        if(isset($_SESSION['success_msg'])){
            echo('<p class="font-weight-bold text-center" style="color:green; font-size:1.8em;">'.$_SESSION['success_msg'].'</p>');
            unset($_SESSION['success_msg']);
        }
    }
    function rollback_registro($mensaje_error, $pdo){
        $sql = "ROLLBACK;";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();

        $_SESSION['error_msg'] = $mensaje_error;
        header('Location: ordenes.php');
        return;
    }