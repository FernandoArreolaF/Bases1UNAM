<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>BD - Proyecto Final</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <script src="assets/js/jquery-3.6.0.min.js"></script>
</head>
<body>

<style>

    .bg-transparent-txn{
        background-color: rgba(255, 255, 255, 0.45);
    }


    .navbar-dark.bg-transparent-txn.navbar-fixed-top-txn a.nav-link:hover{
        color: #3163a6;
    }

    .navbar-dark.bg-transparent-txn.navbar-fixed-top-txn a.nav-link{
        font-size:1.25em;
    }

    .navbar-dark.bg-transparent-txn.navbar-fixed-top-txn a.navbar-brand:hover{
        color: #3163a6;
    }

    .navbar-dark.bg-transparent-txn.navbar-fixed-top-txn a.navbar-brand{
        font-size:1.75em;
    }




    .dropdown-menu.show{
        background-color: #FFFFFF54;
        backdrop-filter: blur(10px);
    }

    .dropdown-menu.show > a:hover.dropdown-item{
        background-color: #FFFFFF6B;
    }

    .navbar-collapse.collapse.show li a:hover{
        background-color: #FFFFFF54;
        padding-left: 10px;
        border-radius: 5px;
    }
    .bg-transparent-txn.scrolled {
        background-color: #FFFFFF6B;
        transition: background-color 400ms ease-out;
        backdrop-filter: blur(3px);
    }
    .navbar.navbar-dark .navbar-toggler {
        color: rgba(255,255,255,1);
        border-color: rgba(0,0,0,.3);
    }


</style>
<script>
    jQuery(function () {
        jQuery(document).scroll(function () {
            var $nav = jQuery(".navbar-fixed-top-txn");
            $nav.toggleClass('scrolled', jQuery(this).scrollTop() > $nav.height());
        });
    });
</script>

<header>
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-transparent-txn navbar-fixed-top-txn">
        <div class="container" >
            <a class="navbar-brand" href="index.php">Restaurante</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="empleados.php">Empleados</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="ordenes.php">Ordenes</a>
                    </li>
                </ul>
        </div>
    </nav>
</header>