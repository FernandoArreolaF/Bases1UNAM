<?php
    session_start();
    require 'header.php';
    require_once 'pdo.php';
    require_once 'util.php';


    if(isset($_POST['totalfinal'])){

        if($_POST['totalfinal'] != '' && (($_POST['platilloSelect1']!= '' && $_POST['cantidad1'] != 0 && $_POST['total1'] != '') || ($_POST['platilloSelect2']!= '' && $_POST['cantidad2'] != 0 && $_POST['total2'] != '') || ($_POST['platilloSelect3']!= '' && $_POST['cantidad3'] != 0 && $_POST['total3'] != ''))){
            $sql = 'BEGIN;';
            $stmt = $pdo->prepare($sql);
            $stmt->execute();

            $insert = false;

            $sql = 'SELECT count(*) as cuenta FROM orden;';
            $stmt = $pdo->prepare($sql);
            $stmt->execute();

            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $num_ordenes = $row['cuenta'];
            $rfc_cliente = 'MELM8305281H4';



            $sql = 'INSERT INTO orden (fecha, num_empleado, rfc_cliente) VALUES (:fecha, :num_empleado, :rfc_cliente);';
            $stmt = $pdo->prepare($sql);
            if(!$stmt->execute(array(
                ':fecha'=> date("Y-m-d"),
                ':num_empleado'=> 3,
                ':rfc_cliente' => $rfc_cliente,
            ))){
                rollback_registro('Orden no pudo ser guardada correctamente', $pdo);
                return;
            }

            $folio = $pdo->lastInsertId();

            if($_POST['platilloSelect1']!= '' && $_POST['cantidad1'] != 0 && $_POST['total1'] != ''){
                $sql = 'INSERT INTO productos_orden (nombre_producto, folio_orden, cantidad) VALUES (:nombre_producto, :folio_orden, :cantidad);';
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array(
                    ':nombre_producto'=> $_POST['platilloSelect1'],
                    ':folio_orden'=> $folio,
                    ':cantidad'=> $_POST['cantidad1'],
                ));
                $insert = true;

            }

            if($_POST['platilloSelect2']!= '' && $_POST['cantidad2'] != 0 && $_POST['total2'] != ''){
                $sql = 'SELECT * FROM productos_orden WHERE folio_orden = :folio_orden AND nombre_producto = :nombre_producto';
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array(
                    ':folio_orden'=> $folio,
                    ':nombre_producto'=> $_POST['platilloSelect2'],
                ));
                if($stmt->rowCount() > 0){
                    $producto_existente = $stmt->fetch(PDO::FETCH_ASSOC);
                    $sql = 'UPDATE productos_orden SET cantidad = :cantidad WHERE folio_orden = :folio_orden AND nombre_producto = :nombre_producto';
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute(array(
                        ':nombre_producto'=> $_POST['platilloSelect2'],
                        ':folio_orden'=> $folio,
                        ':cantidad'=> intval($_POST['cantidad2'])+intval($producto_existente['cantidad'])
                    ));
                }else{
                    $sql = 'INSERT INTO productos_orden (nombre_producto, folio_orden, cantidad) VALUES (:nombre_producto, :folio_orden, :cantidad);';
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute(array(
                        ':nombre_producto'=> $_POST['platilloSelect2'],
                        ':folio_orden'=> $folio,
                        ':cantidad'=> $_POST['cantidad2']
                    ));
                }
                $insert = true;
            }

            if($_POST['platilloSelect3']!= '' && $_POST['cantidad3'] != 0 && $_POST['total3'] != ''){
                $sql = 'SELECT * FROM productos_orden WHERE folio_orden = :folio_orden AND nombre_producto = :nombre_producto';
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array(
                    ':folio_orden'=> $folio,
                    ':nombre_producto'=> $_POST['platilloSelect3'],
                ));
                if($stmt->rowCount() > 0){
                    $producto_existente = $stmt->fetch(PDO::FETCH_ASSOC);
                    $sql = 'UPDATE productos_orden SET cantidad = :cantidad WHERE folio_orden = :folio_orden AND nombre_producto = :nombre_producto';
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute(array(
                        ':nombre_producto'=> $_POST['platilloSelect3'],
                        ':folio_orden'=> $folio,
                        ':cantidad'=> intval($_POST['cantidad3'])+intval($producto_existente['cantidad'])
                    ));
                }else{
                    $sql = 'INSERT INTO productos_orden (nombre_producto, folio_orden, cantidad) VALUES (:nombre_producto, :folio_orden, :cantidad);';
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute(array(
                        ':nombre_producto'=> $_POST['platilloSelect3'],
                        ':folio_orden'=> $folio,
                        ':cantidad'=> $_POST['cantidad3']
                    ));
                }
                $insert = true;
            }
            /*
            if ($insert === false){
                rollback_registro('Los productos de la orden no pudieron ser guardados correctamente', $pdo);
                return;
            }
            */
            $sql = 'COMMIT;';
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $_SESSION['success_msg'] = 'La orden fue registrada exitosamente, su folio es: '.$folio;
            header('Location: ordenes.php');
            return;
        }else{
            $_SESSION['error_msg'] = "Faltaron datos para completar la orden";
            header('Location: ordenes.php');
            return;
        }
    }


    $sql = 'SELECT * FROM producto WHERE disponibilidad = 1;';
    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $select_options = '';
    if($stmt->rowCount() > 0){
        $count = 1;
        $select_options = '<option value="" selected>Elija un producto</option>';
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $select_options .= '<option data-precio="'.$row['precio'].'" value="'.$row['nombre'].'">'.$row['nombre'].'</option>';
        }

    }

?>
<style>
    .banner{
        padding-top: 300px;
        padding-bottom: 200px;
        background-image: linear-gradient(170deg, #B6C7E14D 33%, #0B44994D 82%), url("assets/imgs/platillo.jpg") ;
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        position: relative;
    }
</style>

<div class="banner">
    <div class="container text-center">
        <h1 class="display-2 text-white">Generar Orden</h1>
        <br><br>
        <?php flashMessages(); ?>

    </div>
</div>
<div class="container">
    <br><br>
    <h2 class="text-center">Llene los datos de la orden</h2>
    <br><br>
<?php
    if($select_options !== ''){
        echo '
        <form method="post">
            <div class="row">
                <div class="col-6">
                    <h4>Producto</h4>
                </div>
                <div class="col-2">
                    <h4>Precio</h4>
                </div>
                <div class="col-2">
                    <h4>Cantidad</h4>
                </div>
                <div class="col-2">
                    <h4>Total</h4>
                </div>
            </div>
        ';
        for ($i = 1; $i <=3; $i++){
            echo '
                <div class="row">
                    <div class="input-group mb-3 col-6">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="inputGroupSelect'.$i.'">Producto '.$i.'</label>
                        </div>
                        <select class="custom-select" id="inputGroupSelect'.$i.'" name="platilloSelect'.$i.'" data-num="'.$i.'">
                            '.$select_options.'
                        </select>
                    </div>
                     <div class="col-2">
                        <input type="text" name="precio'.$i.'" id="precio'.$i.'" class="form-control" value="0" readonly>
                    </div>
                    <div class="col-2">
                        <input type="number" data-num="'.$i.'" min="0" name="cantidad'.$i.'" id="cantidad'.$i.'" class="form-control cantidades" >
                    </div>
                    <div class="col-2">
                        <input type="text" name="total'.$i.'" id="total'.$i.'" class="form-control totales" readonly>
                    </div>           
                </div>  
            ';
        }
        echo '
            <div class="row">
                <div class="col-4 offset-6">
                    <h3 class="text-center">Total Final</h3>
                </div>
                <div class="col-2">
                    <input type="text" name="totalfinal" id="totalfinal" class="form-control" readonly>  
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-2 offset-10 text-center">
                    <button class="btn btn-success font-weight-bold" type="submit">Procesar Orden</button>
                </div>
            </div>
        </form>';
    }else{
        echo '<h3 class="text-center">No hay productos disponibles</h3>';
    }
?>
</div>
<br><br>
<h2 class="text-center">Ordenes Registradas</h2>
<br><br>
<div class="container-fluid">
<?php
$sql = "SELECT * FROM orden LEFT JOIN empleado e on orden.num_empleado = e.num_empleado ORDER BY folio DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute();

if($stmt->rowCount() > 0){
    echo '<div class="table-responsive-sm">
                    <table id="tabla_imagenes" class="table table-striped table-image">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">Folio</th>
                                <th scope="col">Fecha</th>
                                <th scope="col">Total</th>
                                <th scope="col">Nombre Empleado</th>
                                <th scope="col">RFC Cliente</th>
                            </tr>
                        </thead>
                    <tbody>';
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $nombre = $row['ap_paterno'].' '.$row['ap_mateno'].' '.$row['nombre'];
        $url_visualizar_empleado = 'empleado.php?id='.$row['num_empleado'];
        echo'
                        <tr>
                            <td>'. $row['folio'] .'</td>
                            <td>'. $row['fecha'] .'</td>
                            <td>'. $row['total'] .'</td>
                            <td><a href="'.$url_visualizar_empleado.'">' . $nombre.'</a></td>
                            <td>' . $row["rfc_cliente"] . '</td>
                        </tr>';
    }
    echo'</tbody>
                    </table>
                    </div>';
}else{
    echo '<h2>No se ordenes registradas</h2>';
}
?>
</div>
<br><br><br>
<script>
    $('select').on('change', function(){
        var num_platillo = $(this).data('num');
        var precio = $(this).find(':selected').data('precio');

        $('#precio'+num_platillo).val(precio);
        $('#cantidad'+num_platillo).val(1);
        $('#total'+num_platillo).val(precio).change();
    });

    $('.cantidades').on('change', function (){
        var num = $(this).data('num');
        var precio = $('#precio'+num).val();
        $('#total'+num).val(Number(precio)*Number($(this).val())).change();
    });

    $('.cantidades').on('keyup', function (){
        var num = $(this).data('num');
        var precio = $('#precio'+num).val();
        $('#total'+num).val(Number(precio)*Number($(this).val())).change();
    });

    $('.totales').on('change', function(){
        $('#totalfinal').val(Number($('#total1').val())+Number($('#total2').val())+Number($('#total3').val()));
    });
</script>

<?php
require 'footer.php';
?>
