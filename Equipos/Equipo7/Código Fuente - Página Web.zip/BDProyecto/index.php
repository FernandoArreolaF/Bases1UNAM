<?php
    require 'header.php';
?>
    <style>
        .banner{
            padding-top: 300px;
            padding-bottom: 200px;
            background-image: linear-gradient(170deg, #B6C7E14D 33%, #0B44994D 82%), url("assets/imgs/restaurante.jpg") ;
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            position: relative;
        }
    </style>

    <div class="banner">
        <div class="container text-center">
            <h1 class="display-2 text-white">Proyecto Final</h1>
            <br><br>
            <h1 class="display-4 text-white">Base de Datos Restaurante</h1>
            <br><br>
            <div class="row">
                <div class="offset-2 col-4">
                    <a role="button" class="btn btn-success btn-lg" href="empleados.php" style="font-size: 1.6em">Empleados</a>
                </div>
                <div class="col-4">
                    <a role="button" class="btn btn-info btn-lg" href="ordenes.php" style="font-size: 1.6em">Llenar Orden</a>
                </div>
            </div>

        </div>
    </div>


<?php
    require 'footer.php';
?>
