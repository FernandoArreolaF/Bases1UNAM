<?php

    //Cambios en el archivo de config de xamp, quitar ';' de los 3 de pgsql

$Boton1 ="";
$articulo1 = " ";
$articulo2 = " ";
$articulo3 = " ";
$br = "";
$r="";
$rfccomp="";
$aux="";


    //PRUEBA
    //Regresar a tabla papeleria osea quitarle el 2
    $dbservername = "localhost";
    $dbusername = "postgres";
    $dbname = "papeleria2";
    $dbpassword = "urisaurio21";
    $puerto = "5432";
    $conexion=pg_connect("host=$dbservername port=$puerto dbname=$dbname user=$dbusername password=$dbpassword");

    if($conexion){
        //echo "Conexión exitosa";
    } else{

        echo "No se pudo realizar la conexión";
    }

    // $consulta = "Select prov_nombre FROM PROVEEDOR";
    // $query = pg_query($conexion, $consulta);
    
    if(isset($_POST['BotonRegistro']))$Boton1=$_POST['BotonRegistro'];


//Recuperar las variables del formulario par al parte de cleintes
    if($Boton1){
        $rfc = $_POST["rfc"];
        $cli_nombre = $_POST["nombre"];
        $cli_apPat = $_POST["apellidopaterno"];
        $cli_ap_Mat = $_POST["apellidomaterno"];
        $cli_estado = $_POST["estado"];
        $cli_CP = $_POST["codigopostal"];
        $cli_colonia = $_POST["colonia"];
        $cli_calle = $_POST["calle"];
        $cli_numero = $_POST["numero"];
        $email = $_POST["email"];
        // echo "\nEl RFC del cliente es : " .$rfc ;
        // echo "\nEl Nombre del cliente es :  ".$cli_nombre;
        // echo "\nEl Paterno del cliente es :  ".$cli_ap_Pat;
        // echo "\nEl Materno del cliente es : ".$cli_ap_Mat;
        // echo "\nEl estado del cliente es : ".$cli_estado;
        // echo "\nEl CP del cliente es : ".$cli_CP;
        // echo "\nEl colonia del cliente es :  ".$cli_colonia;
        // echo "\nEl calle cliente es : ".$cli_calle;
        // echo "\nEl numero del cliente es : ".$cli_numero;
        // echo "\nEl email del cliente es : ".$email;

        //Inserción de datos sobre tabla CLIENTE
        $query="INSERT INTO cliente VALUES('$rfc','$cli_nombre','$cli_apPat','$cli_ap_Mat','$cli_estado','$cli_CP','$cli_colonia','$cli_calle','$cli_numero')"; 
        pg_query($conexion,$query);

        $query2="INSERT INTO EMAIL VALUES('$email','$rfc')"; 
        pg_query($conexion,$query2);

        header("location:principal.html");

    } else {
            //Regalo oso de peluche, taza y regalo
            //Recarga 4 compañías 
            //Prod pritt cuadernos, lápiz, pluma y goma
            //impresión impresión 

            $articulo1 = $_POST["articulo1"];
            $cantidad1 = $_POST["cantidad1"];
            $articulo2 = $_POST["articulo2"];
            $cantidad2 = $_POST["cantidad2"];
            $articulo3 = $_POST["articulo3"];
            $cantidad3 = $_POST["cantidad3"];
            $cli_rfc2 = $_POST["cli_rfc2"];
            $rfccomp= $cli_rfc2;
            
            // $query3= "SELECT cli_rfc FROM cliente WHERE cliente.cli_rfc = '$cli_rfc2' "; 
            // $cone = pg_query($conexion,$query3);
            
            // echo "Hola soy cone : " .$query3;
            // // Verifica si la consulta fue exitosa
            // if ($cone = null){
                    
            //         echo "<br>NO EXISTES primeri if";
            //         exit;
            // } else {
            //     echo "<br>Si existe el usuario, puedes comprar";
            // }

            // if ($cone){
            //     echo "SI HAS EXISTIDO PUEDES COMPRAR";
            // }



                
            // echo "<br>El articulo 1 del cliente es : ".$articulo1;
            // echo "<br>El Cantidad 1 del cliente es : ".$cantidad1;
            // echo "<br>El articulo 2 del cliente es : ".$articulo2;
            // echo "<br>El Cantidad 2 del cliente es : ".$cantidad2;
            // echo "<br>El articulo 3 del cliente es : ".$articulo3;
            // echo "<br>El Cantidad 3 del cliente es : ".$cantidad3;
           
           
            if ($articulo1 != " "){
                $articulo1 = $_POST["articulo1"];
                
                echo "<br>AEl articulo 1 del cliente es : ".$articulo1;


                //Bandera según cada tipo de producto
                // if ($articulo1 = "Regalo" or $articulo1 = "Oso de peluche" or $articulo1 = "Taza"){
                //     echo "Holi<br>";
                //     $br = "br";
                // }

                // if ($articulo2 = "Regalo" or $articulo2 = "Oso de peluche" or $articulo2 = "Taza"){
                //     echo "Holi<br>";
                //     $br = "br";
                // }

                // if ($articulo3 = "Regalo" or $articulo3 = "Oso de peluche" or $articulo3 = "Taza"){
                //     echo "Holi<br>";
                //     $br = "br";
                // }
            }
            if ($articulo2 != " "){
                $articulo2 = $_POST["articulo2"];
                
                echo "<br>AA El articulo 2 del cliente es : ".$articulo2;
            }
            if ($articulo3 != " "){
                $articulo3 = $_POST["articulo3"];
                
                echo "<br>AAA El articulo 3 del cliente es : ".$articulo3;
            }













            // if ($articulo1 != " " or $articulo2 != " " or $articulo3 != " "){
            //     $articulo1 = $_POST["articulo1"];
            //     $articulo2 = $_POST["articulo2"];
            //     $articulo3 = $_POST["articulo3"];
                
            //     echo "<br>El articulo 1 del cliente es : ".$articulo1;
            //     echo "<br>El articulo 2 del cliente es : ".$articulo2;
            //     echo "<br>El articulo 3 del cliente es : ".$articulo3;


            //     //Bandera según cada tipo de producto
            //     // if ($articulo1 = "Regalo" or $articulo1 = "Oso de peluche" or $articulo1 = "Taza"){
            //     //     echo "Holi<br>";
            //     //     $br = "br";
            //     // }

            //     // if ($articulo2 = "Regalo" or $articulo2 = "Oso de peluche" or $articulo2 = "Taza"){
            //     //     echo "Holi<br>";
            //     //     $br = "br";
            //     // }

            //     // if ($articulo3 = "Regalo" or $articulo3 = "Oso de peluche" or $articulo3 = "Taza"){
            //     //     echo "Holi<br>";
            //     //     $br = "br";
            //     // }
            // }


            
        //     if ($articulo1 != " " and $articulo2 != " "){
        //         $articulo1 = $_POST["articulo1"];
        //         $articulo2 = $_POST["articulo2"];
        //         $cantidad1 = $_POST["cantidad1"];
        //         $cantidad2 = $_POST["cantidad2"];


        //         //Validación recargas
        //         if ($articulo1 = "Recarga Telcel" or $articulo1 = "Recarga Movistar" or $articulo1 = "Recarga Pillofon" or $articulo1 = "Recarga AT&T"){
        //             echo "otro mensaje<br>";
        //             $r = "recarga";
        //         }
                
        //         if ($articulo2 = "Recarga Telcel" or $articulo2 = "Recarga Movistar" or $articulo2 = "Recarga Pillofon" or $articulo2 = "Recarga AT&T"){
        //             echo "otro mensaje<br>";
        //             $r = "recarga";
        //         }

        //         if ($articulo3 = "Recarga Telcel" or $articulo3 = "Recarga Movistar" or $articulo3 = "Recarga Pillofon" or $articulo3 = "Recarga AT&T"){
        //             echo "otro mensaje<br>";
        //             $r = "recarga";
        //         }
        //     }

        //     //Validaciónes de 1 con los otros dos
        //     if ($articulo1 != " " and $articulo3 != " "){

        //         $articulo1 = $_POST["articulo1"];
        //         $articulo3 = $_POST["articulo3"];
        //         $cantidad1 = $_POST["cantidad1"];
        //         $cantidad3 = $_POST["cantidad3"];

        //         //Validación recargas
        //         if ($articulo1 = "Recarga Telcel" or $articulo1 = "Recarga Movistar" or $articulo1 = "Recarga Pillofon" or $articulo1 = "Recarga AT&T"){
        //             echo "otro mensaje 2<br>";
        //             $r = "recarga";
        //         }
                
        //         if ($articulo2 = "Recarga Telcel" or $articulo2 = "Recarga Movistar" or $articulo2 = "Recarga Pillofon" or $articulo2 = "Recarga AT&T"){
        //             echo "otro mensaje 2<br>";
        //             $r = "recarga";
        //         }

        //         if ($articulo3 = "Recarga Telcel" or $articulo3 = "Recarga Movistar" or $articulo3 = "Recarga Pillofon" or $articulo3 = "Recarga AT&T"){
        //             echo "otro mensaje 2<br>";
        //             $r = "recarga";
        //         }
        //     }

                    
        //     if ($articulo2 != " " and $articulo3 != " "){
        //         $articulo2 = $_POST["articulo2"];
        //         $articulo3 = $_POST["articulo3"];
        //         $cantidad2 = $_POST["cantidad2"];
        //         $cantidad3 = $_POST["cantidad3"];
                
        //         //Validación recargas
        //         if ($articulo1 = "Recarga Telcel" or $articulo1 = "Recarga Movistar" or $articulo1 = "Recarga Pillofon" or $articulo1 = "Recarga AT&T"){
        //             echo "otro mensaje 3<br>";
        //             $r = "recarga";
        //         }
                
        //         if ($articulo2 = "Recarga Telcel" or $articulo2 = "Recarga Movistar" or $articulo2 = "Recarga Pillofon" or $articulo2 = "Recarga AT&T"){
        //             echo "otro mensaje 3<br>";
        //             $r = "recarga";
        //         }

        //         if ($articulo3 = "Recarga Telcel" or $articulo3 = "Recarga Movistar" or $articulo3 = "Recarga Pillofon" or $articulo3 = "Recarga AT&T"){
        //             echo "otro mensaje 3<br>";
        //             $r = "recarga";
        //         }

        //     }

        //     if ($articulo1 != " " and $articulo2 != " " and $articulo3 != " "){
        //         $articulo1 = $_POST["articulo1"];
        //         $articulo2 = $_POST["articulo2"];
        //         $articulo3 = $_POST["articulo3"];
        //         $cantidad1 = $_POST["cantidad1"];
        //         $cantidad2 = $_POST["cantidad2"];
        //         $cantidad3 = $_POST["cantidad3"];

        //         //Validación recargas
        //         if ($articulo1 = "Recarga Telcel" or $articulo1 = "Recarga Movistar" or $articulo1 = "Recarga Pillofon" or $articulo1 = "Recarga AT&T"){
        //             echo "otro mensaje 322222<br>";
        //             $r = "recarga";
        //         }
                
        //         if ($articulo2 = "Recarga Telcel" or $articulo2 = "Recarga Movistar" or $articulo2 = "Recarga Pillofon" or $articulo2 = "Recarga AT&T"){
        //             echo "otro mensaje 3<br>";
        //             $r = "recarga";
        //         }
    
        //         if ($articulo3 = "Recarga Telcel" or $articulo3 = "Recarga Movistar" or $articulo3 = "Recarga Pillofon" or $articulo3 = "Recarga AT&T"){
        //             echo "otro mensaje 3<br>";
        //             $r = "recarga";
        //     }

        // }
        //header("location:principal.html");
    }   
?>