import styled from "styled-components";
import useUser from "../../Hooks/useUser";
import { useNavigate } from "react-router-dom";


const MenuItemDiv = styled.div`
    position: relative;
    height: 60%;
    padding: 1rem 0;
`;

const Conteiner = styled.div`
    position: relative;
    width: 100%;
    display: flex;
    justify-content: center;
    padding: 0;
    flex-direction: column;
    flex-wrap: wrap;
    vertical-align: middle;
    list-style-type: none;
`;


const menuConfig = {
  vendedor: [
    { label: "Inicio", path: "/home" },
    { label: "Datos", path: "/datos" },
    { label: "Articulos", path: "/articulos"},
  ],
  Cajero: [
    { label: "Inicio", path: "/home" },
    { label: "Datos", path: "/datos" },
    { label: "Venta", path: "/venta"}
  ],
  administrativo: [
    { label: "Reportes", path: "/Reportes" },
  ],
  limpieza: [],
  seguridad: [],
};

const LinkItem = styled.div`
  width: 100%;
  padding: 1rem 0;
  text-align: center;
  color: white;
  background-color: transparent;
  transition: background-color 0.3s ease, color 0.3s ease;
  cursor: pointer;

  &:hover {
    background-color: #374151;
    color: #ffffff;
  }
`;


const MenuLateral = () =>{
  const navigate = useNavigate();

    const {getTipoUsuario}=useUser(); 
    const tipo = getTipoUsuario();

    const opciones = tipo ? menuConfig[tipo] : [];

    return(
        <MenuItemDiv>
            <Conteiner>
                {opciones.map(({ label, path}, idx) => (
                    <LinkItem key={idx} onClick={() => navigate(path)}>
            {label}
          </LinkItem>
                ))}
            </Conteiner>
        </MenuItemDiv>

    );
}

export default MenuLateral;