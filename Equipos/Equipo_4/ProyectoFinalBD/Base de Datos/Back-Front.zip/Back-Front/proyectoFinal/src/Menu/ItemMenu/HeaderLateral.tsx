import styled from "styled-components";

const Navbardiv = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  width: 100%;
  height: min-content;
`;

const ImgHeader = styled.img`
  height: 100%;
  width: inherit;
`;

const HeaderLateral = () => {
  return (
    <Navbardiv>
      <ImgHeader src="https://cdn.pixabay.com/photo/2024/05/31/18/54/meme-8801100_960_720.png" />
    </Navbardiv>
  );
};

export default HeaderLateral;
