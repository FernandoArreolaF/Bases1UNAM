import { useState } from "react";
import styled from "styled-components";
import useUser from "../../Hooks/useUser";
import axios from 'axios';
import { useNavigate } from "react-router-dom";

const NewForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  background-color:rgb(219, 219, 219);
  padding: 2rem;
  border-radius: 1rem;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 400px;
`;
const Title = styled.h2`
  text-align: center;
  font-size: 1.5rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: black; /* Asegúrate de que haya color */
`;
const Conteiner = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  width: 100vw;
`;

const Input = styled.input`
  padding: 0.75rem 1rem;
  border: 1px solid #d1d5db;
  border-radius: 0.5rem;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.3);
  }
`;

const Button = styled.button`
  background-color: #3b82f6;
  color: white;
  padding: 0.75rem 1rem;
  border: none;
  border-radius: 0.5rem;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.2s;

  &:hover {
    background-color: #2563eb;
  }
`;




const Login = () => {
  //const navigate = useNavigate();
  const [Id_Emp, setId_Emp] = useState("");
  const [password, setPassword] = useState("");
  const {addUser} = useUser();
  const navigate = useNavigate();

  const handleLogin = async (e: { preventDefault: () => void; }) => {
    e.preventDefault();
    try {
      const response =await axios.post('http://localhost:8000/login', {
        Id_Emp,
        password
      })
      const [authData, userData] = response.data;
      if(authData.validacion){
        addUser([authData, userData]);
        navigate("/home");
      }else{
        alert("❌ Credenciales incorrectas. Verifica tu ID y contraseña.");
      }
    } catch (error) {
      console.error("Error al enviar los datos", error);
      alert("❌ Conexion invalida. Veridica tu conexion.");
    };
  };

  return (
    <Conteiner>
      <NewForm onSubmit={handleLogin}>
        <Title>Iniciar sesión</Title>
        <Input
          type="number"
          max="99999"
          placeholder="ID EMPLEADO"
          value={Id_Emp}
          onChange={(e) => setId_Emp(e.target.value)}
          required
        />
        <Input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <Button type="submit">Enviar</Button>
      </NewForm>
    </Conteiner>
  );
};

export default Login;