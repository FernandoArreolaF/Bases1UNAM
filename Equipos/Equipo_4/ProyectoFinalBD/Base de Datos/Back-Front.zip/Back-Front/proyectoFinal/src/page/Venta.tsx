import styled from "styled-components";
import { useEffect, useState } from "react";
import axios from "axios";
import NabvarLateral from "../Menu/NabvarLateral";
import useUser from "../Hooks/useUser";

const ContentContainer = styled.div`
  flex: 1;
  padding: 2rem;
  background-color: rgb(36, 56, 86);
  overflow-y: auto;
`;

const Form = styled.form`
  display: flex;
  gap: 1rem;
  margin-bottom: 1rem;
  flex-wrap: wrap;
`;

const Input = styled.input`
  padding: 0.5rem;
  border-radius: 8px;
  border: none;
`;

const Button = styled.button`
  padding: 0.5rem 1rem;
  background-color: #3a86ff;
  color: #fff;
  border: none;
  border-radius: 8px;
  cursor: pointer;
`;

const Lista = styled.div`
  margin-top: 2rem;
`;

const Item = styled.div`
  background: #2e4a6b;
  padding: 1rem;
  border-radius: 10px;
  margin-bottom: 1rem;
`;

const MainCointeiner = styled.div`
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-wrap: nowrap;
  overflow: scroll;
  flex-direction: row;
  justify-content: center;
  align-items: stretch;
  text-align: center;
  overflow-wrap: break-word;
`;

interface Articulo {
  ["Codigo de Barras"]: string;
  Nombre: string;
  ["Precio de venta"]: number;
  Stock: number;
}

interface ArticuloSeleccionado {
  cod_barras: string;
  nombre: string;
  cantidad: number;
  precio: number;
}

const CarritoArticulos = () => {
  const [articulos, setArticulos] = useState<Articulo[]>([]);
  const [codigoBarras, setCodigoBarras] = useState("");
  const [cantidad, setCantidad] = useState(1);
  const [seleccionados, setSeleccionados] = useState<ArticuloSeleccionado[]>([]);
  const [idEmpleado, setIdEmpleado] = useState("");
  const [rfcCliente, setRfcCliente] = useState("");
  const {getId}=useUser();

  useEffect(() => {
    const fetchData = async () => {
      const res = await axios.post("http://localhost:8000/art");
      setArticulos(res.data);
    };
    fetchData();
  }, []);

  const handleAgregar = (e: React.FormEvent) => {
    e.preventDefault();

    const articulo = articulos.find(a => a["Codigo de Barras"] === codigoBarras);

    if (!articulo) {
      alert("❌ Código no encontrado");
      return;
    }

    if (cantidad <= 0 || cantidad > articulo.Stock) {
      alert(`❌ Cantidad inválida. Stock disponible: ${articulo.Stock}`);
      return;
    }

    const yaExiste = seleccionados.find(item => item.cod_barras === codigoBarras);

    if (yaExiste) {
      setSeleccionados(prev =>
        prev.map(item =>
          item.cod_barras === codigoBarras
            ? { ...item, cantidad: item.cantidad + cantidad }
            : item
        )
      );
    } else {
      setSeleccionados(prev => [
        ...prev,
        {
          cod_barras: articulo["Codigo de Barras"],
          nombre: articulo.Nombre,
          cantidad,
          precio: articulo["Precio de venta"]
        }
      ]);
    }

    setCodigoBarras("");
    setCantidad(1);
  };

  const handleEliminar = (codigo: string) => {
    setSeleccionados(prev => prev.filter(item => item.cod_barras !== codigo));
  };

    const handleCompra = async () => {
    const compra = {
      rfc_cliente: rfcCliente,
      id_empleado: Number(idEmpleado),
      id_cajero: getId(),
      articulos: seleccionados
    };

    try {
      const response = await fetch("http://localhost:8000/vent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(compra),
      });

      const data = await response.json();

      if (response.ok) {
        console.log("🧾 Compra realizada:", data);
        alert("✅ Compra registrada correctamente.");
        // Limpiar estados solo si fue exitoso
        setSeleccionados([]);
        setIdEmpleado("");
        setRfcCliente("");
      } else {
        console.error("❌ Error al registrar compra:", data);
        alert("❌ Error al registrar la compra. Revisa la consola.");
      }
    } catch (error) {
      console.error("❌ Error de red o servidor:", error);
      alert("❌ Fallo de conexión con el servidor.");
    }
  };

  return (
    <MainCointeiner>
      <NabvarLateral />
      <ContentContainer>
        <h2>Agregar Artículos por Código</h2>

        <Form onSubmit={handleAgregar}>
          <Input
            type="number"
            placeholder="ID de Vendedor"
            value={idEmpleado}
            onChange={e => setIdEmpleado(e.target.value)}
          />
          <Input
            type="text"
            placeholder="RFC del Cliente"
            value={rfcCliente}
            onChange={e => setRfcCliente(e.target.value)}
          />
          <Input
            type="text"
            placeholder="Código de barras"
            value={codigoBarras}
            onChange={e => setCodigoBarras(e.target.value)}
          />
          <Input
            type="number"
            placeholder="Cantidad"
            value={cantidad}
            onChange={e => setCantidad(Number(e.target.value))}
            min={1}
          />
          <Button type="submit">Agregar</Button>
        </Form>

        <Lista>
          <h3>Artículos Seleccionados</h3>
          {seleccionados.map((art, index) => (
            <Item key={index}>
              <p><strong>{art.nombre}</strong></p>
              <p>Código: {art.cod_barras}</p>
              <p>Cantidad: {art.cantidad}</p>
              <p>Subtotal: ${art.precio * art.cantidad}</p>
              <Button onClick={() => handleEliminar(art.cod_barras)}>Eliminar</Button>
            </Item>
          ))}
        </Lista>

        {seleccionados.length > 0 && (
          <div style={{ marginTop: "2rem" }}>
            <Button onClick={handleCompra}>Realizar Compra</Button>
          </div>
        )}
      </ContentContainer>
    </MainCointeiner>
  );
};

export default CarritoArticulos;