
import useUser from "../Hooks/useUser";
import NabvarLateral from "../Menu/NabvarLateral";
import styled from "styled-components";

const MainCointeiner = styled.div`
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-wrap: nowrap;
  overflow: scroll;
  flex-direction: row;
  justify-content: center;
  align-items: stretch; 
  text-align: center;
  overflow-wrap: break-word;
`;

const ContentContainer = styled.div`
  flex: 1;
  padding: 2rem;
  background-color:rgb(36, 56, 86);
  overflow-y: auto;
`;




const Home = () => {

  const {getNombreCompleto} = useUser();
  const nombre = getNombreCompleto();

  return (
    <MainCointeiner>
      <NabvarLateral/>
      <ContentContainer>
        <h1>Bienvenido</h1>
        <p>{nombre}</p>
      </ContentContainer>
    </MainCointeiner>
  );
};

export default Home;