import styled from "styled-components";
import NabvarLateral from "../Menu/NabvarLateral";
import { useState, useEffect } from "react";
import axios from "axios";

const MainContainer = styled.div`
  width: 100vw;
  height: 100vh;
  display: flex;
  overflow: hidden;
  flex-direction: row;
  background-color: #1c2c3b;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const ContentContainer = styled.div`
  flex: 1;
  padding: 2rem;
  background-color: rgb(36, 56, 86);
  overflow-y: auto;
  color: #ffffff;

  h1 {
    margin-bottom: 2rem;
    font-size: 2rem;
    text-align: center;
  }
`;

const GridDatos = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
`;

const DatoBox = styled.div`
  background-color: #2e4a6b;
  border-radius: 12px;
  padding: 1rem;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);

  h3 {
    margin-bottom: 0.5rem;
    font-size: 1rem;
    color: #a0d2ff;
  }

  p {
    font-size: 1rem;
    font-weight: 500;
  }
`;


const Articulos = () => {
    const [Art, setArt] = useState([]);

  useEffect(() => {
    const fetchArticulos = async () => {
      try {
        const response = await axios.post('http://localhost:8000/art');
        setArt(response.data);
      } catch (error) {
        console.error("❌ Error al cargar artículos:", error);
      }
    };

    fetchArticulos();
  }, []);

  return (
    <MainContainer>
      <NabvarLateral />
      <ContentContainer>
        <h1>Catálogo de Artículos</h1>
        <GridDatos>
          {Art.map((e, idx) => (
            <DatoBox key={idx}>
              <h3>{e["Nombre"] || "Sin nombre"}</h3>
              {e["Codigo de Barras"] && <p><strong>Código:</strong> {e["Codigo de Barras"]}</p>}
              {e["Precio de compra"] && <p><strong>Compra:</strong> ${e["Precio de compra"]}</p>}
              {e["Precio de venta"] && <p><strong>Venta:</strong> ${e["Precio de venta"]}</p>}
              {e["Stock"] != null && <p><strong>Stock:</strong> {e["Stock"]}</p>}
              {e["Categoría"] && <p><strong>Categoría:</strong> {e["Categoría"]}</p>}
              {e["Nombre categoria"] && <p><strong>Nombre Categoria:</strong> {e["Nombre categoria"]}</p>}
              {e["Tipo categoria"] && <p><strong>Tipo categoria:</strong> {e["Tipo categoria"]}</p>}
            </DatoBox>
          ))}
        </GridDatos>
      </ContentContainer>
    </MainContainer>
  );
}

export default Articulos;
