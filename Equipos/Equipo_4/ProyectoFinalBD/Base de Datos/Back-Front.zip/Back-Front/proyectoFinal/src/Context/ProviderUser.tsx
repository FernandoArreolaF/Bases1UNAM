// Context/ProviderUser.tsx
import { createContext, useState, useContext } from "react";

interface Usuario {
  id: number;
  RFC: string;
  Fecha_Ing: string;
  Curp: string;
  email: string;
  nombre: string;
  Paterno: string;
  Materno: string;
  id_gerente: number;
  clave_sucursal: string;
  tipo: 'Cajero' | 'vendedor' | 'limpieza' | 'seguridad' | 'administrativo';
  Colonia: string;
  Calle: string;
  Numero: number;
  Codigo_Postal: number;
  Estado: string;
}
interface Acceso { validacion: boolean; }

type AuthResponse = [Acceso, Usuario | null];
type UserContextType = {
  data: AuthResponse;
  setData: (data: AuthResponse) => void;
};

const defaultValue: UserContextType = {
  data: [{ validacion: false }, null],
  setData: () => {},
};

const UserContext = createContext<UserContextType>(defaultValue);

// eslint-disable-next-line react-refresh/only-export-components
export const useProviderUser = () => useContext(UserContext);

export const ProviderUser: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<AuthResponse>([{ validacion: false }, null]);

  return (
    <UserContext.Provider value={{ data, setData }}>
      {children}
    </UserContext.Provider>
  );
};
