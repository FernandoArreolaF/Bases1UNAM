import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./page/Home";
import Login from "./page/Login/Login";
import { ProviderUser } from "./Context/ProviderUser";
import Articulos from "./page/Articulos";
import Datos from "./page/Datos";
import Venta from "./page/Venta";

function App() {
  return (
      <ProviderUser>
        <Router>
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/home" element={<Home />} />
            <Route path="/articulos" element={<Articulos/>}/>
            <Route path="/datos" element={<Datos/>}/>
            <Route path="/articulos" element={<Articulos/>}/>
            <Route path="/venta" element={<Venta/>}/>
          </Routes>
        </Router>
      </ProviderUser>
  );
}


export default App;