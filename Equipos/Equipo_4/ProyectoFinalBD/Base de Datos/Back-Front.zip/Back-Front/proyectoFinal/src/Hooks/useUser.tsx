
import { useProviderUser } from "../Context/ProviderUser";

interface Usuario {
  id: number;
  RFC: string;
  Fecha_Ing: string;
  Curp: string;
  email: string;
  nombre: string;
  Paterno: string;
  Materno: string;
  id_gerente: number;
  clave_sucursal: string;
  tipo: 'Cajero' | 'vendedor' | 'limpieza' | 'seguridad' | 'administrativo';
  Colonia: string;
  Calle: string;
  Numero: number;
  Codigo_Postal: number;
  Estado: string;
}

interface Acceso {
  validacion: boolean;
}

type AuthResponse = [Acceso, Usuario | null];

const useUser = () => {
  const { data, setData } = useProviderUser(); // data = [acceso, usuario]

  const addUser = (item: AuthResponse) => {
    setData(item); // ejemplo: addUser([{ acceso: true }, usuario])
  };

  const showUser = (): AuthResponse => {
    return data;
  };

  const eliminateUser = () => {
    setData([{ validacion: false }, null]); // resetea el contexto
  };

  const modificarUser = (updates: Partial<Usuario>) => {
    if (!data[1]) return;
    const updatedUser = { ...data[1], ...updates };
    setData([data[0], updatedUser]);
  };

  const getTipoUsuario = (): Usuario["tipo"] | null => {
    return data[1]?.tipo ?? null;
  };
  const getNombreCompleto = (): string | null => {
  if (!data[1]) return null;
  return `${data[1].nombre} ${data[1].Paterno} ${data[1].Materno}`;
  };
  const getId=(): number|null =>{
    if(!data[1]) return null;
    return data[1].id
  }

  return {
    addUser,
    showUser,
    eliminateUser,
    modificarUser,
    getTipoUsuario,
    getNombreCompleto,
    getId
  };
};

export default useUser;
