import styled from "styled-components";
import useUser from "../../Hooks/useUser";
import { useNavigate } from "react-router-dom";


const FooderCointeiner = styled.div`
    height: 20%;
    display: flex;
    justify-content: center;

`;

const Button = styled.button`
  background-color: #3b82f6;
  color: white;
  padding: 0.75rem 1rem;
  border: none;
  border-radius: 0.5rem;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.2s;
  align-self: center; /* centrar dentro del contenedor padre */
  margin-bottom: 1rem; /* opcional para separar del borde inferior */
  height: auto; /* <--- asegura que no se estire */
  width: fit-content; /* o puedes usar un ancho fijo si prefieres */
  
  &:hover {
    background-color: #2563eb;
  }
`;





const FooderLateral = () => {
  const navigate = useNavigate();
  const { eliminateUser } = useUser();

  const onClick = () => {
    eliminateUser();
    navigate("/");
  };

  return (
    <FooderCointeiner>
      <Button onClick={onClick}>Cerrar Sesión</Button>
    </FooderCointeiner>
  );
};


export default FooderLateral;