import styled from "styled-components";
import NabvarLateral from "../Menu/NabvarLateral";
import useUser from "./../Hooks/useUser"; 
import axios from "axios";
import { useState } from "react";

const MainContainer = styled.div`
  width: 100vw;
  height: 100vh;
  display: flex;
  overflow: hidden;
  flex-direction: row;
  background-color: #1c2c3b;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const ContentContainer = styled.div`
  flex: 1;
  padding: 2rem;
  background-color: rgb(36, 56, 86);
  overflow-y: auto;
  color: #ffffff;

  h1 {
    margin-bottom: 2rem;
    font-size: 2rem;
    text-align: center;
  }
`;

const GridDatos = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
`;

const DatoBox = styled.div`
  background-color: #2e4a6b;
  border-radius: 12px;
  padding: 1rem;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);

  h3 {
    margin-bottom: 0.5rem;
    font-size: 1rem;
    color: #a0d2ff;
  }

  p {
    font-size: 1rem;
    font-weight: 500;
  }
`;
const BotonConectar = styled.button`
  margin-top: 2rem;
  padding: 0.75rem 1.5rem;
  background-color: #4caf50;
  color: white;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  font-size: 1rem;
  transition: background 0.3s;

  &:hover {
    background-color: #45a049;
  }
`;

const formatLabel = (key: string): string =>
  key
    .replace(/_/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());

const Datos = () => {
  const [, usuario] = useUser().showUser();
  const {getId} = useUser();
  const [jefes, setJefes] = useState([]);
  const handleConectarAPI = async () => {
    try {
      const res = await axios.post("http://localhost:8000/jerarquia", {
        id_empleado: getId(),  
      });
      setJefes(res.data);
    } catch (error) {
      console.error("❌ Error:", error);
      alert("❌ Falló la peticion");
    }
  };

  if (!usuario) return null;

  return (
    <MainContainer>
      <NabvarLateral />
      <ContentContainer>
        <h1>Datos del Usuario</h1>
        <GridDatos>
          {Object.entries(usuario)
            .filter(([, valor]) => valor !== null) 
            .map(([clave, valor]) => (
              <DatoBox key={clave}>
                <h3>{formatLabel(clave)}</h3>
                <p>{String(valor)}</p>
              </DatoBox>
            ))}
        </GridDatos>
        <div style={{ textAlign: "center" }}>
          <BotonConectar onClick={handleConectarAPI}>
            Jefes
          </BotonConectar>
        </div>
        {jefes.length > 0 && (
          <>
            <h2 style={{ textAlign: "center", margin: "3rem 0 1.5rem" }}>Jefes Jerárquicos</h2>
            <GridDatos>
              {jefes.map((jefe: any, index) => (
                <DatoBox key={index}>
                  <h3>Clave</h3>
                  <p>{jefe.clave}</p>
                  <h3>Nombre</h3>
                  <p>{jefe.nombre}</p>
                  <h3>Nivel</h3>
                  <p>{jefe.nivel}</p>
                </DatoBox>
              ))}
            </GridDatos>
          </>
        )}
      </ContentContainer>
    </MainContainer>
  );
};

export default Datos;
