import styled from "styled-components";
import HeaderLateral from "./ItemMenu/HeaderLateral";
import MenuLateral from "./ItemMenu/MenuLateral";
import FooderLateral from "./ItemMenu/FooderLateral";

const NewNavbarLateral = styled.nav`
  position: relative;
  height: 100vh;
  width: 10%;
  background-color: #1f2937; /* gris oscuro */
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
`;


const NabvarLateral = () => {
  return (
    <>
        <NewNavbarLateral>
            <HeaderLateral/>
            <MenuLateral/>
            <FooderLateral/>
        </NewNavbarLateral>
    </>
  );
};

export default NabvarLateral;