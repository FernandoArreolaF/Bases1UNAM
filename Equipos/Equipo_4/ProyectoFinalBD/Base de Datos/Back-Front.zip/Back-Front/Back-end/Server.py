from typing import List
import psycopg2
from fastapi import FastAPI
import psycopg2.extras
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class LoginRequest(BaseModel):
    Id_Emp: int
    password: str

class Articulo(BaseModel):
    cod_barras: str
    cantidad: int
class Compra(BaseModel):
    rfc_cliente: str
    id_empleado: int
    id_cajero: int
    articulos: List[Articulo]
class JerarquiaRequest(BaseModel):
    id_empleado: int
class Jefe(BaseModel):
    clave: int
    nombre: str
    nivel: int

@app.get("/")
async def read_root():
    return "Hola, prueba para ver si se actualiza, no, buenas"

def get_connection():
    try:
        connection = psycopg2.connect(
            host='localhost',
            user='admin_dev',
            password='320334489',
            database='proyectofinal',
            port="5432",

        )
        return connection
    except Exception as ex:
        print(ex)

@app.post("/login")
async def login(request: LoginRequest):
    conn = get_connection()
    if not conn:
        return {"error": "Hay una falla de conexión"}

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM sp_validar_empleado(%s, %s);", (request.Id_Emp, request.password))
            resultado = cur.fetchone()
            
            if not resultado:
                return [{"validacion": False}, None]
            autenticacion = resultado.get("validacion", 0) == 1
            if not autenticacion:
                return [{"validacion": False}, None]
            usuario = {
                "id": resultado["n_clave_emp"],
                "RFC": resultado["v_rfc_emp"],
                "Fecha_Ing": str(resultado["d_fecha_ing"]),
                "Curp": resultado["v_curp"],
                "email": resultado["v_email_emp"],
                "nombre": resultado["v_nombre"],
                "Paterno": resultado["v_ap_paterno"],
                "Materno": resultado["v_ap_mat"],
                "id_gerente": resultado["n_empleado_clave_emp"],
                "clave_sucursal": resultado["v_sucursal_clave_suc"],
                "tipo": resultado["v_tipo"],
                "Colonia": resultado["colonia"],
                "Calle": resultado["calle"],
                "Numero": resultado["numero"],
                "Codigo_Postal": resultado["cod_postal"],
                "Estado": resultado["estado"],
            }
            
            return [{"validacion": autenticacion}, usuario]

    except Exception as ex:
        print("❌ Error al ejecutar función:", ex)
        return {"error": "Ocurrió un problema al procesar la solicitud"}
    
    finally:
        conn.close()
    
@app.post("/art")
async def getArt():
    conn = get_connection()
    if not conn:
        return {"error": "Fallo en la conexión a la base de datos"}

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("""
                SELECT 
                    *
                FROM sp_obtener_articulos();
            """)
            resultados = cur.fetchall()

            articulos = []
            for resultado in resultados:

                articulo = {
                    "Codigo de Barras": resultado["cod_barras"],
                    "Nombre": resultado["nombre_art"],
                    "Precio de compra": str(resultado["precio_compra"]),
                    "Precio de venta": resultado["precio_venta"],
                    "Stock": resultado["stock"],
                    "Categoría": resultado["categoria_clave_cat"],
                    "Nombre categoria": resultado["nombre_cat"],
                    "Tipo categoria": resultado["tipo_cat"]
                    
                }
                articulos.append(articulo)

            return articulos
    except Exception as e:
        print("❌ Error al obtener artículos:", e)
        return {"error": "Error al consultar los artículos"}
    finally:
        conn.close()

@app.post("/vent")
async def setVenta(compra: Compra):
    conn = get_connection()
    articulos_json = [
        {
            "cod_barras": art.cod_barras,
            "cantidad": art.cantidad
        }
        for art in compra.articulos
    ]

    import json
    articulos_str = json.dumps(articulos_json)

    rfc = compra.rfc_cliente if compra.rfc_cliente else ' '
    print(compra)
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur: # type: ignore
            cur.execute(
                "SELECT * FROM sp_insertar_venta_completa(%s, %s, %s, %s);",
                (
                    rfc,
                    compra.id_empleado,
                    compra.id_cajero,  # Si tienes cajero diferente, cámbialo aquí
                    articulos_str
                )
            )

            resultado = cur.fetchone()  # si la función retorna algo
            conn.commit() # type: ignore

            return {
                "mensaje": "✅ Venta realizada correctamente",
                "resultado": resultado
            }
    except Exception as ex:
        print("❌ Error al ejecutar función:", ex)
        return {"error": ex}
    
    finally:
        conn.close() # type: ignore

@app.post("/jerarquia", response_model=List[Jefe])
def obtener_jerarquia(request: JerarquiaRequest):
    conn = get_connection()
    if not conn:
        return []

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM sp_obtener_jerarquia(%s);", (request.id_empleado,))
            resultados = cur.fetchall()
            return resultados  # Devuelve una lista de dicts
    except Exception as e:
        print("❌ Error:", e)
        return []
    finally:
        conn.close()