<?php
include 'conexion.php';
$con = conexion();
?>
<!doctype html>
<html lang="es">
  <head>
    <title>EMPLEADOS REGISTRADOS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/pricing/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
  </head>

  <body>

    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
      <h5 class="my-0 mr-md-auto font-weight-normal"><img src="logo.png" style="width: 35px; position: absolute;"> <span style="position: relative; left: 35px;">DITTO TEAM *MUEBLERIA*</span></h5>
      <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="index.php">Registrar empleado</a>
        <a class="p-2 text-dark" href="listar.php">Lista de artículos</a>
        <a class="p-2 text-dark" href="listaEmp.php">Empleados registrados<span class="sr-only">(current)</span></a>
      </nav>
    </div>

    <div class="container px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
      <h1 class="display-4">Empleados registrados</h1>
      <p class="lead">Los supervisores no tienen supervisor</p>
    </div>

    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">No Empleado</th>
                    <th scope="col">Fecha Ingreso</th>
                    <th scope="col">RFC</th>
                    <th scope="col">CURP</th>
                    <th scope="col">Email</th>
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellido Paterno</th>
                    <th scope="col">Apellido Materno</th>
                    <th scope="col">Calle</th>
                    <th scope="col">Colonia</th>
                    <th scope="col">Número edificio/casa</th>
                    <th scope="col">Código Postal</th>
                    <th scope="col">Tipo Empleado (1.Cajero 2.Vendedor 3.Administrativo 4.Seguridad 5.Limpieza)</th>
                    <th scope="col">ID Estado</th>
                    <th scope="col">Supervisor</th>
                    <th scope="col">Tel Sucursal</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $sql = "select * from empleado";
                    $obj = pg_query($con, $sql);
                    $i = 0;
                    while($fila=pg_fetch_array($obj)){
                        $i++;
                ?>
                <tr style="height:150px;">
                    <td scope="col"><?=$i?></td>
                    <td scope="col"><?=$fila[0]?></td>
                    <td scope="col"><?=$fila[1]?></td>
                    <td scope="col"><?=$fila[2]?></td>
                    <td scope="col"><?=$fila[3]?></td>
                    <td scope="col"><?=$fila[4]?></td>
                    <td scope="col"><?=$fila[5]?></td>
                    <td scope="col"><?=$fila[6]?></td>
                    <td scope="col"><?=$fila[7]?></td>
                    <td scope="col"><?=$fila[8]?></td>
                    <td scope="col"><?=$fila[9]?></td>
                    <td scope="col"><?=$fila[10]?></td>
                    <td scope="col"><?=$fila[11]?></td>
                    <td scope="col"><?=$fila[12]?></td>
                    <td scope="col"><?=$fila[13]?></td>
                    <td scope="col"><?=$fila[14]?></td>
                    <td scope="col"><?=$fila[15]?></td>
                </tr>
                <?php
                    }
                ?>
            </tbody>
        </table>

        <footer class="pt-4 my-md-5 pt-md-5 border-top">
            <div class="row">
                <div class="col-12 col-md">
                    <img class="mb-2" src="fiunam.png" alt="" width="30" height="30">
                    <small class="d-block mb-3 text-muted">FACULTAD DE INGENIERIA UNAM</small>
                </div>
            </div>
        </footer>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    </body>
</html>
