<!doctype html>
<html lang="es">
  <head>
    <title>REGISTRAR EMPLEADO</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/pricing/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
  </head>

  <body>

    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
      <h5 class="my-0 mr-md-auto font-weight-normal"><img src="logo.png" style="width: 35px; position: absolute;"> <span style="position: relative; left: 35px;">DITTO TEAM *MUEBLERIA*</span></h5>
      <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="index.php">Registrar empleado<span class="sr-only">(current)</span></a>
        <a class="p-2 text-dark" href="listar.php">Lista artículos</a>
        <a class="p-2 text-dark" href="listaEmp.php">Empleados registrados</a>
      </nav>
    </div>

    <div class="container px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
      <h1 class="display-4">Registrar Empleado</h1>
      <p class="lead">ID ESTADO: <br>1.Aguascalientes 2.Baja California 3. Baja California Sur 4.Campeche 5.Chiapas
        6.Chihuahua 7.Ciudad de México <br>8.Coahuila 9.Colima 10.Durango 11.Estado de México 12.Guanajuato
        13.Guerrero 14.Hidalgo <br>15.Jalisco 16.Michoacán 17.Morelos 18.Nayarit 19.Nuevo León 20.Oaxaca
        21.Puebla <br>22.Querétaro 23.Quintana Roo 24.San Luis Potosí 25.Sinaloa 26.Sonora 27.Tabasco
        28.Tamaulipas <br>29.Tlaxcala 30.Veracruz 31.Yucatán 32.Zacatecas
      </p>
    </div>

    <div class="container">
      <div class="card">
        <div class="card-body">
          <form autocomplete="off" action="index-post.php" method="post">
            <div class="row">
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Núm Empleado (5 caracteres)</label>
                  <input type="tex" name="numEmp" maxlength="5" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Fecha Ingreso (aaaa-mm-dd)</label>
                  <input type="tex" name="fIng" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>RFC (13 caracteres)</label>
                  <input type="tex" name="rfc" class="form-control">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>CURP (18 caracteres)</label>
                  <input type="tex" name="curp" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Email</label>
                  <input type="tex" name="email" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Nombres</label>
                  <input type="tex" name="nombres" class="form-control">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Apellido Paterno</label>
                  <input type="tex" name="apPat" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Apellido Materno (opcional)</label>
                  <input type="tex" name="apMat" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Calle</label>
                  <input type="tex" name="calle" class="form-control">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Colonia</label>
                  <input type="tex" name="col" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Número edificio/casa</label>
                  <input type="tex" name="num" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Código Postal (5 caracteres)</label>
                  <input type="tex" name="cPos" class="form-control">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Tipo Empleado (1.Cajero 2.Vendedor 3.Administrativo 4.Seguridad 5.Limpieza)</label>
                  <input type="tex" name="tipo" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Id Estado (checar lista)</label>
                  <input type="tex" name="idEdo" class="form-control">
                </div>
              </div>
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Núm Empleado Supervisor (Sólo no supervisores)</label>
                  <input type="tex" name="numEmpS" class="form-control">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-4 col-4">
                <div class="form-group">
                  <label>Teléfono de Sucursal (10 dígitos)</label>
                  <input type="tex" name="telSuc" class="form-control">
                </div>
              </div>
            </div>
            <input type="submit" class="btn btn-primary float-right" value="Registrar">
          </form>
        </div>
      </div>

      <footer class="pt-4 my-md-5 pt-md-5 border-top">
        <div class="row">
          <div class="col-12 col-md">
            <img class="mb-2" src="fiunam.png" alt="" width="30" height="30">
            <small class="d-block mb-3 text-muted">FACULTAD DE INGENIERIA UNAM</small>
          </div>
        </div>
      </footer>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
  </body>
</html>
