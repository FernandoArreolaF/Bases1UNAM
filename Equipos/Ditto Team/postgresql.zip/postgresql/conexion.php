<?php 
function conexion(){
	$host = "host=localhost";
	$port = "port=5432";
	$dbname = "dbname=postgres";
	$user = "user=postgres";
	$password = "password=123";

	$db = pg_connect("$host $port $dbname $user $password");

	/*if($db){
		echo "exito";
	}else{
		echo "error";
	}*/

	return $db;
}
//echo conexion();
?>