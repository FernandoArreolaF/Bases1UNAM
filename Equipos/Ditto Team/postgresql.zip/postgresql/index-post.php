<?php
include("conexion.php");
$con = conexion();

$numEmp = $_POST["numEmp"];
$fIng = $_POST["fIng"];
$rfc = $_POST["rfc"];
$curp = $_POST["curp"];
$email = $_POST["email"];
$nombres = $_POST["nombres"];
$apPat = $_POST["apPat"];
$apMat = $_POST["apMat"];
$calle = $_POST["calle"];
$col = $_POST["col"];
$num = $_POST["num"];
$cPos = $_POST["cPos"];
$tipo = $_POST["tipo"];
$idEdo = $_POST["idEdo"];
$numEmpS = $_POST["numEmpS"];
$telSuc = $_POST["telSuc"];
echo $numEmp;
if(strlen($numEmp)==5){
    if(strlen($rfc)==13){
        if(strlen($curp)==18){
            if(strlen($cPos)==5){
                if(strlen($telSuc)==10){
                    if($numEmpS==''){
                        $numEmpS = 'default';
                        $sql = "insert into empleado values('$numEmp','$fIng','$rfc','$curp','$email','$nombres','$apPat','$apMat','$calle','$col','$num','$cPos','$tipo','$idEdo',$numEmpS,'$telSuc')";
                        pg_query($con, $sql);
                        header("location:index.php");
                    }else{
                        $sql = "insert into empleado values('$numEmp','$fIng','$rfc','$curp','$email','$nombres','$apPat','$apMat','$calle','$col','$num','$cPos','$tipo','$idEdo','$numEmpS','$telSuc')";
                        pg_query($con, $sql);

                    header("location:index.php");
                    }
                    $sql = "insert into empleado values('$numEmp','$fIng','$rfc','$curp','$email','$nombres','$apPat','$apMat','$calle','$col','$num','$cPos','$tipo','$idEdo','$numEmpS','$telSuc')";
                    pg_query($con, $sql);

                    header("location:index.php");
                } else {
                    echo "El teléfono de la sucursal debe ser de tamaño 10";

                }  
            }else{
                echo "El código postal debe ser de tamaño 5";
            }
        }else{
            echo "El curp debe ser de tamaño 18";
        }
    }else{
        echo "El rfc debe ser de tamaño 13";
    }
}else{
    echo "El número de empleado debe ser de tamaño 5";

}

?>