<?php
$var = "000000000001";
$var2 = "ImgArt/".$var.".png";
echo $var2;
?>