-- Script de toda la programación a nivel BD
---INTEGRANTES:
--Alvarez Badillo Rodrigo
--Mondragón Hernández Andrea Quetzalli
--Montes Cantero Zelene Yosseline Isayana
--Pineda González Rodrigo
--Segura Garduño Karen Alin
-- PROFESOR: ING. FERNANDO ARREOLA
-- BASES DE DATOS, GRUPO 1, SEMESTRE 2022-2

--Creacion de la base de datos 
create database restaurante;

--Conectarse a la base de datos PROYECTOBD
\c restaurante;


---Creación de tablas

--CREACION TABLA categoria

CREATE TABLE categoria(
    id_categoria smallint NOT NULL,
    nombre_categoria character varying(50) NOT NULL,
    descripcion_categoria character varying(300) NOT NULL,
    CONSTRAINT categoria_pk PRIMARY KEY (id_categoria)
);

---CREACIÓN TABLA cliente

CREATE TABLE cliente(
    rfc_cliente character varying(13) NOT NULL,
    nombre_cliente character varying(50) NOT NULL,
    apellido_paterno character varying(30) NOT NULL,
    apellido_materno character varying(30),
    razon_social character varying(50) NOT NULL,
    estado character varying(30) NOT NULL,
    codigo_postal integer NOT NULL,
    colonia character varying(50) NOT NULL,
    calle character varying(50) NOT NULL,
    numero smallint NOT NULL,
    email character varying(30) NOT NULL,
    fecha_nacimiento date NOT NULL,
    CONSTRAINT cliente_pk PRIMARY KEY (rfc_cliente)
);

---CREACIÓN TABLA empleado

CREATE TABLE empleado(
    no_empleado smallint NOT NULL,
    rfc character varying(13) NOT NULL,
    sueldo smallint NOT NULL,
    edad smallint NOT NULL,
    fecha_nacimiento date NOT NULL,
    numero smallint NOT NULL,
    calle character varying(50) NOT NULL,
    colonia character varying(50) NOT NULL,
    codigo_postal integer NOT NULL,
    estado character varying(30) NOT NULL,
    nombre_empleado character varying(70) NOT NULL,
    apellido_paterno character varying(70) NOT NULL,
    apellido_materno character varying(70),
    foto bytea,
    es_cocinero boolean NOT NULL,
    especialidad character varying(100),
    es_mesero boolean NOT NULL,
    horario character varying(20),
    es_administrativo boolean NOT NULL,
    rol character varying(100),
    CONSTRAINT empleado_pk PRIMARY KEY (no_empleado)
);

---CREACIÓN TABLA dependiente

CREATE TABLE dependiente(
    curp character varying(18) NOT NULL,
    parentesco character varying(10) NOT NULL,
    nombre_dependiente character varying(70) NOT NULL,
    apellido_paterno character varying(70) NOT NULL,
    apellido_materno character varying(70),
    no_empleado smallint NOT NULL,
    CONSTRAINT dependiente_pk PRIMARY KEY (curp),
    CONSTRAINT dependiente_empleado_fk FOREIGN KEY (no_empleado)
    REFERENCES empleado (no_empleado)
    ON DELETE CASCADE on update cascade
);

---CREACIÓN TABLA telefono
CREATE TABLE telefono(
    telefono bigint NOT NULL,
    no_empleado smallint NOT NULL,
    CONSTRAINT telefono_pk PRIMARY KEY (telefono),
    CONSTRAINT telefono_empleado_fk FOREIGN KEY (no_empleado)
    REFERENCES empleado (no_empleado)
    ON DELETE CASCADE on update cascade
);

---CREACIÓN TABLA producto

CREATE TABLE producto(
    id_producto smallint NOT NULL,
    nombre_producto character varying(70) NOT NULL,
    disponibilidad smallint,
    precio money,
    receta character varying(3000) NOT NULL,
    descripcion character varying(700) NOT NULL,
    id_categoria smallint NOT NULL,
    CONSTRAINT producto_pk PRIMARY KEY (id_producto),
    CONSTRAINT producto_categoria_fk FOREIGN KEY (id_categoria)
    REFERENCES categoria (id_categoria)
    ON DELETE CASCADE on update cascade,
    CONSTRAINT producto_disponibilidad_chk CHECK (disponibilidad >= 0)
);

---CREACIÓN TABLA orden
CREATE TABLE orden(
    folio_orden character varying(7) NOT NULL,
    pago money,
    fecha character varying NOT NULL,
    no_empleado smallint NOT NULL,
    rfc_cliente character varying(13) NOT NULL,
    CONSTRAINT orden_pk PRIMARY KEY (folio_orden),
    CONSTRAINT orden_empleado_fk FOREIGN KEY (no_empleado)
    REFERENCES empleado (no_empleado)
    ON DELETE CASCADE on update cascade,
    CONSTRAINT orden_cliente_fk FOREIGN KEY (rfc_cliente)
    REFERENCES cliente (rfc_cliente)
    ON DELETE CASCADE on update cascade
);

---CREACIÓN TABLA orden
CREATE TABLE contiene(
    folio_orden character varying(7) NOT NULL,
    id_producto smallint NOT NULL,
    cantidad smallint NOT NULL,
    precio_total money,
    CONSTRAINT contiene_pk PRIMARY KEY (folio_orden, id_producto),
    CONSTRAINT contine_orden_fk FOREIGN KEY (folio_orden)
    REFERENCES orden (folio_orden)
    ON DELETE CASCADE on update cascade, 
    CONSTRAINT contiene_producto_fk FOREIGN KEY (id_producto)
    REFERENCES producto (id_producto)
    ON DELETE CASCADE on update cascade
);


---CREACIÓN DE INDICE

--Indice en la columna disponibilidad en la tabla producto

CREATE INDEX disponibilidad_index
ON producto(disponibilidad);

-- V I S T A S

--Factura
CREATE VIEW v_factura
AS
SELECT ord.folio_orden, ord.pago,
cl.rfc_cliente,
cl.razon_social, 
ord.fecha
FROM  cliente cl, orden ord
WHERE ord.rfc_cliente=cl.rfc_cliente
ORDER BY folio_orden ASC;

--Disponibilidad
CREATE VIEW v_disponibilidad
AS
SELECT nombre_producto 
FROM producto
WHERE disponibilidad = '0';

--Monto-Total
CREATE VIEW monto_total 
AS
SELECT sum (cantidad) 
AS total_ventas, 
sum(precio_total) AS monto_total 
FROM contiene 
JOIN orden 
USING(folio_orden)
WHERE fecha= '07/04/2022';

--Producto mas vendido
CREATE VIEW suma_Productos as 
SELECT sum(cantidad) AS total_productos_vendidos, pro.id_producto 
FROM contiene co, producto pro 
GROUP BY co.id_producto, pro.id_producto 
HAVING co.id_producto=pro.id_producto; 

CREATE VIEW v_platillo_mas_vendido as 
SELECT * FROM producto
WHERE id_producto in ( SELECT s.id_producto 
FROM suma_Productos s, producto prod 
WHERE s.id_producto=prod.id_producto 
AND total_productos_vendidos=(SELECT max(total_productos_vendidos) 
 FROM suma_Productos));

--Fecha
CREATE VIEW v_fecha AS
SELECT DISTINCT fecha
FROM orden
ORDER BY fecha;

--No Empleado
CREATE VIEW v_no_empleado AS
SELECT no_empleado
FROM empleado
ORDER BY no_empleado;


--SECUENCIA
CREATE SEQUENCE folio_orden_sequence
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 500
	OWNED BY orden.folio_orden;

--Disparadores que se encarga de modificar la disponibilidad de los productos

--Disparador al hacer un INSERT
CREATE FUNCTION disponibilidad_productos()
RETURNS TRIGGER AS $producto$
	DECLARE cantidad_disponible smallint;
	BEGIN
		cantidad_disponible=disponibilidad FROM producto 
		WHERE producto.id_producto=NEW.id_producto;
		IF(cantidad_disponible<NEW.cantidad) THEN
			RAISE EXCEPTION 'No hay productos disponibles';
		ELSIF(cantidad_disponible>=NEW.cantidad) THEN 
			UPDATE producto SET 
			disponibilidad=disponibilidad-NEW.cantidad
			WHERE id_producto=NEW.id_producto;
			RETURN NEW;
			END IF;
			RETURN NULL;
	END;
$producto$ LANGUAGE plpgsql;

CREATE TRIGGER disponibilidad_productos BEFORE INSERT ON 
contiene FOR EACH ROW EXECUTE PROCEDURE disponibilidad_productos();

--Disparador al hacer un UPDATE
CREATE FUNCTION disponibilidad_productos_update()
RETURNS TRIGGER AS $producto$
	DECLARE cantidad_disponible smallint;
	BEGIN
		cantidad_disponible=disponibilidad FROM producto 
		WHERE producto.id_producto=NEW.id_producto;
		IF(NEW.cantidad>OLD.cantidad) THEN 
			UPDATE producto SET 
			disponibilidad=disponibilidad-(NEW.cantidad-OLD.cantidad) 
			WHERE id_producto=NEW.id_producto;
			RETURN NEW;
		ELSIF(NEW.cantidad<OLD.cantidad) THEN  
			UPDATE producto SET 
			disponibilidad=disponibilidad+(OLD.cantidad-NEW.cantidad)
			WHERE id_producto=NEW.id_producto;
			RETURN NEW;
			END IF;
			RETURN NULL;
	END;
$producto$ LANGUAGE plpgsql;

CREATE TRIGGER disponibilidad_productos_update AFTER UPDATE ON 
contiene FOR EACH ROW EXECUTE PROCEDURE disponibilidad_productos_update();

--Disparador al hacer un DELETE
CREATE FUNCTION disponibilidad_productos_delete()
RETURNS TRIGGER AS $producto$
	DECLARE cantidad_disponible smallint;
	BEGIN
	UPDATE producto SET 
	disponibilidad=disponibilidad+OLD.cantidad  
	WHERE id_producto=OLD.id_producto;
	RETURN OLD;
	END;
$producto$ LANGUAGE plpgsql;

CREATE TRIGGER disponibilidad_productos_delete AFTER DELETE ON 
contiene FOR EACH ROW EXECUTE PROCEDURE disponibilidad_productos_delete();

--Disparador para modificar el precio por producto al insertar en la tabla contiene
CREATE FUNCTION calculo_pago_produto()
RETURNS TRIGGER AS $calculo_pago_produto$
	DECLARE 
    pago_nuevo_product money;
    nuevo_pago money;
	BEGIN

        IF(TG_OP='INSERT') THEN 
            pago_nuevo_product= precio
            FROM producto pro
            WHERE pro.id_producto=NEW.id_producto; 
			UPDATE contiene SET 
			precio_total=(pago_nuevo_product*NEW.cantidad)
			WHERE folio_orden=NEW.folio_orden
			AND
			id_producto=NEW.id_producto;
			RETURN NEW;
        ELSIF(TG_OP='UPDATE') THEN 
            IF(NEW.cantidad!=OLD.cantidad) THEN
                nuevo_pago= precio
                FROM producto pro
                WHERE pro.id_producto=OLD.id_producto;
                UPDATE contiene SET 
                precio_total=(nuevo_pago*NEW.cantidad)
                WHERE folio_orden=OLD.folio_orden
                AND
                id_producto=OLD.id_producto;
                RETURN NEW;
                END IF;
        END IF;
		RETURN NULL;
	END;
$calculo_pago_produto$ LANGUAGE plpgsql;

CREATE TRIGGER calculo_pago_produto AFTER INSERT OR UPDATE ON 
contiene FOR EACH ROW EXECUTE PROCEDURE calculo_pago_produto();

--Disparador para modificar el pago de las ordenes
CREATE FUNCTION calculo_pago()
RETURNS TRIGGER AS $orden$
	DECLARE 
	pago_nuevo money;
	BEGIN
		pago_nuevo= sum(precio_total) FROM contiene
		GROUP BY folio_orden
		HAVING folio_orden=NEW.folio_orden;
			UPDATE orden SET 
			pago=pago_nuevo
			WHERE folio_orden=NEW.folio_orden;
		RETURN NEW;
	END;
$orden$ LANGUAGE plpgsql;

CREATE TRIGGER calculo_pago AFTER INSERT OR UPDATE ON 
contiene FOR EACH ROW EXECUTE PROCEDURE calculo_pago();


--DISPARADOR FORMATO ID TABLA ORDEN 
CREATE FUNCTION formato_id_orden()
RETURNS TRIGGER AS $formato_id_orden$
	DECLARE 
	stri1 text;
	stri2 text;
	stri3 text; 
	BEGIN
		IF(CAST(NEW.folio_orden AS int)<10) THEN
			stri1='ORD-00'||NEW.folio_orden;
			UPDATE orden SET 
			folio_orden=stri1
			WHERE folio_orden=NEW.folio_orden;
			RETURN NEW;
		ELSIF(CAST(NEW.folio_orden AS int)>9 AND CAST(NEW.folio_orden AS int)<99 ) THEN 
			stri2='ORD-0'||NEW.folio_orden;
			UPDATE orden SET 
			folio_orden=stri2
			WHERE folio_orden=NEW.folio_orden;
			RETURN NEW;
		ELSIF(CAST(NEW.folio_orden AS int)>99) THEN 
			stri3='ORD-'||NEW.folio_orden;
			UPDATE orden SET 
			folio_orden=stri3
			WHERE folio_orden=NEW.folio_orden;
			RETURN NEW;
			END IF;
			RETURN NULL;
	END;
$formato_id_orden$ LANGUAGE plpgsql;


CREATE TRIGGER formato_id_orden AFTER INSERT ON 
orden FOR EACH ROW EXECUTE PROCEDURE formato_id_orden();



--VERIFICACION QUE SEA MESERO
--Disparador al hacer un INSERT
CREATE FUNCTION verificar_mesero()
RETURNS TRIGGER AS $verificar_mesero$
	Declare
	validacion boolean;
	BEGIN
	validacion = es_mesero FROM empleado WHERE no_empleado = NEW.no_empleado;
		IF(validacion = 'false') THEN
			RAISE EXCEPTION 'NO es mesero, no puede tomar ordenes.';
		END IF;
			RETURN NEW;
	END;
$verificar_mesero$ LANGUAGE plpgsql;

CREATE TRIGGER verificar_mesero BEFORE INSERT ON 
orden FOR EACH ROW EXECUTE PROCEDURE verificar_mesero();

--Disparador para modificar el pago al borar orden en la tabla contiene
CREATE FUNCTION calculo_pago_delete()
RETURNS TRIGGER AS $orden$
	DECLARE 
	pago_delete money;
	BEGIN
		pago_delete= sum(precio_total) FROM contiene
		GROUP BY folio_orden
		HAVING folio_orden=OLD.folio_orden;
			UPDATE orden SET 
			pago=pago_delete
			WHERE folio_orden=OLD.folio_orden;
		RETURN OLD;
	END;
$orden$ LANGUAGE plpgsql;

CREATE TRIGGER calculo_pago_delete AFTER DELETE ON 
contiene FOR EACH ROW EXECUTE PROCEDURE calculo_pago_delete();

---FUNCION 
CREATE FUNCTION formato_id_orden_delete(stri1 text)
RETURNS text AS $$
    DECLARE
    formato text;
	BEGIN
		IF(CAST(stri1 AS int)<10) THEN
			formato='ORD-00'||stri1;
			RETURN formato;
		ELSIF(CAST(stri1 AS int)>9 AND CAST(stri1 AS int)<99 ) THEN 
			formato='ORD-0'||stri1;
			RETURN formato;
		ELSIF(CAST(stri1 AS int)>99) THEN 
			formato='ORD-'||stri1;
			RETURN formato;
			END IF;
			RETURN NULL;
	END;
$$ LANGUAGE plpgsql;

-- Inserts
--E M P L E A D O
INSERT INTO empleado(
	no_empleado, rfc, sueldo, edad, fecha_nacimiento, numero, calle, colonia, codigo_postal, estado, nombre_empleado, apellido_paterno, apellido_materno,foto,es_cocinero, especialidad, es_mesero, horario, es_administrativo, rol)
	VALUES ('1', 'MOLJ650522XH9','10000','25','01/02/1997','20','Bailen','Tlatelolco','13900','Mexico','Hugo','Antunez', 'Diaz',pg_read_binary_file('C:\FotosBD\F1.jpg'), '0',' ','1','Matutino','0',' ');

INSERT INTO empleado(
	no_empleado, rfc, sueldo, edad, fecha_nacimiento, numero, calle, colonia, codigo_postal, estado, nombre_empleado, apellido_paterno, apellido_materno,foto, es_cocinero, especialidad,es_mesero, horario, es_administrativo, rol)
	VALUES ('2', 'LOZJ491234LJ9','15000','30','20/06/1971','222','Bulevar','Polanco','5603','Mexico','Leonardo','Alvarez', 'Chavez',pg_read_binary_file('C:\FotosBD\F2.jpg'), '1','Panaderia y pasteleria','0',' ','0',' ');

INSERT INTO empleado(
	no_empleado, rfc, sueldo, edad, fecha_nacimiento, numero, calle, colonia, codigo_postal, estado, nombre_empleado, apellido_paterno, apellido_materno,foto, es_cocinero, especialidad, es_mesero, horario, es_administrativo, rol)
	VALUES ('3', 'AMHT123498PO6','6000','40','25/02/1961','9','Camino', 'Del Carmen','5489','Mexico','Valeria','Marin', 'Mondragon',pg_read_binary_file('C:\FotosBD\F3.jpg'),'0',' ','0',' ','1','Interpersonales');

INSERT INTO empleado(
	no_empleado, rfc, sueldo, edad, fecha_nacimiento, numero, calle, colonia, codigo_postal, estado, nombre_empleado, apellido_paterno,foto,es_cocinero, especialidad, es_mesero, horario, es_administrativo, rol)
	VALUES ('4', 'VALE328511HM1','15000','29','04/08/1992','69','Orizaba','Benito Juarez','03100','Ciudad de Mexico','Cole','Sprouse', pg_read_binary_file('C:\FotosBD\F4.jpg') ,'1','Cortes de carne','1','Vespertino','0',' ');

INSERT INTO empleado(
	no_empleado, rfc, sueldo, edad, fecha_nacimiento, numero, calle, colonia, codigo_postal, estado, nombre_empleado, apellido_paterno,foto,es_cocinero, especialidad, es_mesero, horario, es_administrativo, rol)
	VALUES ('5', 'XIAO312001HG9','20000','23','08/08/1998','81','Sierra Hermosa','Santa Lucia','55749','Mexico','Shawn','Mendes', pg_read_binary_file('C:\FotosBD\F5.jpg') ,'0','','1','Matutino','1','Jefe de piso');

--D E P E N D I E N T E
INSERT INTO dependiente(
	curp, parentesco, nombre_dependiente, apellido_paterno, apellido_materno, no_empleado)
	VALUES ('MOHG010418MDFNRNA5','hijo','Gabriel', 'Mondragon', 'Hernandez', '3');
	
INSERT INTO dependiente(
	curp, parentesco, nombre_dependiente, apellido_paterno, apellido_materno, no_empleado)
	VALUES ('MAHS010418MDFTRNA5','hijo','Santiago', 'Martinez', 'Hernandez', '1');
	
INSERT INTO dependiente(
	curp, parentesco, nombre_dependiente, apellido_paterno, apellido_materno, no_empleado)
	VALUES ('MOCA010418MDFVRNA5','hija','Andrea', 'Morales', 'Ordoñez', '2');


--T E L E F O N O
INSERT INTO telefono(
	telefono, no_empleado)
	VALUES ('5548483498', '1');

INSERT INTO telefono(
	telefono, no_empleado)
	VALUES ('5539124056', '2');

INSERT INTO telefono(
	telefono, no_empleado)
	VALUES ('5524259871', '3');

INSERT INTO telefono(
	telefono, no_empleado)
	VALUES ('5536985214', '4');

INSERT INTO telefono(
	telefono, no_empleado)
	VALUES ('5578945612', '5');


--C L I E N T E 

INSERT INTO cliente(
	rfc_cliente, nombre_cliente, apellido_paterno, apellido_materno, razon_social, estado, codigo_postal, colonia, calle, numero, email, fecha_nacimiento)
	VALUES ('QUMA470929F37', 'Diego', 'Arroyo', 'Pineda', 'Bimbo', 'Mexico', '14300','Juares', 'Roche Sur', 7, 'diego@gmail.com', '19/02/1990');

INSERT INTO cliente(
	rfc_cliente, nombre_cliente, apellido_paterno, apellido_materno, razon_social, estado, codigo_postal, colonia, calle, numero, email, fecha_nacimiento)
	VALUES ('ANDA690929G37', 'Andrea', 'Mondragon', 'Hernandez', 'Ferrari', 'Mexico', '14700','Roma', 'Rio Danubio', 14, 'andrea@gmail.com', '18/04/1995');

INSERT INTO cliente(
	rfc_cliente, nombre_cliente, apellido_paterno, apellido_materno, razon_social, estado, codigo_postal, colonia, calle, numero, email, fecha_nacimiento)
	VALUES ('HIRA200929Z39', 'Hiram', 'Gomez', 'Rodrigez', 'Inbursa', 'Mexico', '14300','Polanco', 'Amberes', 200, 'hiram@gmail.com', '20/09/1998');

INSERT INTO cliente(
	rfc_cliente, nombre_cliente, apellido_paterno, apellido_materno, razon_social, estado, codigo_postal, colonia, calle, numero, email, fecha_nacimiento)
	VALUES ('EUP9609207K4', 'Miguel', 'Mondragon', 'Roldan', 'Enfermeros Unidos', 'Mexico', '5574','Sierra Hermosa', 'Santa Lucia', '27', 'miguelmondragon@gmail.com', '06/11/1973');

INSERT INTO cliente(
	rfc_cliente, nombre_cliente, apellido_paterno, apellido_materno, razon_social, estado, codigo_postal, colonia, calle, numero, email, fecha_nacimiento)
	VALUES ('BIM9609207K4', 'Gabriela', 'Hernandez', 'Mendez','BIMBO', 'Mexico','55749', 'Rancho Nuevo', 'Libertad', '15', 'gabrielahernadez@gmail.com', '14/03/1978');

INSERT INTO cliente(
	rfc_cliente, nombre_cliente, apellido_paterno, apellido_materno, razon_social, estado, codigo_postal, colonia, calle, numero, email, fecha_nacimiento)
	VALUES ('BSM970519DU8', 'Yasmin', 'Carmona', 'Ordoñez','SANTANDER', 'Mexico', '15460', 'Venustiano Carranza', 'calle A', '10', 'yasmincarmona@gmail.com', '11/01/2001');


--C A T E G O R I A

INSERT INTO categoria(
	id_categoria, nombre_categoria, descripcion_categoria)
	VALUES ('1', 'Bebida', 'Líquidos de diferentes sabores mostrados en presentaciones como agua de sabor, gaseosa, vino y cerveza.');

INSERT INTO categoria(
	id_categoria, nombre_categoria, descripcion_categoria)
	VALUES ('2', 'Comida', 'Platillos variados para desayuno, comida y cena.');


--P R O D U C T O
INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('123', 'Limonada', '40', '25', '1.Vacía dos tazas de agua y el azúcar  a la licuadora. Muele por 15 segundos o hasta que el azúcar se haya disuelto completamente en el agua. Este es un paso importante ya que si añades el azúcar después tardará mucho en disolverse y tendrás que revolver por mucho tiempo.2.Añade los limones y licúa por 5 segundos y no más. 3.Cuela la mezcla en la jarra con el resto del agua, revuelve. Sirve con hielo y rodajas de limón, si lo deseas.', 'Agua fresca del limon', '1');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('639','Chilaquiles','40','60','1.Para preparar las tortillas:2.Precalienta el horno a 150 C. Corta las tortillas en pedazos de 5 cm, úntalas ligeramente con aceite y espolvoréalas con sal. Ponlas en una charola y hornéalas de 15 a 20 minutos, hasta que se tuesten. Deja que se enfríen. También puedes freír los pedazos de tortilla en aceite.Para preparar la salsa de tomate:3.Precalienta el horno a 175 C. Pon los tomates verdes, la cebolla, el ajo y los chiles serranos en un recipiente. Añade una cucharada de aceite aprox. y úntalo sobre todos los ingredientes hasta que todos tengan una capa ligera de aceite. Pon todo en una charola para hornear y espolvorea con sal.4.Hornea hasta que los tomates estén suaves y todos los ingredientes se vean un poco quemados. Pon todo en una licuadora con el cilantro y el caldo y licua perfectamente.5.Calienta la cucharada adicional de aceite en un sartén a fuego medio. Cuando el aceite esté caliente, añade la salsa licuada y termina de cocinar a fuego medio durante unos10 minutos. Sazona al gusto.','Platillo consistente en tortillas de maíz cortadas, fritas y cocinadas en salsa.', '2');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('789','Agua de Horchata','40','30','1.Remoja en agua hirviendo el arroz y espera a que enfrié. 2.En una cacerola hierve 2 tazas de agua con las 4 rajas de canela, déjala enfriar. 3.Licúa el arroz con todo y agua, el agua con canela y un pedazo de ella.4.Utiliza un colador de malla fina para pasar lo licuado a una jarra grande. Incorpora leche al gusto hasta lograr la consistencia deseada.5.Agrega de 2 a 3 litros de agua más y revuelve con azúcar al gusto. Al final agrega hielos.','Bebida refrescante tradicional de amplio consumo.', '1');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('369','Cafe de olla','0','20','1.Combine el agua, el piloncillo, las ramas de canela, el anís y los clavos en una cacerola mediana. Calienta a fuego medio-alto, revolviendo ocasionalmente.2.Reduzca el fuego a bajo, tape y cocine por 15 minutos. Retire del fuego, agregue los gránulos de café, cubra y deje reposar durante 5 minutos. 3.Caliente la leche evaporada en una cacerola pequeña a fuego medio-alto. Batir constantemente hasta que la leche esté espumosa y empiece a hervir. Retírelo del calor.4.Cuela el café a través de un colador fino en tazas individuales. Sirve inmediatamente con leche espumosa a un lado','Café caliente con un toque de canela.','1');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('147','Quesadilla de queso','40','15','1.Parte o ralla el queso de su referencia en pequeñas tiritas.3.Extiende en la mitad de la tortilla y poner la cantidad al gusto del ques y dóblala sobre sí misma para que quede tapada.4.En una sartén a fuego medio-fuerte, pon la quesadilla para que se cocine por un lado, y cuando se haya tostado ligeramente, dale la vuelta con cuidado para que se cocine por el otro lado.','Platillo consistente en tortillas de maíz cortadas, fritas y cocinadas en salsa.', '2');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('951','Molletes','40','20','1.Untar todas las mitads de bolillo con los frijoles refritos.2.Agregar rebanadas de queso manchego hasta cubrir los frijoles.3.Meter al horno de microondas durante 1 minuto o hasta gratinar perfectamente.4.Agregar la salsa pico de gallo.','Platillo con base de bolillo tostado y varios ingredientes salados o dulces. Se preparan haciendo un corte longitudinal a un bolillo, tomando cada mitad y poniéndola en el comal o en el horno para calentarlo y tostarlo.', '2');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('235','Agua de mango','25','45','1.Coloca el azúcar, el agua y los mangos pelados y picados en tu licuadora. 2.Procesa hasta que tengas una textura fina y suave. 3.Vierta en una jarra grande y agrega los cubitos de hielo. 4.Prueba para comprobar la dulzura.','Refrescante agua sabor mango', '1');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('852','Té helado','15','10','1. Preparar el té de la manera habitual poniendo solamente la mitad del agua.2.Es importante  como en todos los tés respetar los tiempos de infusión. No intentes alargar la infusión para conseguir más sabor. 3.Una vez tenemos nuestra infusión concentrada, es el momento de endulzar el té ( si es que lo quieres así). Si lo haces con el té frío, te costará mas disolver el azúcar/edulcorante. 4.Pon hielo, así conseguiremos enfríar nuestra infusión sin que quede aguada.', 'Cuenta con gotas de limón y hojas de menta, adquiere un sabor muy fresco que permanece en la boca.','1');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('192','Gin-tonic','0','35','1.En un vaso alto con abundante hielo, se mezclan partes iguales de ginebra y de agua tónica. 2.Se agregan unas gotas de limón y está listo (la presentación habitual lo muestra con rodajas de limón en el borde del vaso).','Bebida con historia, tradicional y siempre de moda se le agrega rodajas de pepino, arándanos, grosellas, jugo de naranja o miel la bebida cambia levemente.' ,'1');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('358','Granizados de frutas','36','10','1.Licuar medio vaso (del que se usará para servir la bebida) de la fruta en trozos, medio vaso de hielo, unas gotitas de limón. 2.El hielo se granizará y se impregnará de las frutas; puede endulzarse con azúcar o estevia.3.Servir los granizados en un vaso rústico tipo frasco le da una presentación muy moderna. Acompañar con una pajita y una varilla para revolver.','Frutas del verano para crear bebidas refrescantes es una sugerencia muy práctica.', '1');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('820','Café frappé','40','20','1.El café frappé se prepara en base a café expreso, al que se le agrega leche fría o agua helada. 2.Se mezclan los ingredientes en una coctelera y se sirve sobre hielo granizado. 3.Un toque de chocolate rallado sobre la espuma, ya en el vaso, le dará una presentación muy apetecible.', 'Típica bebida invernal, se transforma en una extraordinaria bebida refrescante.','1');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('150','Crema de elote','21','35','1.En una cacerola derrite la mantequilla y fríe la harina hasta que dore ligeramente. Incorpora la cebolla y la mitad de la Leche Evaporada.2.Licúa los granos de elote con el agua, el resto de la Leche Evaporada, el queso crema, el consomé de pollo y calienta hasta que espese ligeramente.','Crema de elote con toques de maiz', '2');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('315','Pozole','30','40','1.Calienta los 5 litros agua con ½ cebolla, 4 dientes de ajo y la sal. 2.Añade la costilla, la pulpa de cerdo y el laurel; cocina hasta que la carne esté suave.3.Licúa los chiles con 2 tazas de agua, ¼ de cebolla, 2 dientes de ajo, el comino y la pimienta, cuela y vierte en la olla del maíz; cocina por 30 minutos más.','Platillo con granos de maiz con un toque de picante', '2');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('959','Enfrijoladas','12','35',	'1.Licue los frijoles de la olla con un poco de su caldo y el chile chipotle. 2.Caliente una cacerola con la manteca y cuando humee vierta los frijoles molidos.Al final deberá obtener una salsa ligeramente espesa.3.Caliente el aceite y pase dentro de él las tortillas una a una por unos segundos, sólo para que se suavicen.','Tortillas bañadas con salsa de frijol', '2');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('225','Tinga','40','20','1.Licúa la cebolla con el ajo, los jitomates, el chile chipotle, el Concentrado de Tomate y caldo de pollo.2.Calienta el aceite, agrega la cebolla y cocina hasta que esté ligeramente transparente. 3.Añade la pechuga de pollo y la preparación de jitomate, mezcla y cocina por 10 minutos a fuego bajo o hasta que espese ligeramente.','Platillo de pollo desmenusado con chile chipotle', '2');

INSERT INTO producto(
	id_producto, nombre_producto, disponibilidad, precio, receta, descripcion, id_categoria)
	VALUES ('520','Calabazas rellenas','0','25','1.Retira el relleno a las calabazas, cortalo en cubos y mezcla con el jamón; rellena las calabazas con la preparación anterior y cubre con una rebanada de queso tipo manchego.2.Colócalas en una sartén sin aceite, previamente precalentada a fuego bajo durante 1 minuto, cocina a fuego bajo de 7 a 8 minutos por cada lado o hasta que esten bien cocidas.',	'Calabazas rellenas con queso y jamón', '2');


---O R D E N 
INSERT INTO orden(
	folio_orden, fecha, no_empleado, rfc_cliente)
	VALUES (nextval('folio_orden_sequence'), '07/4/2022', '1', 'EUP9609207K4');
	
INSERT INTO orden(
	folio_orden, fecha, no_empleado, rfc_cliente)
	VALUES (nextval('folio_orden_sequence'), '07/4/2022', '1', 'BIM9609207K4');
		
INSERT INTO orden(
	folio_orden, fecha, no_empleado, rfc_cliente)
	VALUES (nextval('folio_orden_sequence'), '08/4/2022', '1', 'BSM970519DU8');
	
INSERT INTO orden(
	folio_orden, fecha, no_empleado, rfc_cliente)
	VALUES (nextval('folio_orden_sequence'), '09/4/2022', '1', 'QUMA470929F37');
	
INSERT INTO orden(
	folio_orden, fecha, no_empleado, rfc_cliente)
	VALUES (nextval('folio_orden_sequence'), '12/4/2022', '1', 'HIRA200929Z39');




--C O N T I E N E

INSERT INTO contiene(
	folio_orden, id_producto, cantidad, precio_total)
	VALUES ('ORD-001', '123', '1', '25');

INSERT INTO contiene(
	folio_orden, id_producto, cantidad, precio_total)
	VALUES ('ORD-001', '639', '1', '60');

INSERT INTO contiene(
	folio_orden, id_producto, cantidad, precio_total)
	VALUES ('ORD-001', '147', '1', '15');
	
INSERT INTO contiene(
	folio_orden, id_producto, cantidad, precio_total)
	VALUES ('ORD-002', '639', '2', '120');

INSERT INTO contiene(
	folio_orden, id_producto, cantidad, precio_total)
	VALUES ('ORD-002', '123', '2', '50');

INSERT INTO contiene(
	folio_orden, id_producto, cantidad, precio_total)
	VALUES ('ORD-002', '147', '2', '30');

INSERT INTO contiene(
	folio_orden, id_producto, cantidad, precio_total)
	VALUES ('ORD-003', '789', '1', '30');
	
INSERT INTO contiene(
	folio_orden, id_producto, cantidad, precio_total)
	VALUES ('ORD-004', '123', '1', '25');
	
INSERT INTO contiene(
	folio_orden, id_producto, cantidad, precio_total)
	VALUES ('ORD-005', '147', '4', '60');


