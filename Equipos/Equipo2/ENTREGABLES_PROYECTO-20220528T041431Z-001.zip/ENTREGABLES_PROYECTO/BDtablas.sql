-- Script de creación de la base de datos y tablas
---INTEGRANTES:
--Alvarez Badillo Rodrigo
--Mondragón Hernández Andrea Quetzalli
--Montes Cantero Zelene Yosseline Isayana
--Pineda González Rodrigo
--Segura Garduño Karen Alin
-- PROFESOR: ING. FERNANDO ARREOLA
-- BASES DE DATOS, GRUPO 1, SEMESTRE 2022-2


--Creacion de la base de datos 
create database restaurante;

--Conectarse a la base de datos PROYECTOBD
\c restaurante;


---Creación de tablas

--CREACION TABLA categoria

CREATE TABLE categoria(
    id_categoria smallint NOT NULL,
    nombre_categoria character varying(50) NOT NULL,
    descripcion_categoria character varying(300) NOT NULL,
    CONSTRAINT categoria_pk PRIMARY KEY (id_categoria)
);

---CREACIÓN TABLA cliente

CREATE TABLE cliente(
    rfc_cliente character varying(13) NOT NULL,
    nombre_cliente character varying(50) NOT NULL,
    apellido_paterno character varying(30) NOT NULL,
    apellido_materno character varying(30),
    razon_social character varying(50) NOT NULL,
    estado character varying(30) NOT NULL,
    codigo_postal integer NOT NULL,
    colonia character varying(50) NOT NULL,
    calle character varying(50) NOT NULL,
    numero smallint NOT NULL,
    email character varying(30) NOT NULL,
    fecha_nacimiento date NOT NULL,
    CONSTRAINT cliente_pk PRIMARY KEY (rfc_cliente)
);

---CREACIÓN TABLA empleado

CREATE TABLE empleado(
    no_empleado smallint NOT NULL,
    rfc character varying(13) NOT NULL,
    sueldo smallint NOT NULL,
    edad smallint NOT NULL,
    fecha_nacimiento date NOT NULL,
    numero smallint NOT NULL,
    calle character varying(50) NOT NULL,
    colonia character varying(50) NOT NULL,
    codigo_postal integer NOT NULL,
    estado character varying(30) NOT NULL,
    nombre_empleado character varying(70) NOT NULL,
    apellido_paterno character varying(70) NOT NULL,
    apellido_materno character varying(70),
    foto bytea,
    es_cocinero boolean NOT NULL,
    especialidad character varying(100),
    es_mesero boolean NOT NULL,
    horario character varying(20),
    es_administrativo boolean NOT NULL,
    rol character varying(100),
    CONSTRAINT empleado_pk PRIMARY KEY (no_empleado)
);

---CREACIÓN TABLA dependiente

CREATE TABLE dependiente(
    curp character varying(18) NOT NULL,
    parentesco character varying(10) NOT NULL,
    nombre_dependiente character varying(70) NOT NULL,
    apellido_paterno character varying(70) NOT NULL,
    apellido_materno character varying(70),
    no_empleado smallint NOT NULL,
    CONSTRAINT dependiente_pk PRIMARY KEY (curp),
    CONSTRAINT dependiente_empleado_fk FOREIGN KEY (no_empleado)
    REFERENCES empleado (no_empleado)
    ON DELETE CASCADE on update cascade
);

---CREACIÓN TABLA telefono
CREATE TABLE telefono(
    telefono bigint NOT NULL,
    no_empleado smallint NOT NULL,
    CONSTRAINT telefono_pk PRIMARY KEY (telefono),
    CONSTRAINT telefono_empleado_fk FOREIGN KEY (no_empleado)
    REFERENCES empleado (no_empleado)
    ON DELETE CASCADE on update cascade
);

---CREACIÓN TABLA producto

CREATE TABLE producto(
    id_producto smallint NOT NULL,
    nombre_producto character varying(70) NOT NULL,
    disponibilidad smallint,
    precio money,
    receta character varying(3000) NOT NULL,
    descripcion character varying(700) NOT NULL,
    id_categoria smallint NOT NULL,
    CONSTRAINT producto_pk PRIMARY KEY (id_producto),
    CONSTRAINT producto_categoria_fk FOREIGN KEY (id_categoria)
    REFERENCES categoria (id_categoria)
    ON DELETE CASCADE on update cascade,
    CONSTRAINT producto_disponibilidad_chk CHECK (disponibilidad >= 0)
);

---CREACIÓN TABLA orden
CREATE TABLE orden(
    folio_orden character varying(7) NOT NULL,
    pago money,
    fecha character varying NOT NULL,
    no_empleado smallint NOT NULL,
    rfc_cliente character varying(13) NOT NULL,
    CONSTRAINT orden_pk PRIMARY KEY (folio_orden),
    CONSTRAINT orden_empleado_fk FOREIGN KEY (no_empleado)
    REFERENCES empleado (no_empleado)
    ON DELETE CASCADE on update cascade,
    CONSTRAINT orden_cliente_fk FOREIGN KEY (rfc_cliente)
    REFERENCES cliente (rfc_cliente)
    ON DELETE CASCADE on update cascade
);

---CREACIÓN TABLA orden
CREATE TABLE contiene(
    folio_orden character varying(7) NOT NULL,
    id_producto smallint NOT NULL,
    cantidad smallint NOT NULL,
    precio_total money,
    CONSTRAINT contiene_pk PRIMARY KEY (folio_orden, id_producto),
    CONSTRAINT contine_orden_fk FOREIGN KEY (folio_orden)
    REFERENCES orden (folio_orden)
    ON DELETE CASCADE on update cascade, 
    CONSTRAINT contiene_producto_fk FOREIGN KEY (id_producto)
    REFERENCES producto (id_producto)
    ON DELETE CASCADE on update cascade
);

