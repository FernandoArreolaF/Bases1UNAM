INSERT INTO sucursal VALUES (1,'COYOACAN',5583658910, '2000-02-09',2335, 34,'Vallarta','Villa Coyoacan','CDMX');
INSERT INTO sucursal VALUES (2,'COPILCO',5545484741,'2001-12-05',13540,45,'Copilco Universidad','Coyoacan','CDMX');
INSERT INTO sucursal VALUES (3,'ALVARO OBREGON',5545547841,'2002-12-05',13540,45,'Fuentes','Jardines del Pedregal','CDMX');
INSERT INTO sucursal VALUES (4,'TLALPAN',5546547852,'2002-02-05',18340,45,'Cuicuilco','San Fernando','CDMX');

INSERT INTO supervisor VALUES(1,'RALM010101000', 'loq@gmail.com', '2020-01-01','LONO26309HDFV', 'Ricardo', 'Lopez','Mendoza',09820, 234, 'Lomas', 'Condesa', 'CDMX');
INSERT INTO supervisor VALUES(2,'OATM010101000','oscar@gmail.com','2022-05-24','TOMO00505HDFV','Oscar', 'Tovar','Mendoza',10254,05,'Olivos','Colores','CDMX');
INSERT INTO supervisor VALUES(3,'BATM010101000','mario@gmail.com','2010-03-06','MBMO20459HDFV','Mario','Benitez','Mera',12456,78,'Leyes','Torres','CDMX');
INSERT INTO supervisor VALUES(4,'GABT010101000','gustavo@gmail.com','2010-06-02','GBTL20478HDFV','Gustavo','Bernal','Tellez',14896,12,'Leyes','Pedregal','CDMX');

INSERT INTO categoria VALUES(1,'Salas');
INSERT INTO categoria VALUES(2,'Comedores');
INSERT INTO categoria VALUES(3,'Cocinas');
INSERT INTO categoria VALUES(4,'Colchones');
INSERT INTO categoria VALUES(5,'Escritorios');
