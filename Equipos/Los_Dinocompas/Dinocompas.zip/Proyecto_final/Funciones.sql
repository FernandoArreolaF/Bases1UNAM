CREATE FUNCTION  agrega_no_dispo()
    RETURNS trigger AS
$BODY$
BEGIN 
DELETE FROM STOCK_ND;
INSERT INTO STOCK_ND VALUES((select nombre from articulo where stock < 3),
                            (select stock from articulo where stock < 3)); 
UPDATE STOCK_ND SET stock ='No disponible' WHERE stock = '0';
    RETURN NEW;
END;
$BODY$
LANGUAGE plpgsql; 

CREATE TRIGGER no_dispon 
AFTER UPDATE or insert or DELETE ON articulo 
FOR EACH ROW
EXECUTE FUNCTION agrega_no_dispo();


/////////////////////////////////////////////////////////////////////////////////////////////////////////

CREATE VIEW ticket_fac AS(SELECT max(a.folio_ticket::text) AS folio,
    t.fecha_ticket AS fecha,
    string_agg(a.codigo_barra::character varying::text, ' ,'::text) AS codigos,
    string_agg(((a.cant_por_art::double precision * a.monto_por_art)::character varying)::text, ' ,'::text) AS precio_total_por_articulo,
    string_agg(a.cant_por_art::character varying::text, ' ,'::text) AS totales_por_articulo,
    t.cant_total_art AS cantidad_de_articulos,
    t.monto_total AS precio_total,
    t.num_empleado_vend AS empleado_que_vendio,
    t.num_empleado_caj AS cajero,
    floor(1000::double precision + random() * (9000 - 1000 + 1)::double precision)::integer AS folio_factura
   FROM ticket t
     JOIN incluye a ON t.folio::text = a.folio_ticket::text
  GROUP BY a.folio_ticket, t.fecha_ticket, t.num_empleado_vend, t.cant_total_art, t.monto_total, t.num_empleado_caj
 HAVING a.folio_ticket::text = (( SELECT max(incluye.folio_ticket::text) AS max
           FROM incluye)));

/////////////////////////////////////////////////////////////////////////////////////////////////////////

CREATE SEQUENCE folio_seq
    START 1
    INCREMENT 1;

/////////////////////////////////////////////////////////////////////////////////////////////////////////


CREATE or REPLACE FUNCTION agrega_totale( )
    RETURNS trigger AS
$BODY$
BEGIN
--Monto total
UPDATE TICKET SET monto_total = (SELECT SUM((monto_por_art)*(cant_por_art)) 
FROM INCLUYE WHERE folio_ticket = (SELECT MAX(folio) FROM ticket))
WHERE folio = (SELECT MAX(folio) FROM ticket);

--Cantidad total de articulos
UPDATE TICKET SET cant_total_art = (SELECT SUM((cant_por_art)) 
FROM INCLUYE WHERE folio_ticket = (SELECT MAX(folio) FROM ticket))
WHERE folio = (SELECT MAX(folio) FROM ticket);

RETURN NEW;
END;
$BODY$
LANGUAGE plpgsql;

CREATE  or REPLACE TRIGGER ag_tickete
AFTER INSERT ON incluye
FOR EACH ROW
EXECUTE FUNCTION agrega_totale();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

SELECT DISTINCT id_sucursal_sucursal from empleado 
WHERE id_sucursal_sucursal = 
(SELECT id_sucursal_sucursal from empleado WHERE num_empleado = 1) 
AND id_sucursal_sucursal = 
(SELECT id_sucursal_sucursal from empleado WHERE num_empleado = 2);

////////////////////////////////////////////////////////////////////////////////////////////////////////////

CREATE OR REPLACE FUNCTION reporte(v_fecha_inicio VARCHAR,v_fecha_fin VARCHAR) RETURNS
TABLE( nombre varchar(50),monto NUMERIC,
	  articulos double precision) 
AS $$
BEGIN
	IF v_fecha_inicio = '' AND v_fecha_fin <> '' THEN
	
	RETURN QUERY SELECT DISTINCT s.nombre, trunc(cast(SUM(t.monto_total) as numeric),2), 
	SUM(t.cant_total_art) FROM
	empleado e JOIN sucursal s on s.id_sucursal = e.id_sucursal_sucursal JOIN ticket t 
	ON t.num_empleado_caj = e.num_empleado OR t.num_empleado_vend = e.num_empleado
	GROUP BY e.num_empleado, e.id_sucursal_sucursal, s.nombre,t.fecha_ticket 
	HAVING t.fecha_ticket =  cast (v_fecha_fin as date);
	
	
	
	
	elsif v_fecha_inicio <> '' and v_fecha_fin = '' then 
	
	RETURN QUERY SELECT  DISTINCT s.nombre,trunc(cast(SUM(t.monto_total) as numeric),2), 
	SUM(t.cant_total_art) FROM
	empleado e JOIN sucursal s on s.id_sucursal = e.id_sucursal_sucursal JOIN ticket t 
	ON t.num_empleado_caj = e.num_empleado OR t.num_empleado_vend = e.num_empleado
	GROUP BY e.num_empleado, e.id_sucursal_sucursal, s.nombre,t.fecha_ticket 
	HAVING t.fecha_ticket =  cast (v_fecha_inicio as date);
	
	
	

	elsif v_fecha_inicio <> '' and v_fecha_fin <>'' then
	RETURN QUERY SELECT  DISTINCT s.nombre, trunc(cast(SUM(t.monto_total) as numeric),2), 
	SUM(t.cant_total_art) FROM
	empleado e JOIN sucursal s on s.id_sucursal = e.id_sucursal_sucursal JOIN ticket t 
	ON t.num_empleado_caj = e.num_empleado OR t.num_empleado_vend = e.num_empleado
	GROUP BY e.num_empleado, e.id_sucursal_sucursal, s.nombre,t.fecha_ticket 
	HAVING t.fecha_ticket  between cast(v_fecha_inicio as date) and cast(v_fecha_fin as date);
	
	
	else 
	RETURN QUERY SELECT  DISTINCT s.nombre,trunc(cast(SUM(t.monto_total) as numeric),2), 
	SUM(t.cant_total_art) FROM
	empleado e JOIN sucursal s on s.id_sucursal = e.id_sucursal_sucursal JOIN ticket t 
	ON t.num_empleado_caj = e.num_empleado OR t.num_empleado_vend = e.num_empleado
	GROUP BY e.num_empleado, e.id_sucursal_sucursal, s.nombre,t.fecha_ticket 
	HAVING t.fecha_ticket =  (select current_date);
	
END IF;
END;
$$
language plpgsql;


//////////////////////////////////////////////////////////////////////////////////////////////////

CREATE INDEX idx_incluye 
ON incluye(codigo_barra,folio_ticket);


///////////////////////////////////////////////////////////////////////////////////////////////



