EMPLEADO {
            no_empleado  int (PK),
            rfc varing(13) (U),
            sueldo int,
            foto bytea,
            calle varing(30),
            no_exterior varing(9),
            colonia varing(30),
            estado varing(20),
            cp int,
            nombre varing(20),
            ap_paterno varing(25),
            ap_materno varing(25) (N),
            edad smallint (C),
            fecha_nacimiento date,
            especialidad varing(25) (N),
            rol varing(25) (N),
            horario varing(12) (N)
}
 
DEPENDIENTE {
            [curp varing(18) (U), no_empleado  int (FK)] (PK),
            parentesco  varing(14),
            nombre varing(20) ,
            ap_paterno varing(25),
            ap_materno varing(25) (N),
}
 
ORDEN {
            folio varing(7) (PK),
            fecha date,
            monto_final int (C),
            no_empleado  int (FK),
            rfc_cliente varing(13) (FK),
}
 
PRODUCTO {
            Id_producto int (PK),     
            nombre varing(50),
            receta varing(140),
            descripción varing(140),
            precio int,
            disponibilidad boolean (C),
            ventas int,
            id_categoría (FK)
}
 
CATEGORIA {
            id_categoria int (PK),
            descripcion varing(100),
            nombre_categoria varing(8)
}
 
CLIENTE {
            rfc varing(13) (PK),
            razon_solcial varing(35),
            fecha_nacimiento date,
            email varing(50),
            calle varing(35),
            no_exterior varing(10),
            colonia varing(35),
            estado varing(18),
            cp int,
            nombre varing(35),
            ap_paterno varing(25),
            ap_materno varing(25) (N)
}
 
TELEFONO {
            teleforno varing(10) (PK),
            no_empleado  int (FK)
}
 
ORDEN_PRODUCTO {
            [id_producto int (FK), folio varing(7) (FK)] (PK),
            cantidad smallint,
            precio_total_producto int (C)
}
