/*Función 1*/
CREATE FUNCTION public.actualiza_monto_total_prod() RETURNS trigger
LANGUAGE plpgsql
    AS $$
    DECLARE
monto_finali integer;
monto_total_producto integer;
no_ventas integer;
precio_producto integer;
BEGIN
select ventas,precio into no_ventas,precio_producto from producto where
producto.id_producto = new.id_producto;
select monto_final into monto_finali from orden where orden.folio = new.folio;
no_ventas = no_ventas + new.cantidad;
UPDATE producto SET ventas = no_ventas WHERE id_producto = new.id_producto; --
actualiza el numero de ventas, sumando el no que tenia mas la cantidad nueva
monto_total_producto = new.cantidad * precio_producto;
UPDATE orden_producto SET precio_total_por_producto = monto_total_producto WHERE
id_producto = new.id_producto and folio=new.folio;
-- actualiza el monto total de un producto y su cantidad
monto_finali = monto_finali + monto_total_producto;
UPDATE orden SET monto_final = monto_finali WHERE folio = new.folio;
--se actualiza el monto total de la orden, sumando todos los montos por producto que
pueda existir.
return new;
END;
$$;

/*Función 2*/
CREATE FUNCTION public.calcula_edad() RETURNS trigger
LANGUAGE plpgsql
    AS $$
    DECLARE
edadcal integer;
BEGIN
edadcal = (extract(year from now()) - extract(year from
NEW.fecha_nacimiento))::integer;
UPDATE empleado SET edad = edadcal WHERE no_empleado = NEW.no_empleado;
RETURN NEW;
END;
$$;

/*Funcion 3*/
CREATE FUNCTION public.empleado_ordenes(num_empleado text) RETURNS TABLE(folio_ord text, monto_orden integer)
LANGUAGE plpgsql
    AS $$
    DECLARE
mesero char varying;
BEGIN
select empleado.horario into mesero from empleado where empleado.no_empleado = num_empleado ;
if mesero is null then
    raise exception 'El empleado seleccionado NO es un mesero.';
else
    RETURN QUERY
    select orden.folio,orden.monto_final from empleado
    join orden on empleado.no_empleado = orden.no_empleado
    WHERE orden.fecha = now()::date;
END IF;
END;
$$;

/*Funcion 4*/
CREATE FUNCTION public.factura(folio_orden text) RETURNS text
LANGUAGE plpgsql
    AS $_$
    DECLARE
fol text;
rfc_cliente char varying;
razon_cliente char varying;
fecha_orden date;
monto_orden integer;
registro Record;
productos CURSOR for select producto.nombre, producto.precio,
cantidad,precio_total_por_producto
from orden_producto
join producto on orden_producto.id_producto = producto.id_producto
WHERE folio = folio_orden;
BEGIN
select folio,cliente.rfc,razon_social,orden.fecha,orden.monto_final
INTO fol,rfc_cliente,razon_cliente,fecha_orden,monto_orden from orden
JOIN cliente on rfc_cte = cliente.rfc WHERE folio = folio_orden;
if fol is not null then
    RAISE NOTICE '-------------------------------------------------------------
    -------------------------------';
    RAISE NOTICE '------FOLIO: %--------------------------------FECHA: %-------
    ----------------',fol,fecha_orden;
    RAISE NOTICE '------RFC EMISOR: CHE110527DQ3----------------------Nombre:
    Restaurante Los excentos--------';
    RAISE NOTICE '------REGIMEN FISCAL: ACTIVIDADES EMPRESARIALES-----EFECTO:
    INGRESO-------------------------';
    RAISE NOTICE '------USO DE CFDI: GASTOS EN GENERAL----------------FORMA DE
    PAGO:EFECTIVO------------------';
    RAISE NOTICE '-------------------------------------------------------------
    -------------------------------';
    RAISE NOTICE '';
    RAISE NOTICE ' RFC RECEPTOR: %',rfc_cliente;
    RAISE NOTICE ' NOMBRE O RAZON SOCIAL: %',razon_cliente;
    RAISE NOTICE '';
        for registro in productos loop
            RAISE NOTICE 'PRODUCTO: %',registro.nombre;
            RAISE NOTICE ' VALOR UNITARIO: $% CANTIDAD: % IMPORTE: $%',registro.precio,registro.cantidad,registro.precio_total_por_producto;
            RAISE NOTICE '';
        end loop;
    RAISE NOTICE ' --------------';
    RAISE NOTICE ' TOTAL: $%',monto_orden;
else
    RAISE EXCEPTION 'La orden ingresada NO existe O NO se ha ingresado el RFC del
    cliente. ';
END IF;
RETURN 'Su factura se ha realizado correctamente';
END;
$_$;

/*Funcion 5*/
CREATE FUNCTION public.ingresar_productos(prod1 character varying, cant1 integer, prod2 character varying, cant2 integer, prod3 character varying, cant3 integer) RETURNS text
LANGUAGE plpgsql
    AS $$
    DECLARE
id_1 integer ;
id_2 integer;
id_3 integer;
BEGIN
SELECT id_producto into id_1 FROM producto WHERE nombre = prod1;
SELECT id_producto into id_2 FROM producto WHERE nombre = prod2;
SELECT id_producto into id_3 FROM producto WHERE nombre = prod3;
if (prod1 = '0' and prod2 = '0' and prod3 = '0') then
    RAISE EXCEPTION 'No se ha ingresado ningun producto';
else
    INSERT INTO public.orden(no_empleado)VALUES ('EMP-001');
end if;
if prod1 != '0' then
    INSERT INTO public.orden_producto(id_producto, folio, cantidad) VALUES (id_1,
    orden_actual(), cant1);
end if;
if prod2 != '0' then
    INSERT INTO public.orden_producto(id_producto, folio, cantidad) VALUES (id_2,
    orden_actual(), cant2);
end if;
if prod3 != '0' then
    INSERT INTO public.orden_producto(id_producto, folio, cantidad) VALUES (id_3,
    orden_actual(), cant3);
end if;
RETURN id_1;
END;
$$;

/*Funcion 6*/
CREATE FUNCTION public.no_ventas(fecha_ini date, fecha_fin date) RETURNS TABLE(no_ventas bigint, monto_total bigint)
LANGUAGE plpgsql
    AS $$
    BEGIN
RETURN QUERY
SELECT count(folio),sum(monto_final) from orden where fecha between fecha_ini and
fecha_fin;
END;
$$;

/*Funcion 7*/
CREATE FUNCTION public.orden_actual() RETURNS text
LANGUAGE plpgsql
    AS $$
    DECLARE fol text;
BEGIN
select folio into fol from orden order by folio desc
limit 1;
RETURN fol;
END;$$;

/*Funcion 8*/
CREATE FUNCTION public.revisa_ingreso_productos() RETURNS trigger
LANGUAGE plpgsql
    AS $$
BEGIN
if new.ventas = 0 then
    return new;
else
    raise exception 'No se puede ingresar manualmente el no de ventas del producto';
end if;
end;
$$;

/*Funcion 9*/
CREATE FUNCTION public.revisa_ingreso_productos_orden() RETURNS trigger
LANGUAGE plpgsql
    AS $$
    DECLARE
disponible bool;
nombre_prod char varying;
BEGIN
select disponibilidad,nombre into disponible,nombre_prod from producto where
producto.id_producto = new.id_producto;
if (disponible) then
if new.precio_total_por_producto is not null then
if new.precio_total_por_producto = 0 then
    return new;
else
    raise exception 'No se puede ingresar manualmente el monto total por el producto';
end if;
else
    return new;
end if;
else
    raise exception 'El producto % NO esta disponible',nombre_prod;
end if;
end;
$$;

/*Funcion 10*/
CREATE FUNCTION public.revisa_orden() RETURNS trigger
LANGUAGE plpgsql
    AS $$
    DECLARE
horario_mesero char varying;
BEGIN
select horario into horario_mesero from empleado where empleado.no_empleado = new.no_empleado;
if new.folio SIMILAR TO 'ORD-[0-9][0-9][0-9]' then
if new.monto_final = 0 then
if horario_mesero is null then
raise exception 'El empleado ingresado No es un mesero que pueda levantar ordenes';
else
    return new;
end if;
else
    raise exception 'No se puede ingresar manualmente el monto total de la orden';
end if;
else
    raise exception 'El Numero de folio no tiene el formato correcto';
end if;
end; 
$$;

/*Funcion 11*/
CREATE FUNCTION public.telefonos(emp text) RETURNS text
LANGUAGE plpgsql
    AS $$
    DECLARE
numero text;
pivote text = '';
registro Record;
telefonos CURSOR FOR select telefono from telefono
join empleado on empleado.no_empleado = telefono.no_empleado
WHERE telefono.no_empleado = emp order by telefono;
BEGIN
for registro in telefonos loop
    pivote = numero;
    --numero = concat(pivote,' ,', registro.telefono);
    numero = concat(registro.telefono,', ',pivote);
end loop;
RETURN numero;
END;
$$;

/*Funcion 12*/
CREATE FUNCTION public.verificar_empleado() RETURNS trigger
LANGUAGE plpgsql
    AS $$
BEGIN
if new.no_empleado SIMILAR TO 'EMP-[0-9][0-9][0-9]' then
if new.edad is not NULL then
    raise exception 'NO se puede ingresar la Edad Manualmente';
else
    RETURN NEW;
end if;
else
    raise exception 'NO se puede ingresar el Numero de Empleado';
end if;
END;
$$;

