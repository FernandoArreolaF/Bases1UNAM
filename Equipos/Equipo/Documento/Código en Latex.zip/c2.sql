CREATE TABLE public.categoria (
    id_categoria integer NOT NULL,
    nombre_categoria character varying(8) NOT NULL,
    descripcion character varying(100) NOT NULL
);

CREATE TABLE public.cliente (
    rfc character varying(13) NOT NULL,
    razon_social character varying(55) NOT NULL,
    nombre character varying(50),
    ap_paterno character varying(30),
    ap_materno character varying(30),
    calle character varying(45),
    no_exterior character varying(10),
    colonia character varying(45),
    estado character varying(18),
    cp character varying(5),
    fecha_nacimiento date,
    email character varying(50)
);

CREATE TABLE public.dependiente (
    curp character varying(18) NOT NULL,
    no_empleado text NOT NULL,
    nombre character varying(30) NOT NULL,
    ap_paterno character varying(25) NOT NULL,
    ap_materno character varying(25),
    parentesco character varying(14) NOT NULL
);

CREATE TABLE public.empleado (
    no_empleado text DEFAULT ('EMP-'::text ||lpad((nextval('public.emp_seq'::regclass))::text, 3, '0'::text)) NOT NULL,
    rfc character varying(13) NOT NULL,
    nombre character varying(20) NOT NULL,
    ap_paterno character varying(25) NOT NULL,
    ap_materno character varying(25),
    calle character varying(30) NOT NULL,
    no_exterior character varying(9) NOT NULL,
    colonia character varying(30) NOT NULL,
    estado character varying(20) NOT NULL,
    cp character varying(5) NOT NULL,
    fecha_nacimiento date NOT NULL,
    edad integer,
    sueldo integer NOT NULL,
    especialidad character varying(25),
    rol character varying(25),
    horario character varying(12),
    foto character varying(20) NOT NULL
);

CREATE TABLE public.orden (
    folio text DEFAULT ('ORD-'::text ||lpad((nextval('public.folio_seq'::regclass))::text, 3, '0'::text)) NOT NULL,
    fecha date DEFAULT (now())::date NOT NULL,
    monto_final integer DEFAULT 0,
    no_empleado text NOT NULL,
    rfc_cte character varying(13)
);

CREATE TABLE public.orden_producto (
    id_producto integer NOT NULL,
    folio text NOT NULL,
    cantidad smallint NOT NULL,
    precio_total_por_producto integer DEFAULT 0
);

CREATE TABLE public.producto (
    id_producto integer DEFAULT nextval('public.producto_id_producto_seq'::regclass) NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion character varying(350) NOT NULL,
    receta character varying(350) NOT NULL,
    disponibilidad boolean NOT NULL,
    id_categoria integer NOT NULL,
    precio integer NOT NULL,
    ventas integer DEFAULT 0
);

CREATE TABLE public.telefono (
    telefono character varying(18) NOT NULL,
    no_empleado text NOT NULL
);