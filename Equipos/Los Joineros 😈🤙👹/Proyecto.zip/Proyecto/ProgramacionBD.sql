--Script de toda la programación a nivel BD
--Cada que se agregue un artículo a una venta, debe actualizarse los totales (por artículo, venta y cantidad de artículos), así como validar que elartículo esté disponible.
--VALIDA LA VENTA
CREATE OR REPLACE FUNCTION validar_detalle_venta()
RETURNS TRIGGER AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM ARTICULO
               WHERE codigo_barras = NEW.codigo_barra
                 AND stock >= NEW.cantidad)
    THEN
        NEW.precio_unitario = (SELECT precio_venta
                               FROM ARTICULO
                               WHERE codigo_barras = NEW.codigo_barra);
        NEW.monto_total_art = NEW.cantidad * NEW.precio_unitario;
        RETURN NEW;
    ELSE
        IF NOT EXISTS (SELECT 1 FROM ARTICULO WHERE codigo_barras = NEW.codigo_barra) THEN
            RAISE EXCEPTION 'El artículo con código de barras % no está registrado en el inventario.', NEW.codigo_barra;
        ELSE
            RAISE EXCEPTION 'Stock insuficiente para el artículo con código de barras %. Cantidad solicitada: %, Stock disponible: %.',
                NEW.codigo_barra,
                NEW.cantidad,
                (SELECT stock FROM ARTICULO WHERE codigo_barras = NEW.codigo_barra);
        END IF;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_validar_detalle_venta
BEFORE INSERT ON DETALLE_VENTA
FOR EACH ROW
EXECUTE FUNCTION validar_detalle_venta();


--ACTUALZIA EL STOCK DESPUES DE REALIZAR LA VENTA
CREATE OR REPLACE FUNCTION actualizar_stock_total_venta()
RETURNS TRIGGER AS $$
DECLARE
  stock_ajuste NUMERIC;
BEGIN
	IF (TG_OP = 'INSERT') THEN
	    UPDATE ARTICULO
	    SET stock = stock - NEW.cantidad
	    WHERE codigo_barras = NEW.codigo_barra;
	ELSEIF (TG_OP = 'UPDATE') THEN
		stock_ajuste := NEW.cantidad - OLD.cantidad;
	    UPDATE ARTICULO
	    SET stock = stock - stock_ajuste
	    WHERE codigo_barras = NEW.codigo_barra;
	END IF;

    UPDATE VENTA
    SET monto_total = (SELECT COALESCE(SUM(monto_total_art), 0)
                       FROM DETALLE_VENTA
                       WHERE folio_venta = NEW.folio_venta)
    WHERE folio_venta = NEW.folio_venta;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trigger_actualizar_stock_total
AFTER INSERT OR UPDATE ON DETALLE_VENTA
FOR EACH ROW
EXECUTE FUNCTION actualizar_stock_total_venta();


--Crear al menos, un índice, del tipo que se prefiera y donde se prefiera. Justificar el porqué de la elección en ambos aspectos.
-- Indice de ARTICULO_STOCK
CREATE INDEX idx_articulo_stock ON ARTICULO(stock);

-- Indice de DETALLE_VENTA
CREATE INDEX idx_detalle_venta_folio ON DETALLE_VENTA(folio_venta);

-- Indice de ARTICULO_STOCK_ con filtro para conocer articulos con stock bajo
CREATE INDEX idx_articulo_stock_bajo ON ARTICULO(stock) WHERE stock < 3;


--Lista de artículos no disponibles o con stock < 3. Si el artículo no está disponible, debe aparecer el mensaje ”No disponible”.
CREATE VIEW no_disponibles AS 
SELECT codigo_barras, nombre, stock,
	CASE 
		WHEN stock < 3 THEN 'No disponible'
	END AS estado
FROM ARTICULO
WHERE stock < 3;

--Caso contrario
CREATE VIEW disponibles AS 
SELECT codigo_barras, nombre, stock,
	CASE 
		WHEN stock >= 3 THEN 'Disponible'
	END AS estado
FROM ARTICULO
WHERE stock >= 3;


-- De manera automática se genere una vista que contenga información necesaria para asemejarse a un ticket de venta, incluyendo un folio para facturación (caracteres aleatorios).
--FUnción de crear ticket (forma de tabla)
CREATE OR REPLACE FUNCTION ticket(folio_venta VARCHAR(10))
RETURNS TABLE(TICKET TEXT) AS $$
BEGIN 
	RETURN QUERY 
	
	SELECT 'Factura: ' || UPPER(substr(md5(random()::text), 1, 6))
  
	UNION ALL

  	SELECT 'Fecha: ' || V.fecha_venta::TEXT 
	FROM VENTA V WHERE V.folio_venta = ticket.folio_venta

  	UNION ALL

  	SELECT 'Cliente RFC: ' || COALESCE(V.rfc_cliente::TEXT, 'NO REGISTRADO') 
  	FROM VENTA V WHERE V.folio_venta = ticket.folio_venta

  	UNION ALL

  	SELECT 'Producto: ' || A.nombre || ' | Cantidad: ' || DV.cantidad::TEXT || ' | Precio: $' || DV.precio_unitario::TEXT
  	FROM DETALLE_VENTA DV
  	JOIN ARTICULO A ON A.codigo_barras = DV.codigo_barra
  	WHERE DV.folio_venta = ticket.folio_venta

  	UNION ALL

  	SELECT 'Total de la venta: $' || V.monto_total::TEXT
  	FROM VENTA V WHERE V.folio_venta = ticket.folio_venta;

END;
$$ LANGUAGE plpgsql;

--Vista de tickets
CREATE VIEW vista_tickets AS 
SELECT
	'Factura: ' || UPPER(substr(md5(random()::text), 1, 6)) AS Folio_de_factura,
	V.folio_venta,
	V.fecha_venta,
	COALESCE(C.rfc_cliente::TEXT, 'NO REGISTRADO') AS rfc_cliente,
    A.nombre AS articulo,
    DV.cantidad,
    DV.precio_unitario,
    DV.monto_total_art,
    V.monto_total
FROM VENTA V
LEFT JOIN CLIENTE C ON V.rfc_cliente = C.rfc_cliente
JOIN DETALLE_VENTA DV ON DV.folio_venta = V.folio_venta
JOIN ARTICULO A ON A.codigo_barras = DV.codigo_barra;

--Función para el disparador del ticket forma automatica
CREATE OR REPLACE FUNCTION mostrar_ticket_automatico()
RETURNS TRIGGER AS $$
DECLARE
  linea TEXT;
BEGIN
  FOR linea IN SELECT * FROM ticket(NEW.folio_venta)
  LOOP
    RAISE NOTICE '%', linea; 
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
--Disparador para mostrar el ticket al hacer una venta
CREATE TRIGGER mostrar_ticket
AFTER INSERT ON VENTA
FOR EACH ROW
EXECUTE FUNCTION mostrar_ticket_automatico();


--Al iniciar una venta, debe validarse que el vendedor y el cajero, pertenezcan a la misma sucursal, en caso de que no sea así, debe mostrarse un mensaje de error.
CREATE OR REPLACE FUNCTION valVendedor_Cajero()
RETURNS TRIGGER AS $$
DECLARE
    suc_vendedor NUMERIC;
    suc_cajero NUMERIC;
    suc_venta NUMERIC;
BEGIN
    SELECT id_sucursal INTO suc_vendedor
    FROM EMPLEADO
    WHERE id_empleado = NEW.empleado_venta;

    SELECT id_sucursal INTO suc_cajero
    FROM EMPLEADO
    WHERE id_empleado = NEW.empleado_cobro;

    IF suc_vendedor IS NULL OR suc_cajero IS NULL THEN
        RAISE EXCEPTION 'El vendedor o cajero no estan registrados';
    END IF;

    IF suc_vendedor <> suc_cajero THEN
        RAISE EXCEPTION 'La venta no se puede realizar correctamente, el vendedor y el cajero no pertenecen a la misma sucursal';
    END IF;

    IF NEW.id_sucursal != suc_venta OR NEW.id_sucursal != suc_cajero THEN
        RAISE EXCEPTION 'Los empleados no pertenecen a la misma sucursal de la venta';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
--Disparador para validar el vendedor al tratar de hacer una venta
CREATE TRIGGER trg_Val_Vendedor_Cajero
BEFORE INSERT ON VENTA
FOR EACH ROW
EXECUTE FUNCTION valVendedor_Cajero()


--Dado el nombre de un empleado, obtener toda la jerarquía organizacional
-- Funcion de obtencion de jerarquía de empleados en direccion ascendente y descendente
CREATE OR REPLACE FUNCTION ver_jerarquia_completa(nombre_completo_empleado TEXT)
RETURNS TABLE(relacion TEXT, nombre_completo TEXT, rol TEXT) AS $$
BEGIN
    RETURN QUERY
    WITH RECURSIVE jerarquia_sub AS (
        SELECT 
            'Subordinado'::TEXT AS relacion,
            (e.nombre_empleado || ' ' || e.apellido_pat_empleado || ' ' || COALESCE(e.apellido_mat_empleado, ''))::TEXT AS nombre_completo,
            e.rol::TEXT
        FROM EMPLEADO e
        WHERE e.id_jerarquia_empleado = (
            SELECT id_empleado
            FROM EMPLEADO
            WHERE (nombre_empleado || ' ' || apellido_pat_empleado || ' ' || COALESCE(apellido_mat_empleado, '')) = nombre_completo_empleado
            LIMIT 1
        )
        UNION ALL
        SELECT 
            'Subordinado',
            (e.nombre_empleado || ' ' || e.apellido_pat_empleado || ' ' || COALESCE(e.apellido_mat_empleado, ''))::TEXT,
            e.rol::TEXT
        FROM EMPLEADO e
        JOIN jerarquia_sub js ON e.id_jerarquia_empleado = (
            SELECT id_empleado
            FROM EMPLEADO
            WHERE (nombre_empleado || ' ' || apellido_pat_empleado || ' ' || COALESCE(apellido_mat_empleado, '')) = js.nombre_completo
            LIMIT 1
        )
    ),
    jerarquia_jefe AS (
        SELECT 
            'Jefe'::TEXT AS relacion,
            (e.nombre_empleado || ' ' || e.apellido_pat_empleado || ' ' || COALESCE(e.apellido_mat_empleado, ''))::TEXT AS nombre_completo,
            e.rol::TEXT
        FROM EMPLEADO e
        WHERE e.id_empleado = (
            SELECT id_jerarquia_empleado
            FROM EMPLEADO
            WHERE (nombre_empleado || ' ' || apellido_pat_empleado || ' ' || COALESCE(apellido_mat_empleado, '')) = nombre_completo_empleado
            LIMIT 1
        )
        UNION ALL
        SELECT 
            'Jefe',
            (jefe.nombre_empleado || ' ' || jefe.apellido_pat_empleado || ' ' || COALESCE(jefe.apellido_mat_empleado, ''))::TEXT,
            jefe.rol::TEXT
        FROM EMPLEADO jefe
        JOIN jerarquia_jefe jj ON jefe.id_empleado = (
            SELECT id_jerarquia_empleado
            FROM EMPLEADO
            WHERE (nombre_empleado || ' ' || apellido_pat_empleado || ' ' || COALESCE(apellido_mat_empleado, '')) = jj.nombre_completo
            LIMIT 1
        )
    )
    SELECT * FROM jerarquia_sub
    UNION
    SELECT * FROM jerarquia_jefe;
END;
$$ LANGUAGE plpgsql;



--Extra: diaparadores para el DASHBOARD
--Cantidad de ingresos totales mensuales por sucursal en un año determinado
CREATE OR REPLACE VIEW vista_ingresos_mensuales AS
SELECT 
    S.id_sucursal,
    S.nombre_sucursal,
    TO_CHAR(V.fecha_venta, 'TMMonth') AS mes,
    EXTRACT(YEAR FROM V.fecha_venta)::INT AS anio,
    SUM(V.monto_total) AS ingresos_totales
FROM VENTA V
JOIN SUCURSAL S ON V.id_sucursal = S.id_sucursal
GROUP BY S.id_sucursal, S.nombre_sucursal, anio, mes
ORDER BY anio, mes, S.nombre_sucursal;

--Otra gráfica que considere relevante para usuarios de negocio
--Se opto por crear una vista que muestre que productos se han vendido más
CREATE VIEW vista_articulos_mas_vendidos AS
SELECT 
    A.codigo_barras,
    A.nombre AS articulo,
    SUM(DV.cantidad) AS cantidad_total
FROM DETALLE_VENTA DV
JOIN ARTICULO A ON A.codigo_barras = DV.codigo_barra
GROUP BY A.codigo_barras, A.nombre
ORDER BY cantidad_total DESC;

--Extra: disparador para formato de folio de venta
--Prefijo MBL para folio de venta
CREATE OR REPLACE FUNCTION pre_folioVenta()
RETURNS TRIGGER AS $$
BEGIN
	IF NEW.folio_venta IS NULL THEN
		RAISE EXCEPTION 'JAJA NO';
	END IF;
	
	IF NEW.folio_venta NOT LIKE 'MBL-%' THEN
		NEW.folio_venta := 'MBL-' || LPAD(NEW.folio_venta, 6, '0');
	END IF;
	RETURN NEW;
END;
$$ LANGUAGE plpgsql;
	
CREATE OR REPLACE TRIGGER pre_folioVen
BEFORE INSERT ON VENTA
FOR EACH ROW
EXECUTE FUNCTION pre_folioVenta();
