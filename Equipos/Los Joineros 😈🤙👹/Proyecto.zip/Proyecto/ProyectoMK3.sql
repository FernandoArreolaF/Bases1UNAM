-- Database: Proyecto

-- DROP DATABASE IF EXISTS "Proyecto";
--Seleccionar lineas y presionar F5

-- Tabla CATEGORIA
CREATE TABLE CATEGORIA (
    id_categoria NUMERIC PRIMARY KEY,
    nombre_categoria VARCHAR(50) NOT NULL
);


-- Tabla ARTICULO
CREATE TABLE ARTICULO (
    codigo_barras NUMERIC(20) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    precio_venta NUMERIC NOT NULL,
    precio_compra NUMERIC NOT NULL,
    stock NUMERIC NOT NULL,
    fotografia BYTEA NOT NULL,
    id_categoria NUMERIC NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES CATEGORIA(id_categoria)
);

-- Tabla PROVEEDOR
CREATE TABLE PROVEEDOR (
    id_proveedor NUMERIC PRIMARY KEY,
    rfc_prov VARCHAR(13) NOT NULL,
    razon_social_prov VARCHAR(50) NOT NULL,
    estado_prov VARCHAR(30) NOT NULL,
    calle_ VARCHAR(30) NOT NULL,
    cp_prov VARCHAR(5) NOT NULL,
    telefono_prov NUMERIC NOT NULL,
    cuenta_pago VARCHAR(16) NOT NULL
);

--Tabla SUCURSAL
CREATE TABLE SUCURSAL (
    id_sucursal NUMERIC PRIMARY KEY,
    nombre_sucursal VARCHAR(30) NOT NULL,
    estado_sucursal VARCHAR(30) NOT NULL,
    calle_sucursal VARCHAR(30) NOT NULL,
    numero_sucursal NUMERIC NOT NULL,
    cp_sucursal VARCHAR(5) NOT NULL,
    telefono_sucursal NUMERIC NOT NULL,
    ano_fundacion NUMERIC NOT NULL
);

-- Tabla EMPLEADO
CREATE TABLE EMPLEADO (
    id_empleado NUMERIC PRIMARY KEY,
    rfc VARCHAR(13) NOT NULL,
    curp VARCHAR(18) NOT NULL,
    nombre_empleado VARCHAR(30) NOT NULL,
    apellido_pat_empleado VARCHAR(30) NOT NULL,
    apellido_mat_empleado VARCHAR(30),
    estado_empleado VARCHAR(30) NOT NULL,
    colonia_empleado VARCHAR(30) NOT NULL,
    calle_empleado VARCHAR(30) NOT NULL,
    numero_empleado NUMERIC NOT NULL,
    cp_empleado VARCHAR(5) NOT NULL,
    rfc_empleado VARCHAR(13) NOT NULL,
    curp_empleado VARCHAR(18) NOT NULL,
    correo_empleado VARCHAR(100) NOT NULL,
    rol VARCHAR(50) NOT NULL,
    fecha_ingreso DATE NOT NULL,
    id_jerarquia_empleado NUMERIC,
    tipo_empleado VARCHAR(30) NOT NULL,
    id_sucursal NUMERIC,
    FOREIGN KEY (id_jerarquia_empleado) REFERENCES EMPLEADO(id_empleado),
    FOREIGN KEY (id_sucursal) REFERENCES SUCURSAL(id_sucursal)
);

-- Tabla TELEFONO DEL EMPLEADO 
CREATE TABLE TELEFONO (
    id_empleado NUMERIC PRIMARY KEY,
    telefono_empleado NUMERIC UNIQUE NOT NULL,
    FOREIGN KEY (id_empleado) REFERENCES EMPLEADO(id_empleado)
);

-- Tabla CLIENTE
CREATE TABLE CLIENTE (
    rfc_cliente NUMERIC(13) PRIMARY KEY,
    nombre_cliente VARCHAR(30) NOT NULL,
    apellido_pat_cliente VARCHAR(30) NOT NULL,
    apellido_mat__cliente VARCHAR(30),
    razon_social_cliente VARCHAR(50) NOT NULL,
    telefono NUMERIC NOT NULL,
    correo_cliente VARCHAR(100) NOT NULL,
    estado_cliente VARCHAR(30) NOT NULL,
    colonia_cliente VARCHAR(30) NOT NULL,
    calle_cliente VARCHAR(30) NOT NULL,
    numero_cliente NUMERIC NOT NULL,
    cp_cliente VARCHAR(5) NOT NULL
);


-- Tabla VENTA
CREATE TABLE VENTA (
    folio_venta VARCHAR(10) PRIMARY KEY,
    fecha_venta DATE NOT NULL,
    monto_total NUMERIC NOT NULL,
    empleado_venta NUMERIC NOT NULL,
    empleado_cobro NUMERIC NOT NULL,
    id_sucursal NUMERIC NOT NULL,
	rfc_cliente NUMERIC(13),
    FOREIGN KEY (empleado_venta) REFERENCES EMPLEADO(id_empleado),
    FOREIGN KEY (empleado_cobro) REFERENCES EMPLEADO(id_empleado),
    FOREIGN KEY (id_sucursal) REFERENCES SUCURSAL(id_sucursal),
	FOREIGN KEY (rfc_cliente) REFERENCES CLIENTE(rfc_cliente)
);


-- Tabla DETALLE_VENTA
CREATE TABLE DETALLE_VENTA (
    folio_venta VARCHAR(10) NOT NULL,
    codigo_barra NUMERIC(20) NOT NULL,
    cantidad NUMERIC NOT NULL,
    precio_unitario NUMERIC NOT NULL,
    monto_total_art NUMERIC NOT NULL,
    PRIMARY KEY (folio_venta, codigo_barra),
    FOREIGN KEY (folio_venta) REFERENCES VENTA(folio_venta),
    FOREIGN KEY (codigo_barra) REFERENCES ARTICULO(codigo_barras)
);

-- Tabla PROVEE
CREATE TABLE PROVEE (
    codigo_barra NUMERIC(20) NOT NULL,
    id_proveedor NUMERIC NOT NULL,
    fecha_suministro DATE NOT NULL,
    PRIMARY KEY (codigo_barra, id_proveedor),
    FOREIGN KEY (codigo_barra) REFERENCES ARTICULO(codigo_barras),
    FOREIGN KEY (id_proveedor) REFERENCES PROVEEDOR(id_proveedor)
);

--Aquí empezamos los requisitos 
--Cada que se agregue un artículo a una venta, debe actualizarse los totales (por artículo, venta y cantidad de artículos), así como validar que elartículo esté disponible.
--VALIDA LA VENTA
CREATE OR REPLACE FUNCTION validar_detalle_venta()
RETURNS TRIGGER AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM ARTICULO
               WHERE codigo_barras = NEW.codigo_barra
                 AND stock >= NEW.cantidad)
    THEN
        NEW.precio_unitario = (SELECT precio_venta
                               FROM ARTICULO
                               WHERE codigo_barras = NEW.codigo_barra);
        NEW.monto_total_art = NEW.cantidad * NEW.precio_unitario;
        RETURN NEW;
    ELSE
        IF NOT EXISTS (SELECT 1 FROM ARTICULO WHERE codigo_barras = NEW.codigo_barra) THEN
            RAISE EXCEPTION 'El artículo con código de barras % no está registrado en el inventario.', NEW.codigo_barra;--AGREGUE ESTE PLUS, NOS DIRA SI EL CODIGO SE ENCUENTRA EN EL INVENTARIO O NO
        ELSE
            RAISE EXCEPTION 'Stock insuficiente para el artículo con código de barras %. Cantidad solicitada: %, Stock disponible: %.',
                NEW.codigo_barra,
                NEW.cantidad,
                (SELECT stock FROM ARTICULO WHERE codigo_barras = NEW.codigo_barra);
        END IF;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_validar_detalle_venta
BEFORE INSERT ON DETALLE_VENTA
FOR EACH ROW
EXECUTE FUNCTION validar_detalle_venta();


--ACTUALZIA EL STOCK DESPUES DE REALIZAR LA VENTA
CREATE OR REPLACE FUNCTION actualizar_stock_total_venta()
RETURNS TRIGGER AS $$
DECLARE
  stock_ajuste NUMERIC;
BEGIN
	--Al hacer un insert
	IF (TG_OP = 'INSERT') THEN
	    UPDATE ARTICULO
	    SET stock = stock - NEW.cantidad
	    WHERE codigo_barras = NEW.codigo_barra;
	--Al hacer update
	ELSEIF (TG_OP = 'UPDATE') THEN
		stock_ajuste := NEW.cantidad - OLD.cantidad;
	    UPDATE ARTICULO
	    SET stock = stock - stock_ajuste
	    WHERE codigo_barras = NEW.codigo_barra;
	END IF;

    UPDATE VENTA
    SET monto_total = (SELECT COALESCE(SUM(monto_total_art), 0)
                       FROM DETALLE_VENTA
                       WHERE folio_venta = NEW.folio_venta)
    WHERE folio_venta = NEW.folio_venta;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trigger_actualizar_stock_total
AFTER INSERT OR UPDATE ON DETALLE_VENTA
FOR EACH ROW
EXECUTE FUNCTION actualizar_stock_total_venta();

--PRUEBA DE LOS TRIGGERS

INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad)
VALUES (001, 99999, 1); -- Usamos la venta existente 1000001 para insertar un articulo que no existe


INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad)
VALUES (001, 10002, 1); -- Intentamos vender 1 unidad del artículo 10002 y nos va a salir con stock insuficiente 

--Prueba 3: Inserción VÁLIDA en una VENTA NUEVA y VACÍA

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente)
VALUES (003, CURRENT_DATE, 0.00, 1, 2, 1, 2222222222222); --Se crea una venta vacia para que visualicemos que si funcionan los triggers

SELECT stock FROM ARTICULO WHERE codigo_barras = 10001; -- Nos da un resultado de 5
SELECT monto_total FROM VENTA WHERE folio_venta = 003; -- Nos da un resultado de 0.00

INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad)
VALUES (004, 10001, 2); -- Vendemos 2 unidades

-- Y ahora haces un update:
UPDATE DETALLE_VENTA
SET cantidad = 3
WHERE folio_venta = 003 AND codigo_barra = 10001;


SELECT precio_unitario, monto_total_art FROM DETALLE_VENTA
WHERE folio_venta = 003 AND codigo_barra = 10001; --Precio unitario y total de los 2 articulos

SELECT stock FROM ARTICULO WHERE codigo_barras = 10001;--El stock cambio a 3 unidades

SELECT monto_total FROM VENTA WHERE folio_venta = 1000003;--Tenemos el total por los dos articulos



--Crear al menos, un índice, del tipo que se prefiera y donde se prefiera. Justificar el porqué de la elección en ambos aspectos.

-- Indice de ARTICULO_STOCK
-- Justificacion:
/*
El indice de ARTICULO_STOCK nos es util para poder conocer que articulos tienen poco stock o estan disponibles
*/ 

CREATE INDEX idx_articulo_stock ON ARTICULO(stock);
--Prueba de indice
EXPLAIN ANALYZE --Juntar con la linea de abajo para observar el rendimiento
select * FROM ARTICULO;


-- Indice de DETALLE_VENTA
-- Justificacion:
/*
El indice nos permite mejorar la velocidad de busquedad de todas las lineas de detalle asociadas a un folio_venta
y a su vez es util para consultar detalles de una venta en especifico 
*/ 

CREATE INDEX idx_detalle_venta_folio ON DETALLE_VENTA(folio_venta);
--Prueba de indice
EXPLAIN ANALYZE --Juntar con la linea de abajo para observar el rendimiento
select * FROM DETALLE_VENTA;



-- Indice de ARTICULO_STOCK_ con filtro para conocer articulos con stock bajo
-- Justificacion:
/*
El indice de ARTICULO_STOCK_ nos es util para poder conocer que articulos tienen un stock bajo
*/ 
CREATE INDEX idx_articulo_stock_bajo ON ARTICULO(stock) WHERE stock < 3;
--Prueba de indice
EXPLAIN ANALYZE --Juntar con la linea de abajo para observar el rendimiento
SELECT * FROM ARTICULO WHERE stock < 3;


--Lista de artículos no disponibles o con stock < 3. Si el artículo no está disponible, debe aparecer el mensaje ”No disponible”.
CREATE VIEW no_disponibles AS 
SELECT codigo_barras, nombre, stock,
	CASE 
		WHEN stock < 3 THEN 'No disponible'
	END AS estado
FROM ARTICULO
WHERE stock < 3;


--Caso contrario
CREATE VIEW disponibles AS 
SELECT codigo_barras, nombre, stock,
	CASE 
		WHEN stock >= 3 THEN 'Disponible'
	END AS estado
FROM ARTICULO
WHERE stock >= 3;

--Prueba de consultas
select * FROM ARTICULO;

SELECT * FROM no_disponibles;

SELECT * FROM disponibles;

select * FROM VENTA;


-- De manera automática se genere una vista que contenga información necesaria para asemejarse a un ticket de venta, incluyendo un folio para facturación (caracteres aleatorios).
CREATE OR REPLACE FUNCTION ticket(folio_venta VARCHAR(10)) --Se activa al agregar un nuevo folio de venta
RETURNS TABLE(TICKET TEXT) AS $$
BEGIN 
	RETURN QUERY 
	
	SELECT 'Factura: ' || UPPER(substr(md5(random()::text), 1, 6))
  
	UNION ALL

  	SELECT 'Fecha: ' || V.fecha_venta::TEXT 
	FROM VENTA V WHERE V.folio_venta = ticket.folio_venta

  	UNION ALL

  	SELECT 'Cliente RFC: ' || COALESCE(V.rfc_cliente::TEXT, 'NO REGISTRADO') 
  	FROM VENTA V WHERE V.folio_venta = ticket.folio_venta

  	UNION ALL

  	SELECT 'Producto: ' || A.nombre || ' | Cantidad: ' || DV.cantidad::TEXT || ' | Precio: $' || DV.precio_unitario::TEXT
  	FROM DETALLE_VENTA DV
  	JOIN ARTICULO A ON A.codigo_barras = DV.codigo_barra
  	WHERE DV.folio_venta = ticket.folio_venta

  	UNION ALL

  	SELECT 'Total de la venta: $' || V.monto_total::TEXT
  	FROM VENTA V WHERE V.folio_venta = ticket.folio_venta;

END;
$$ LANGUAGE plpgsql;
--Prueba de función:
SELECT * FROM ticket('MBL-000001');

--Vista de tickets
CREATE VIEW vista_tickets AS 
SELECT
	'Factura: ' || UPPER(substr(md5(random()::text), 1, 6)) AS Folio_de_factura,
	V.folio_venta,
	V.fecha_venta,
	COALESCE(C.rfc_cliente::TEXT, 'NO REGISTRADO') AS rfc_cliente,
    A.nombre AS articulo,
    DV.cantidad,
    DV.precio_unitario,
    DV.monto_total_art,
    V.monto_total
FROM VENTA V
LEFT JOIN CLIENTE C ON V.rfc_cliente = C.rfc_cliente
JOIN DETALLE_VENTA DV ON DV.folio_venta = V.folio_venta
JOIN ARTICULO A ON A.codigo_barras = DV.codigo_barra;
	
--Prueba vista de tickets
select * from vista_tickets;

--Borrar para pruebas
--DROP FUNCTION TICKET;
--DROP VIEW vista_tickets;

CREATE OR REPLACE FUNCTION mostrar_ticket_automatico()
RETURNS TRIGGER AS $$
DECLARE
  linea TEXT;
BEGIN
  FOR linea IN SELECT * FROM ticket(NEW.folio_venta)
  LOOP
    RAISE NOTICE '%', linea; --Permitira mostrar mensajes que no interrumpan la ejerución
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER mostrar_ticket
AFTER INSERT ON VENTA
FOR EACH ROW
EXECUTE FUNCTION mostrar_ticket_automatico();

--Prueba
INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente)
VALUES (004, '2024-05-24', 1500.00, 1, 2, 1, 1111111111111);




--Al iniciar una venta, debe validarse que el vendedor y el cajero, pertenezcan a la misma sucursal, en caso de que no sea así, debe mostrarse un mensaje de error.
CREATE OR REPLACE FUNCTION valVendedor_Cajero()
RETURNS TRIGGER AS $$
DECLARE
    suc_vendedor NUMERIC;
    suc_cajero NUMERIC;
    suc_venta NUMERIC;
BEGIN
    -- Obtener la sucursal del vendedor
    SELECT id_sucursal INTO suc_vendedor
    FROM EMPLEADO
    WHERE id_empleado = NEW.empleado_venta;

    -- Obtener la sucursal del cajero
    SELECT id_sucursal INTO suc_cajero
    FROM EMPLEADO
    WHERE id_empleado = NEW.empleado_cobro;

    -- Valida que tanto el cajero como el vendedor esten registrados
    IF suc_vendedor IS NULL OR suc_cajero IS NULL THEN
        RAISE EXCEPTION 'El vendedor o cajero no estan registrados';
    END IF;

    -- Verificar si pertenecen a la misma sucursal
    IF suc_vendedor <> suc_cajero THEN
        RAISE EXCEPTION 'La venta no se puede realizar correctamente, el vendedor y el cajero no pertenecen a la misma sucursal';
    END IF;

    -- Valida que la sucursal que realiza la venta sea la misma DEL CAJERO Y DEL VENDEDORR
    IF NEW.id_sucursal != suc_venta OR NEW.id_sucursal != suc_cajero THEN
        RAISE EXCEPTION 'Los empleados no pertenecen a la misma sucursal de la venta';
    END IF;


    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_Val_Vendedor_Cajero
BEFORE INSERT ON VENTA
FOR EACH ROW
EXECUTE FUNCTION valVendedor_Cajero()
--------------------------------------------------------------------------------------------------------------------------
--PRUEBAS DEL TRIGGER 
--PRUEBA 1: 

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
       (003, '2024-04-22', 1500.00, 1, 2, 2, NULL);
--No se permite realizar la venta ya que los emplleados no pertenecen a la sucursal en dode se esta registrando la venta

--Correccion para poder realiza la venta 
INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
       (003, '2024-04-22', 1500.00, 1, 2, 1, NULL);
	   
--PRUEBA 2: Se tratara de realizar una venta pero el vendedor y el cajero pertenecen a otra sucursal poor lo tanto no se pede realizar. 

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
       (004, '2024-04-22', 1500.00, 1, 3, 2, NULL);

--PRUEB 3: el vendedor no esta  registrado 
INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
       (008, '2024-04-22', 1500.00, 10, 3, 2, NULL);



--Dado el nombre de un empleado, obtener toda la jerarquía organizacional
-- Funcion de obtencion de jerarquía de empleados en direccion ascendente y descendente
-- Justificación:
/*
La función ver_jerarquia_completa nos da la posibilidad de poder conocer la jerarquia que tiene
alguien dentro de la estructura organizacional de la muebleria, dando como resultado las personas
tienen un puesto mayor o menor dentro de la consulta
*/
CREATE OR REPLACE FUNCTION ver_jerarquia_completa(nombre_completo_empleado TEXT)
RETURNS TABLE(relacion TEXT, nombre_completo TEXT, rol TEXT) AS $$
BEGIN
    RETURN QUERY
    WITH RECURSIVE jerarquia_sub AS (
        SELECT 
            'Subordinado'::TEXT AS relacion,
            (e.nombre_empleado || ' ' || e.apellido_pat_empleado || ' ' || COALESCE(e.apellido_mat_empleado, ''))::TEXT AS nombre_completo,
            e.rol::TEXT
        FROM EMPLEADO e
        WHERE e.id_jerarquia_empleado = (
            SELECT id_empleado
            FROM EMPLEADO
            WHERE (nombre_empleado || ' ' || apellido_pat_empleado || ' ' || COALESCE(apellido_mat_empleado, '')) = nombre_completo_empleado
            LIMIT 1
        )
        UNION ALL
        SELECT 
            'Subordinado',
            (e.nombre_empleado || ' ' || e.apellido_pat_empleado || ' ' || COALESCE(e.apellido_mat_empleado, ''))::TEXT,
            e.rol::TEXT
        FROM EMPLEADO e
        JOIN jerarquia_sub js ON e.id_jerarquia_empleado = (
            SELECT id_empleado
            FROM EMPLEADO
            WHERE (nombre_empleado || ' ' || apellido_pat_empleado || ' ' || COALESCE(apellido_mat_empleado, '')) = js.nombre_completo
            LIMIT 1
        )
    ),
    jerarquia_jefe AS (
        SELECT 
            'Jefe'::TEXT AS relacion,
            (e.nombre_empleado || ' ' || e.apellido_pat_empleado || ' ' || COALESCE(e.apellido_mat_empleado, ''))::TEXT AS nombre_completo,
            e.rol::TEXT
        FROM EMPLEADO e
        WHERE e.id_empleado = (
            SELECT id_jerarquia_empleado
            FROM EMPLEADO
            WHERE (nombre_empleado || ' ' || apellido_pat_empleado || ' ' || COALESCE(apellido_mat_empleado, '')) = nombre_completo_empleado
            LIMIT 1
        )
        UNION ALL
        SELECT 
            'Jefe',
            (jefe.nombre_empleado || ' ' || jefe.apellido_pat_empleado || ' ' || COALESCE(jefe.apellido_mat_empleado, ''))::TEXT,
            jefe.rol::TEXT
        FROM EMPLEADO jefe
        JOIN jerarquia_jefe jj ON jefe.id_empleado = (
            SELECT id_jerarquia_empleado
            FROM EMPLEADO
            WHERE (nombre_empleado || ' ' || apellido_pat_empleado || ' ' || COALESCE(apellido_mat_empleado, '')) = jj.nombre_completo
            LIMIT 1
        )
    )
    SELECT * FROM jerarquia_sub
    UNION
    SELECT * FROM jerarquia_jefe;
END;
$$ LANGUAGE plpgsql;

-- Ejemplo de funcionamiento
SELECT * FROM ver_jerarquia_completa('Ana Lopez Hernandez');
SELECT * FROM ver_jerarquia_completa('Luis Gomez Martinez');


--Prueba de datos (INSERT)
--Categoria
INSERT INTO CATEGORIA (id_categoria, nombre_categoria) VALUES
	(1, 'Sillas'),
	(2, 'Mesas');

--Articulo
INSERT INTO ARTICULO (codigo_barras, nombre, precio_venta, precio_compra, stock, fotografia, id_categoria) VALUES
	(10001, 'Silla Gamer', 1500.00, 1000.00, 5, decode('42696E617279496D6731', 'hex'), 1),
	(10002, 'Mesa Oficina', 3000.00, 2000.00, 10, decode('42696E617279496D6732', 'hex'), 2);

UPDATE ARTICULO SET stock = 10 WHERE codigo_barras = 10002;

--Provedoor
INSERT INTO PROVEEDOR (id_proveedor, rfc_prov, razon_social_prov, estado_prov, calle_, cp_prov, telefono_prov, cuenta_pago) VALUES
	(1, 'ABC123456T89', 'Muebles SA', 'CDMX', 'Reforma', '01000', 5551234567, '1234567890123456'),
	(2, 'XYZ987654U32', 'Distribuidora MX', 'Jalisco', 'Juárez', '44100', 3331234567, '6543210987654321');

--Sucursal
INSERT INTO SUCURSAL (id_sucursal, nombre_sucursal, estado_sucursal, calle_sucursal, numero_sucursal, cp_sucursal, telefono_sucursal, ano_fundacion) VALUES
	(1, 'Sucursal Centro', 'CDMX', 'Insurgentes', 101, '03000', 5551122334, 2010),
	(2, 'Sucursal Norte', 'CDMX', 'Tlalpan', 202, '03100', 5556677889, 2015);

--Empleado
INSERT INTO EMPLEADO (id_empleado, rfc, curp, nombre_empleado, apellido_pat_empleado, apellido_mat_empleado,
    estado_empleado, colonia_empleado, calle_empleado, numero_empleado, cp_empleado,
    rfc_empleado, curp_empleado, correo_empleado, rol, fecha_ingreso,
    id_jerarquia_empleado, tipo_empleado, id_sucursal) VALUES
		(1, 'EMPRFC001', 'CURP001111MXDF', 'Luis', 'Gomez', 'Martinez', 'CDMX', 'Roma', 'Durango', 10, '06700', 'EMPRFC001', 'CURP001111MXDF', 'luis@empresa.com', 'Vendedor', '2022-01-10', NULL, 'vendedor', 1),
		(2, 'EMPRFC002', 'CURP002222MXDF', 'Ana', 'Lopez', 'Hernandez', 'CDMX', 'Centro', 'Juarez', 20, '06000', 'EMPRFC002', 'CURP002222MXDF', 'ana@empresa.com', 'Cajero', '2023-03-05', 1, 'cajero', 1),
        (3, 'EMPRFC003', 'CURP003333MXDF', 'Pedro', 'Ramírez', 'Luna', 'CDMX', 'Tlalpan', 'Viaducto', 30, '03500', 'EMPRFC003', 'CURP003333MXDF', 'pedro@empresa.com', 'Vendedor', '2023-06-01', NULL, 'vendedor', 2), 
    	(4, 'EMPRFC004', 'CURP004444MXDF', 'Laura', 'Sánchez', 'Morales', 'CDMX', 'Tlalpan', 'Periférico', 40, '03600', 'EMPRFC004', 'CURP004444MXDF', 'laura@empresa.com', 'Cajero', '2023-07-15', 3, 'cajero', 2);

--Telefono
INSERT INTO TELEFONO (id_empleado, telefono_empleado) VALUES
	(1, 5512345678),
	(2, 5523456789);

INSERT INTO TELEFONO (id_empleado, telefono_empleado) VALUES
    (3, 5534567890),
    (4, 5545678901);

--Cliente
INSERT INTO CLIENTE (rfc_cliente, nombre_cliente, apellido_pat_cliente, apellido_mat__cliente,
    razon_social_cliente, telefono, correo_cliente, estado_cliente, colonia_cliente,
    calle_cliente, numero_cliente, cp_cliente) VALUES
	(1111111111111, 'Carlos', 'Perez', 'Diaz', 'Carlos Perez Diaz', 5544332211, 'carlos@cliente.com', 'CDMX', 'Del Valle', 'Xola', 123, '03100'),
	(2222222222222, 'Lucía', 'Mendez', 'Gomez', 'Lucía Mendez Gomez', 5566778899, 'lucia@cliente.com', 'CDMX', 'Narvarte', 'Universidad', 456, '03200');

--Venta
INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
	(002, '2024-04-21', 3000.00, 1, 2, 1, 2222222222222);

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
	(001, '2024-04-21', 3000.00, 1, 2, 1, 2222222222222);

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES 
	(005, '2024-05-01', 3000.00, 3, 4, 2, 1111111111111);

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal) VALUES 
	(007, '2024-01-01', 4000.00, 3, 4, 2);

--Detalle de venta
INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad, precio_unitario, monto_total_art) VALUES
	('MBL-000001', 10001, 1, 1500.00, 1500.00),
	('MBL-000002', 10002, 1, 3000.00, 3000.00);

INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad, precio_unitario, monto_total_art) VALUES 
	('MBL-000005', 10001, 2, 1500.00, 3000.00);

INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad, precio_unitario, monto_total_art) VALUES 
	('MBL-000007', 10001, 2, 3000.00, 3000.00);

--Provee
INSERT INTO PROVEE (codigo_barra, id_proveedor, fecha_suministro) VALUES
	(10001, 1, '2023-06-10'),
	(10002, 2, '2023-07-15');
	
-----------------------------------------------------------------------------------------------------------------------------------------
-- Ver el contenido de las tablas 

SELECT* FROM CATEGORIA;
SELECT* FROM ARTICULO;
SELECT* FROM PROVEEDOR;
SELECT* FROM SUCURSAL;
SELECT* FROM EMPLEADO;
SELECT* FROM CLIENTE;
SELECT* FROM TELEFONO;
SELECT* FROM VENTA;
SELECT* FROM DETALLE_VENTA;
SELECT* FROM PROVEE;


--Eliminar pruebas
/*
TRUNCATE TABLE 
    DETALLE_VENTA, VENTA, PROVEE, TELEFONO,
    CLIENTE, EMPLEADO, SUCURSAL, ARTICULO, PROVEEDOR, CATEGORIA
RESTART IDENTITY CASCADE;
*/



--Para la parte dos el DashBoard
--Para ambos se crearan vistas
--Cantidad de ingresos totales mensuales por sucursal en un año determinado
CREATE OR REPLACE VIEW vista_ingresos_mensuales AS
SELECT 
    S.id_sucursal,
    S.nombre_sucursal,
    TO_CHAR(V.fecha_venta, 'TMMonth') AS mes,
    EXTRACT(YEAR FROM V.fecha_venta)::INT AS anio,
    SUM(V.monto_total) AS ingresos_totales
FROM VENTA V
JOIN SUCURSAL S ON V.id_sucursal = S.id_sucursal
GROUP BY S.id_sucursal, S.nombre_sucursal, anio, mes
ORDER BY anio, mes, S.nombre_sucursal;
--Prueba de vista
select * FROM vista_ingresos_mensuales;

--DROP VIEW vista_ingresos_mensuales;

--Otra gráfica que considere relevante para usuarios de negocio
--Se opto por crear una vista que muestre que productos se han vendido más
CREATE VIEW vista_articulos_mas_vendidos AS
SELECT 
    A.codigo_barras,
    A.nombre AS articulo,
    SUM(DV.cantidad) AS cantidad_total
FROM DETALLE_VENTA DV
JOIN ARTICULO A ON A.codigo_barras = DV.codigo_barra
GROUP BY A.codigo_barras, A.nombre
ORDER BY cantidad_total DESC;
--Prueba vista
select * from vista_articulos_mas_vendidos;


--Prefijo MLB para folio de venta
CREATE OR REPLACE FUNCTION pre_folioVenta()
RETURNS TRIGGER AS $$
BEGIN
	IF NEW.folio_venta IS NULL THEN
		RAISE EXCEPTION 'JAJA NO';
	END IF;
	
	IF NEW.folio_venta NOT LIKE 'MBL-%' THEN
		NEW.folio_venta := 'MBL-' || LPAD(NEW.folio_venta, 6, '0');
	END IF;
	RETURN NEW;
END;
$$ LANGUAGE plpgsql;
	
CREATE OR REPLACE TRIGGER pre_folioVen
BEFORE INSERT ON VENTA
FOR EACH ROW
EXECUTE FUNCTION pre_folioVenta();

--Para nuclear
/*
DROP TABLE IF EXISTS 
    DETALLE_VENTA,
    VENTA,
    PROVEE,
    TELEFONO,
    EMPLEADO,
    CLIENTE,
    ARTICULO,
    PROVEEDOR,
    CATEGORIA,
    SUCURSAL
CASCADE;
*/