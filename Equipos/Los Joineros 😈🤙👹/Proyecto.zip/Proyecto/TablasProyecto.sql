--Script de creación de la base de datos y tablas
-- Tabla CATEGORIA
CREATE TABLE CATEGORIA (
    id_categoria NUMERIC PRIMARY KEY,
    nombre_categoria VARCHAR(50) NOT NULL
);


-- Tabla ARTICULO
CREATE TABLE ARTICULO (
    codigo_barras NUMERIC(20) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    precio_venta NUMERIC NOT NULL,
    precio_compra NUMERIC NOT NULL,
    stock NUMERIC NOT NULL,
    fotografia BYTEA NOT NULL,
    id_categoria NUMERIC NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES CATEGORIA(id_categoria)
);

-- Tabla PROVEEDOR
CREATE TABLE PROVEEDOR (
    id_proveedor NUMERIC PRIMARY KEY,
    rfc_prov VARCHAR(13) NOT NULL,
    razon_social_prov VARCHAR(50) NOT NULL,
    estado_prov VARCHAR(30) NOT NULL,
    calle_ VARCHAR(30) NOT NULL,
    cp_prov VARCHAR(5) NOT NULL,
    telefono_prov NUMERIC NOT NULL,
    cuenta_pago VARCHAR(16) NOT NULL
);

--Tabla SUCURSAL
CREATE TABLE SUCURSAL (
    id_sucursal NUMERIC PRIMARY KEY,
    nombre_sucursal VARCHAR(30) NOT NULL,
    estado_sucursal VARCHAR(30) NOT NULL,
    calle_sucursal VARCHAR(30) NOT NULL,
    numero_sucursal NUMERIC NOT NULL,
    cp_sucursal VARCHAR(5) NOT NULL,
    telefono_sucursal NUMERIC NOT NULL,
    ano_fundacion NUMERIC NOT NULL
);

-- Tabla EMPLEADO
CREATE TABLE EMPLEADO (
    id_empleado NUMERIC PRIMARY KEY,
    rfc VARCHAR(13) NOT NULL,
    curp VARCHAR(18) NOT NULL,
    nombre_empleado VARCHAR(30) NOT NULL,
    apellido_pat_empleado VARCHAR(30) NOT NULL,
    apellido_mat_empleado VARCHAR(30),
    estado_empleado VARCHAR(30) NOT NULL,
    colonia_empleado VARCHAR(30) NOT NULL,
    calle_empleado VARCHAR(30) NOT NULL,
    numero_empleado NUMERIC NOT NULL,
    cp_empleado VARCHAR(5) NOT NULL,
    rfc_empleado VARCHAR(13) NOT NULL,
    curp_empleado VARCHAR(18) NOT NULL,
    correo_empleado VARCHAR(100) NOT NULL,
    rol VARCHAR(50) NOT NULL,
    fecha_ingreso DATE NOT NULL,
    id_jerarquia_empleado NUMERIC,
    tipo_empleado VARCHAR(30) NOT NULL,
    id_sucursal NUMERIC,
    FOREIGN KEY (id_jerarquia_empleado) REFERENCES EMPLEADO(id_empleado),
    FOREIGN KEY (id_sucursal) REFERENCES SUCURSAL(id_sucursal)
);

-- Tabla TELEFONO DEL EMPLEADO 
CREATE TABLE TELEFONO (
    id_empleado NUMERIC PRIMARY KEY,
    telefono_empleado NUMERIC UNIQUE NOT NULL,
    FOREIGN KEY (id_empleado) REFERENCES EMPLEADO(id_empleado)
);

-- Tabla CLIENTE
CREATE TABLE CLIENTE (
    rfc_cliente NUMERIC(13) PRIMARY KEY,
    nombre_cliente VARCHAR(30) NOT NULL,
    apellido_pat_cliente VARCHAR(30) NOT NULL,
    apellido_mat__cliente VARCHAR(30),
    razon_social_cliente VARCHAR(50) NOT NULL,
    telefono NUMERIC NOT NULL,
    correo_cliente VARCHAR(100) NOT NULL,
    estado_cliente VARCHAR(30) NOT NULL,
    colonia_cliente VARCHAR(30) NOT NULL,
    calle_cliente VARCHAR(30) NOT NULL,
    numero_cliente NUMERIC NOT NULL,
    cp_cliente VARCHAR(5) NOT NULL
);


-- Tabla VENTA
CREATE TABLE VENTA (
    folio_venta VARCHAR(10) PRIMARY KEY,
    fecha_venta DATE NOT NULL,
    monto_total NUMERIC NOT NULL,
    empleado_venta NUMERIC NOT NULL,
    empleado_cobro NUMERIC NOT NULL,
    id_sucursal NUMERIC NOT NULL,
	rfc_cliente NUMERIC(13),
    FOREIGN KEY (empleado_venta) REFERENCES EMPLEADO(id_empleado),
    FOREIGN KEY (empleado_cobro) REFERENCES EMPLEADO(id_empleado),
    FOREIGN KEY (id_sucursal) REFERENCES SUCURSAL(id_sucursal),
	FOREIGN KEY (rfc_cliente) REFERENCES CLIENTE(rfc_cliente)
);


-- Tabla DETALLE_VENTA
CREATE TABLE DETALLE_VENTA (
    folio_venta VARCHAR(10) NOT NULL,
    codigo_barra NUMERIC(20) NOT NULL,
    cantidad NUMERIC NOT NULL,
    precio_unitario NUMERIC NOT NULL,
    monto_total_art NUMERIC NOT NULL,
    PRIMARY KEY (folio_venta, codigo_barra),
    FOREIGN KEY (folio_venta) REFERENCES VENTA(folio_venta),
    FOREIGN KEY (codigo_barra) REFERENCES ARTICULO(codigo_barras)
);

-- Tabla PROVEE
CREATE TABLE PROVEE (
    codigo_barra NUMERIC(20) NOT NULL,
    id_proveedor NUMERIC NOT NULL,
    fecha_suministro DATE NOT NULL,
    PRIMARY KEY (codigo_barra, id_proveedor),
    FOREIGN KEY (codigo_barra) REFERENCES ARTICULO(codigo_barras),
    FOREIGN KEY (id_proveedor) REFERENCES PROVEEDOR(id_proveedor)
);