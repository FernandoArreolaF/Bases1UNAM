--Prueba de datos (INSERT)
--Categoria
INSERT INTO CATEGORIA (id_categoria, nombre_categoria) VALUES
	(1, 'Sillas'),
	(2, 'Mesas');

INSERT INTO CATEGORIA (id_categoria, nombre_categoria) VALUES
	(3, 'Escritorios'),
	(4, 'Libreros'),
	(5, 'Sofás'),
	(6, 'Camas'),
	(7, 'Alacenas');


--Articulo
INSERT INTO ARTICULO (codigo_barras, nombre, precio_venta, precio_compra, stock, fotografia, id_categoria) VALUES
	(10001, 'Silla Gamer', 1500.00, 1000.00, 5, decode('42696E617279496D6731', 'hex'), 1),
	(10002, 'Mesa Oficina', 3000.00, 2000.00, 10, decode('42696E617279496D6732', 'hex'), 2);

UPDATE ARTICULO SET stock = 10 WHERE codigo_barras = 10002;

INSERT INTO ARTICULO (codigo_barras, nombre, precio_venta, precio_compra, stock, fotografia, id_categoria) VALUES
	(10003, 'Escritorio Ejecutivo', 4500.00, 3000.00, 7, decode('42696E617279496D6733', 'hex'), 3),
	(10004, 'Librero Moderno', 2500.00, 1500.00, 15, decode('42696E617279496D6734', 'hex'), 4),
	(10005, 'Sofá de 3 plazas', 6000.00, 4000.00, 4, decode('42696E617279496D6735', 'hex'), 5),
	(10006, 'Cama King Size', 8000.00, 5000.00, 3, decode('42696E617279496D6736', 'hex'), 6),
	(10007, 'Alacena Vintage', 3500.00, 2000.00, 6, decode('42696E617279496D6737', 'hex'), 7);



--Provedoor
INSERT INTO PROVEEDOR (id_proveedor, rfc_prov, razon_social_prov, estado_prov, calle_, cp_prov, telefono_prov, cuenta_pago) VALUES
	(1, 'ABC123456T89', 'Muebles SA', 'CDMX', 'Reforma', '01000', 5551234567, '1234567890123456'),
	(2, 'XYZ987654U32', 'Distribuidora MX', 'Jalisco', 'Juárez', '44100', 3331234567, '6543210987654321');

INSERT INTO PROVEEDOR (id_proveedor, rfc_prov, razon_social_prov, estado_prov, calle_, cp_prov, telefono_prov, cuenta_pago) VALUES
	(3, 'LMN456789A00', 'Muebles del Centro', 'EdoMex', 'Toluca', '50000', 7221234567, '3216549873214560'),
	(4, 'OPQ321654B55', 'Mueblería Nacional', 'Puebla', 'Zaragoza', '72000', 2227654321, '4561237896543210'),
	(5, 'RST789123C11', 'Fábrica Hogar', 'Querétaro', 'Constituyentes', '76000', 4423334444, '7894561237894561'),
	(6, 'UVW159753D22', 'Sillones Elite', 'Nuevo León', 'Garza Sada', '64000', 8181231234, '1593572584567890'),
	(7, 'XYZ258456E33', 'Muebles Rústicos', 'Guanajuato', 'Juárez', '37000', 4771122334, '2584561593578520');

--Sucursal
INSERT INTO SUCURSAL (id_sucursal, nombre_sucursal, estado_sucursal, calle_sucursal, numero_sucursal, cp_sucursal, telefono_sucursal, ano_fundacion) VALUES
	(1, 'Sucursal Centro', 'CDMX', 'Insurgentes', 101, '03000', 5551122334, 2010),
	(2, 'Sucursal Norte', 'CDMX', 'Tlalpan', 202, '03100', 5556677889, 2015);

INSERT INTO SUCURSAL (id_sucursal, nombre_sucursal, estado_sucursal, calle_sucursal, numero_sucursal, cp_sucursal, telefono_sucursal, ano_fundacion) VALUES
	(3, 'Sucursal Sur', 'CDMX', 'Revolución', 303, '03400', 5557788990, 2020),
	(4, 'Sucursal Oriente', 'CDMX', 'Ignacio Zaragoza', 404, '03500', 5559988776, 2018),
	(5, 'Sucursal Poniente', 'CDMX', 'Mixcoac', 505, '03600', 5558877665, 2017),
	(6, 'Sucursal Satélite', 'EdoMex', 'Periférico', 606, '53100', 5551122446, 2019),
	(7, 'Sucursal Toluca', 'EdoMex', 'Morelos', 707, '50000', 7223344556, 2016);


--Empleado
INSERT INTO EMPLEADO (id_empleado, rfc, curp, nombre_empleado, apellido_pat_empleado, apellido_mat_empleado,
    estado_empleado, colonia_empleado, calle_empleado, numero_empleado, cp_empleado,
    rfc_empleado, curp_empleado, correo_empleado, rol, fecha_ingreso,
    id_jerarquia_empleado, tipo_empleado, id_sucursal) VALUES
		(1, 'EMPRFC001', 'CURP001111MXDF', 'Luis', 'Gomez', 'Martinez', 'CDMX', 'Roma', 'Durango', 10, '06700', 'EMPRFC001', 'CURP001111MXDF', 'luis@empresa.com', 'Vendedor', '2022-01-10', NULL, 'vendedor', 1),
		(2, 'EMPRFC002', 'CURP002222MXDF', 'Ana', 'Lopez', 'Hernandez', 'CDMX', 'Centro', 'Juarez', 20, '06000', 'EMPRFC002', 'CURP002222MXDF', 'ana@empresa.com', 'Cajero', '2023-03-05', 1, 'cajero', 1),
        (3, 'EMPRFC003', 'CURP003333MXDF', 'Pedro', 'Ramírez', 'Luna', 'CDMX', 'Tlalpan', 'Viaducto', 30, '03500', 'EMPRFC003', 'CURP003333MXDF', 'pedro@empresa.com', 'Vendedor', '2023-06-01', NULL, 'vendedor', 2), 
    	(4, 'EMPRFC004', 'CURP004444MXDF', 'Laura', 'Sánchez', 'Morales', 'CDMX', 'Tlalpan', 'Periférico', 40, '03600', 'EMPRFC004', 'CURP004444MXDF', 'laura@empresa.com', 'Cajero', '2023-07-15', 3, 'cajero', 2);

INSERT INTO EMPLEADO (id_empleado, rfc, curp, nombre_empleado, apellido_pat_empleado, apellido_mat_empleado,
    estado_empleado, colonia_empleado, calle_empleado, numero_empleado, cp_empleado,
    rfc_empleado, curp_empleado, correo_empleado, rol, fecha_ingreso,
    id_jerarquia_empleado, tipo_empleado, id_sucursal) VALUES
	(5, 'EMPRFC005', 'CURP005555MXDF', 'Diego', 'Flores', 'Rivera', 'CDMX', 'Del Valle', 'Coyoacán', 50, '03700', 'EMPRFC005', 'CURP005555MXDF', 'diego@empresa.com', 'Vendedor', '2023-05-10', NULL, 'vendedor', 3),
	(6, 'EMPRFC006', 'CURP006666MXDF', 'Andrea', 'Martínez', 'Soto', 'CDMX', 'Coyoacán', 'Insurgentes Sur', 60, '03800', 'EMPRFC006', 'CURP006666MXDF', 'andrea@empresa.com', 'Cajero', '2023-06-20', 5, 'cajero', 3),
	(7, 'EMPRFC007', 'CURP007777MXDF', 'Santiago', 'Reyes', 'Mora', 'CDMX', 'Centro', 'Tacuba', 70, '03900', 'EMPRFC007', 'CURP007777MXDF', 'santiago@empresa.com', 'Vendedor', '2024-01-15', NULL, 'vendedor', 4),
	(8, 'EMPRFC008', 'CURP008888MXDF', 'Valeria', 'Núñez', 'Rojas', 'CDMX', 'Roma', 'Álvaro Obregón', 80, '04000', 'EMPRFC008', 'CURP008888MXDF', 'valeria@empresa.com', 'Cajero', '2024-02-10', 7, 'cajero', 4),
	(9, 'EMPRFC009', 'CURP009999MXDF', 'Emilio', 'Castañeda', 'Ortiz', 'CDMX', 'Narvarte', 'Bucareli', 90, '04100', 'EMPRFC009', 'CURP009999MXDF', 'emilio@empresa.com', 'Vendedor', '2024-03-01', NULL, 'vendedor', 5);



--Telefono
INSERT INTO TELEFONO (id_empleado, telefono_empleado) VALUES
	(1, 5512345678),
	(2, 5523456789);

INSERT INTO TELEFONO (id_empleado, telefono_empleado) VALUES
    (3, 5534567890),
    (4, 5545678901);

INSERT INTO TELEFONO (id_empleado, telefono_empleado) VALUES
	(5, 5556789012),
	(6, 5557890123),
	(7, 5558901234),
	(8, 5559012345),
	(9, 5560123456);


--Cliente
INSERT INTO CLIENTE (rfc_cliente, nombre_cliente, apellido_pat_cliente, apellido_mat__cliente,
    razon_social_cliente, telefono, correo_cliente, estado_cliente, colonia_cliente,
    calle_cliente, numero_cliente, cp_cliente) VALUES
	(1111111111111, 'Carlos', 'Perez', 'Diaz', 'Carlos Perez Diaz', 5544332211, 'carlos@cliente.com', 'CDMX', 'Del Valle', 'Xola', 123, '03100'),
	(2222222222222, 'Lucía', 'Mendez', 'Gomez', 'Lucía Mendez Gomez', 5566778899, 'lucia@cliente.com', 'CDMX', 'Narvarte', 'Universidad', 456, '03200');

INSERT INTO CLIENTE (rfc_cliente, nombre_cliente, apellido_pat_cliente, apellido_mat__cliente,
    razon_social_cliente, telefono, correo_cliente, estado_cliente, colonia_cliente,
    calle_cliente, numero_cliente, cp_cliente) VALUES
	(3333333333333, 'María', 'García', 'Torres', 'María García Torres', 5511223344, 'maria@cliente.com', 'CDMX', 'Portales', 'División del Norte', 321, '03300'),
	(4444444444444, 'José', 'Hernández', 'Sánchez', 'José Hernández Sánchez', 5522334455, 'jose@cliente.com', 'CDMX', 'Escandón', 'Patriotismo', 654, '03400'),
	(5555555555555, 'Fernanda', 'López', 'Jiménez', 'Fernanda López Jiménez', 5533445566, 'fernanda@cliente.com', 'CDMX', 'Anzures', 'Ejército Nacional', 987, '03500'),
	(6666666666666, 'Ricardo', 'Ramírez', 'Delgado', 'Ricardo Ramírez Delgado', 5544556677, 'ricardo@cliente.com', 'CDMX', 'Tacuba', 'Marina Nacional', 111, '03600'),
	(7777777777777, 'Alejandra', 'Cruz', 'Vega', 'Alejandra Cruz Vega', 5555667788, 'alejandra@cliente.com', 'CDMX', 'Lindavista', 'Montevideo', 222, '03700');


--Venta
INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
	(002, '2024-04-21', 3000.00, 1, 2, 1, 2222222222222);

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
	(001, '2024-04-21', 3000.00, 1, 2, 1, 2222222222222);

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES 
	(005, '2024-05-01', 3000.00, 3, 4, 2, 1111111111111);

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal) VALUES 
	(007, '2024-01-01', 4000.00, 3, 4, 2);

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
	(006, '2024-05-04', 8000.00, 5, 6, 3, 5555555555555);

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
	(008, '2024-05-05', 3500.00, 7, 8, 4, 6666666666666);

--Detalle de venta
INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad, precio_unitario, monto_total_art) VALUES
	('MBL-000001', 10001, 1, 1500.00, 1500.00),
	('MBL-000002', 10002, 1, 3000.00, 3000.00);

INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad, precio_unitario, monto_total_art) VALUES 
	('MBL-000005', 10001, 2, 1500.00, 3000.00);

INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad, precio_unitario, monto_total_art) VALUES 
	('MBL-000007', 10001, 2, 3000.00, 3000.00);

INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad, precio_unitario, monto_total_art) VALUES
	('MBL-000003', 10004, 1, 2500.00, 2500.00),
	('MBL-000004', 10005, 1, 6000.00, 6000.00),
	('MBL-000006', 10006, 1, 8000.00, 8000.00),
	('MBL-000008', 10007, 1, 3500.00, 3500.00);



--Provee
INSERT INTO PROVEE (codigo_barra, id_proveedor, fecha_suministro) VALUES
	(10001, 1, '2023-06-10'),
	(10002, 2, '2023-07-15');

INSERT INTO PROVEE (codigo_barra, id_proveedor, fecha_suministro) VALUES
	(10003, 3, '2023-08-01'),
	(10004, 4, '2023-09-05'),
	(10005, 5, '2023-10-10'),
	(10006, 6, '2023-11-15'),
	(10007, 7, '2023-12-20');


--Pruebas para las funciones escenciales del proyecto
--Cada que se agregue un artículo a una venta, debe actualizarse los totales (por artículo, venta y cantidad de artículos), así como validar que elartículo esté disponible.
--PRUEBA DE LOS TRIGGERS

INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad)
VALUES (001, 99999, 1); -- Usamos la venta existente 1000001 para insertar un articulo que no existe


INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad)
VALUES (001, 10002, 1); -- Intentamos vender 1 unidad del artículo 10002 y nos va a salir con stock insuficiente 

--Prueba 3: Inserción VÁLIDA en una VENTA NUEVA y VACÍA

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente)
VALUES (003, CURRENT_DATE, 0.00, 1, 2, 1, 2222222222222); --Se crea una venta vacia para que visualicemos que si funcionan los triggers

SELECT stock FROM ARTICULO WHERE codigo_barras = 10001; -- Nos da un resultado de 5
SELECT monto_total FROM VENTA WHERE folio_venta = 003; -- Nos da un resultado de 0.00

INSERT INTO DETALLE_VENTA (folio_venta, codigo_barra, cantidad)
VALUES (004, 10001, 2); -- Vendemos 2 unidades

-- Y ahora haces un update:
UPDATE DETALLE_VENTA
SET cantidad = 3
WHERE folio_venta = 003 AND codigo_barra = 10001;


SELECT precio_unitario, monto_total_art FROM DETALLE_VENTA
WHERE folio_venta = 003 AND codigo_barra = 10001; --Precio unitario y total de los 2 articulos

SELECT stock FROM ARTICULO WHERE codigo_barras = 10001;--El stock cambio a 3 unidades

SELECT monto_total FROM VENTA WHERE folio_venta = 1000003;--Tenemos el total por los dos articulos


--Crear al menos, un índice, del tipo que se prefiera y donde se prefiera. Justificar el porqué de la elección en ambos aspectos.
--Prueba de indice
EXPLAIN ANALYZE --Juntar con la linea de abajo para observar el rendimiento
select * FROM ARTICULO;

--Prueba de indice
EXPLAIN ANALYZE --Juntar con la linea de abajo para observar el rendimiento
select * FROM DETALLE_VENTA;

--Prueba de indice
EXPLAIN ANALYZE --Juntar con la linea de abajo para observar el rendimiento
SELECT * FROM ARTICULO WHERE stock < 3;


--Lista de artículos no disponibles o con stock < 3. Si el artículo no está disponible, debe aparecer el mensaje ”No disponible”.
--Prueba de consultas
select * FROM ARTICULO;

SELECT * FROM no_disponibles;

SELECT * FROM disponibles;

select * FROM VENTA;


-- De manera automática se genere una vista que contenga información necesaria para asemejarse a un ticket de venta, incluyendo un folio para facturación (caracteres aleatorios).
--Prueba de función:
SELECT * FROM ticket('MBL-000001');

--Prueba vista de tickets
select * from vista_tickets;

--Prueba
INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente)
VALUES (004, '2024-05-24', 1500.00, 1, 2, 1, 1111111111111);


--Al iniciar una venta, debe validarse que el vendedor y el cajero, pertenezcan a la misma sucursal, en caso de que no sea así, debe mostrarse un mensaje de error.
--PRUEBAS DEL TRIGGER 
--PRUEBA 1: 

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
       (003, '2024-04-22', 1500.00, 1, 2, 2, NULL);
--No se permite realizar la venta ya que los emplleados no pertenecen a la sucursal en dode se esta registrando la venta

--Correccion para poder realiza la venta 
INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
       (003, '2024-04-22', 1500.00, 1, 2, 1, NULL);
	   
--PRUEBA 2: Se tratara de realizar una venta pero el vendedor y el cajero pertenecen a otra sucursal poor lo tanto no se pede realizar. 

INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
       (004, '2024-04-22', 1500.00, 1, 3, 2, NULL);

--PRUEB 3: el vendedor no esta  registrado 
INSERT INTO VENTA (folio_venta, fecha_venta, monto_total, empleado_venta, empleado_cobro, id_sucursal, rfc_cliente) VALUES
       (008, '2024-04-22', 1500.00, 10, 3, 2, NULL);


--Dado el nombre de un empleado, obtener toda la jerarquía organizacional
-- Ejemplo de funcionamiento
SELECT * FROM ver_jerarquia_completa('Ana Lopez Hernandez');
SELECT * FROM ver_jerarquia_completa('Luis Gomez Martinez');