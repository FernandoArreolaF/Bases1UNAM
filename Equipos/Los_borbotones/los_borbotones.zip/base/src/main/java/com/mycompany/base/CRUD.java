
package com.mycompany.base;
import java.io.InputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class CRUD {
    
    int NumeroEmp;
    
    public int getNumeroEmp() {
        return NumeroEmp;
    }

    public void setNumeroEmp(int NumeroEmp) {
        this.NumeroEmp = NumeroEmp;
    }
    
    
    public void Mostrar(JTable paramEmp, String id){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("Número de Empleado");
        modelo.addColumn("RFC");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido Paterno");
        modelo.addColumn("Apellido Materno");
        
        
        
        paramEmp.setModel(modelo);
        
        sql = "select num_empleado,rfc_emp,nombre_emp,ap_pat_emp,ap_mat_emp from empleado where num_empleado ='"+id+"' ";
        
        
        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
   
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
        
        
        
        
        
        
    }
    
    
     public void MostrarDos(JTable paramEmp, String id){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("Sueldo");
        modelo.addColumn("Edad");
        modelo.addColumn("Fecha de nacimiento");
        modelo.addColumn("Calle");
        modelo.addColumn("CP");
        
        
        paramEmp.setModel(modelo);
        
        sql = "select sueldo_emp, edad_emp, fecha_nacimiento_emp, calle_emp,cp_emp from empleado where num_empleado = '"+id+"' ";
        


        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
            
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
    
    
}

     public void Mostrarcuatro(JTable paramEmp, String id){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("Numero exterior");
        modelo.addColumn("Colonia");
        modelo.addColumn("Estado");
        modelo.addColumn("Cocinero");
        modelo.addColumn("Especialidad");
        
        
        
        paramEmp.setModel(modelo);
        
        sql = "select numero_emp, colonia_emp, estado_emp, es_cocinero, especialidad from empleado where num_empleado = '"+id+"' ";
        


        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
            
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
    
    
}
     
     public void Mostrarcinco(JTable paramEmp, String id){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("Mesero");
        modelo.addColumn("Horario");
        modelo.addColumn("Administrador");
        modelo.addColumn("Rol");
        
        
        
        paramEmp.setModel(modelo);
        
        sql = "select es_mesero, horario, es_admin, rol from empleado where num_empleado = '"+id+"' ";
        


        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
            
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
    
    
}
     
     public void Orden(String registro, int numeroEmp, String rfc){
        CConexion conect = new CConexion();
        String consulta = "select ingreso_alimentos(?, ?, ?);";              
        try{
            
            CallableStatement ct = conect.establecerConexion().prepareCall(consulta);
            ct.setString(1,registro);
            ct.setInt(2, numeroEmp);
            ct.setString(3,rfc);
            
            ct.execute();          
            
            
           
            
            JOptionPane.showMessageDialog(null,"Se registro los  datos correctamente");
           
         }catch(Exception e){
             JOptionPane.showMessageDialog(null,"No se registro los  datos correctamente, error " +e.toString());
         }
         
         
         
     }

      public void MostrarTres(JTable paramEmp){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        
        modelo.addColumn("ID");
        modelo.addColumn("Producto");
        modelo.addColumn("Precio");
        
        
        paramEmp.setModel(modelo);
        
        sql = "select id_alimento, nombre, precio from alimento ";
        


        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
        
        
    
    
}
     
     
   public void orden_vista_tabla(JTable paramEmp){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("");
       
        
        paramEmp.setModel(modelo);
        
        sql = "select max(folio_orden) as folio_orden from orden";
        
        
        
        String [] datos = new String[1];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
        
        
        
        
        
        
    }  
     
     public void contener(String folio, String id, int cantidad){
        CConexion conect = new CConexion();
        String consulta = "select validador_alimento(?, ?, ?);";              
        try{
            
            CallableStatement ct = conect.establecerConexion().prepareCall(consulta);
            ct.setString(1,folio);
            ct.setString(2, id);
            ct.setInt(3,cantidad);
            
            ct.execute();          
            
           
            JOptionPane.showMessageDialog(null,"Se registro los  datos correctamente");
           
         }catch(Exception e){
             JOptionPane.showMessageDialog(null,"No se registro los  datos correctamente, error " +e.toString());
         }
         
         
         
     }
     
   
   public void insert(String nombre, String apellidoPaterno, String apellidoMaterno, String fechaNacimiento, int edad, String estado, int codigoPostal, String calle, int numero, String colonia, int numeroEmpleado, String rfc, int sueldo, String rol, String especialidad, boolean admin, boolean cocinero, boolean mesero, String horario, InputStream x, long foto){
       CConexion conect = new CConexion();
        String consulta = "INSERT INTO empleado VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";  
        
        try{
            java.sql.Date FH = java.sql.Date.valueOf(fechaNacimiento);
            
            
            CallableStatement ct = conect.establecerConexion().prepareCall(consulta);
            ct.setInt(1,numeroEmpleado);
            ct.setString(2, rfc);
            ct.setDate(3, FH);
            ct.setString(4,calle);
            ct.setInt(5,codigoPostal);
            ct.setInt(6,numero);
            ct.setString(7,colonia);
            ct.setString(8,estado);
            ct.setString(9,nombre);
            ct.setString(10,apellidoPaterno);
            ct.setString(11,apellidoMaterno);
            ct.setInt(12,sueldo);
            ct.setInt(13,edad);
            ct.setBinaryStream(14,x,foto);
            ct.setBoolean(15,cocinero);
            ct.setString(16,especialidad);
            ct.setBoolean(17,mesero);
            ct.setString(18,horario);
            ct.setBoolean(19,admin);
            ct.setString(20,rol);
            
            ct.execute();          
            
            
           
            
            JOptionPane.showMessageDialog(null,"Se registro los  datos correctamente");
           
         }catch(Exception e){
             JOptionPane.showMessageDialog(null,"No se registro los  datos correctamente, error " +e.toString());
         }
   }
   
   public void Mostrarfactura1(JTable paramEmp, String folio, String rfc){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("");
        
        
        paramEmp.setModel(modelo);
        
        sql = "select nombre_cliente from factura where folio_orden = '"+folio+"' and rfc_cliente = '"+rfc+"' ";
        
        
        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
        
        
        
        
        
        
    }
   
   public void Mostrarfactura2(JTable paramEmp, String folio, String rfc){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("");
        modelo.addColumn("");
        modelo.addColumn("");
        
        
        paramEmp.setModel(modelo);
        
        sql = "select colonia_cliente, estado_cliente, cp_cliente from factura where folio_orden = '"+folio+"' and rfc_cliente = '"+rfc+"' ";
        
        
        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
        
        
        
        
        
        
    }
   
   public void Mostrarfactura3(JTable paramEmp, String folio, String rfc){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("");
        modelo.addColumn("");
       
        
        paramEmp.setModel(modelo);
        
        sql = "select calle_cliente, numero_cliente from factura where folio_orden = '"+folio+"' and rfc_cliente = '"+rfc+"' ";
        
        
        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
        
        
        
        
        
        
    }
   
   public void Mostrarfactura4(JTable paramEmp, String folio, String rfc){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("");
        
       
        
        paramEmp.setModel(modelo);
        
        sql = "select email from factura where folio_orden = '"+folio+"' and rfc_cliente = '"+rfc+"' ";
        
        
        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
               
                
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
        
        
        
        
        
        
    }
   
   public void Mostrarfactura5(JTable paramEmp, String folio, String rfc){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("");
        
       
        
        paramEmp.setModel(modelo);
        
        sql = "select fecha_orden where folio_orden = '"+folio+"' and rfc_cliente = '"+rfc+"' ";
        
        
        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
               
                
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
        
        
        
        
        
        
    }
   
   public void Mostrarfactura6(JTable paramEmp, String folio){
        CConexion objetoConexion = new CConexion();
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql = "";
        modelo.addColumn("FOLIO");
        modelo.addColumn("ID ALIMENTO");
        modelo.addColumn("PRECIO");
        modelo.addColumn("CANTIDAD");
        modelo.addColumn("SUBTOTAL");
       
        
        paramEmp.setModel(modelo);
        
        sql = "select * from contener where folio_orden = '"+folio+"'";
        
        
        
        String [] datos = new String[20];      
        Statement st;
        try{
            
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
               
                
                modelo.addRow(datos);
            }
            paramEmp.setModel(modelo);
            
        }catch(Exception e){
            
        }
        
        
        
        
        
        
    }
}
