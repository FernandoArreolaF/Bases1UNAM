
package com.mycompany.base;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class CConexion {
    Connection conectar = null;
    String usuario = "postgres";
    String contrasenia = "larios.2022";
    String bd = "proyectoFinal";
    String ip ="localhost";
    String Puerto = "5432";
    String cadena ="jdbc:postgresql://"+ip+":"+Puerto+"/"+bd;

    public Connection establecerConexion(){
        try{
            Class.forName("org.postgresql.Driver");
            conectar = DriverManager.getConnection(cadena,usuario,contrasenia);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error al conectar a la base de datos, error " +e.toString());
        }
        return conectar;
    }

}
