
package vistas.proyecto ;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;




public class conexionsql {
    Connection conectar = null;
    String usuario = "postgres";
    String contrasenia = "admin";
    String bd = "proyecto";
    String ip ="localhost";
    String Puerto = "5432";
    String cadena ="jdbc:postgresql://"+ip+":"+Puerto+"/"+bd;
    
    
    public Connection establecerConexion(){
        try{
            Class.forName("org.postgresql.Driver");
            conectar = DriverManager.getConnection(cadena,usuario,contrasenia);
            JOptionPane.showMessageDialog(null,"Se conectó a la base de datos correctamente");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error al conectar a la base de datos, error " +e.toString());
        }
        return conectar;
    }
     
}
