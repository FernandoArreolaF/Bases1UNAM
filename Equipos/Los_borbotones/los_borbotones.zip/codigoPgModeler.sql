-- Database generated with pgModeler (PostgreSQL Database Modeler).
-- pgModeler  version: 0.9.2
-- PostgreSQL version: 12.0
-- Project Site: pgmodeler.io
-- Model Author: ---


-- Database creation must be done outside a multicommand file.
-- These commands were put in this file only as a convenience.
-- -- object: new_database | type: DATABASE --
-- -- DROP DATABASE IF EXISTS new_database;
-- CREATE DATABASE new_database;
-- -- ddl-end --
-- 

-- object: public."EMPLEADO" | type: TABLE --
-- DROP TABLE IF EXISTS public."EMPLEADO" CASCADE;
CREATE TABLE public."EMPLEADO" (
	num_empleado numeric NOT NULL,
	rfc_emp varchar(13) NOT NULL,
	fecha_nacimiento_emp date NOT NULL,
	calle_emp varchar(50) NOT NULL,
	cp_emp smallint NOT NULL,
	numero_emp varchar(15) NOT NULL,
	colonia_emp varchar(80) NOT NULL,
	estado_emp varchar(25) NOT NULL,
	nombre_emp varchar(50) NOT NULL,
	ap_pat_emp varchar(25) NOT NULL,
	ap_mat_emp varchar(25),
	sueldo_emp money NOT NULL,
	edad_emp smallint NOT NULL,
	foto_emp bytea NOT NULL,
	es_cocinero bool NOT NULL,
	especialidad varchar(15) NOT NULL,
	es_mesero bool NOT NULL,
	horario timestamp NOT NULL,
	es_admin bool NOT NULL,
	rol varchar(15) NOT NULL,
	CONSTRAINT "EMPLEADO_pk" PRIMARY KEY (num_empleado)

);
-- ddl-end --
-- ALTER TABLE public."EMPLEADO" OWNER TO postgres;
-- ddl-end --

-- object: public."DEPENDIENTE" | type: TABLE --
-- DROP TABLE IF EXISTS public."DEPENDIENTE" CASCADE;
CREATE TABLE public."DEPENDIENTE" (
	curp varchar(18) NOT NULL,
	parentesco varchar(15) NOT NULL,
	"num_empleado_EMPLEADO" numeric NOT NULL,
	CONSTRAINT "DEPENDIENTE_pk" PRIMARY KEY (curp)

);
-- ddl-end --
-- ALTER TABLE public."DEPENDIENTE" OWNER TO postgres;
-- ddl-end --

-- object: public."ALIMENTO" | type: TABLE --
-- DROP TABLE IF EXISTS public."ALIMENTO" CASCADE;
CREATE TABLE public."ALIMENTO" (
	id_alimento varchar(10) NOT NULL,
	nombre varchar(30) NOT NULL,
	descripcion varchar(200) NOT NULL,
	receta varchar(100) NOT NULL,
	disponibilidad bool NOT NULL,
	precio money NOT NULL,
	CONSTRAINT "ALIMENTO_pk" PRIMARY KEY (id_alimento)

);
-- ddl-end --
-- ALTER TABLE public."ALIMENTO" OWNER TO postgres;
-- ddl-end --

-- object: public."CLIENTE" | type: TABLE --
-- DROP TABLE IF EXISTS public."CLIENTE" CASCADE;
CREATE TABLE public."CLIENTE" (
	rfc_cliente varchar(13) NOT NULL,
	fecha_nacimiento_cliente date NOT NULL,
	calle_cliente varchar(50) NOT NULL,
	cp_cliente smallint NOT NULL,
	numero_cliente varchar(15) NOT NULL,
	colonia_cliente varchar(80) NOT NULL,
	estado_cliente varchar(25) NOT NULL,
	nombre_cliente varchar(50) NOT NULL,
	ap_pat_cliente varchar(25) NOT NULL,
	ap_mat_cliente varchar(25),
	razon_social varchar(200) NOT NULL,
	email varchar(80) NOT NULL,
	CONSTRAINT "CLIENTE_pk" PRIMARY KEY (rfc_cliente)

);
-- ddl-end --
-- ALTER TABLE public."CLIENTE" OWNER TO postgres;
-- ddl-end --

-- object: public."ORDEN" | type: TABLE --
-- DROP TABLE IF EXISTS public."ORDEN" CASCADE;
CREATE TABLE public."ORDEN" (
	folio_orden varchar(8) NOT NULL,
	fecha_orden date NOT NULL,
	pago_total money NOT NULL,
	"num_empleado_EMPLEADO" numeric NOT NULL,
	"rfc_cliente_CLIENTE" varchar(13) NOT NULL,
	CONSTRAINT "ORDEN_pk" PRIMARY KEY (folio_orden)

);
-- ddl-end --
-- ALTER TABLE public."ORDEN" OWNER TO postgres;
-- ddl-end --

-- object: public.telefono | type: TABLE --
-- DROP TABLE IF EXISTS public.telefono CASCADE;
CREATE TABLE public.telefono (
	telefono int4 NOT NULL,
	"num_empleado_EMPLEADO" numeric NOT NULL,
	CONSTRAINT contener_pk PRIMARY KEY (telefono)

);
-- ddl-end --
-- ALTER TABLE public.telefono OWNER TO postgres;
-- ddl-end --

-- object: "EMPLEADO_fk" | type: CONSTRAINT --
-- ALTER TABLE public."DEPENDIENTE" DROP CONSTRAINT IF EXISTS "EMPLEADO_fk" CASCADE;
ALTER TABLE public."DEPENDIENTE" ADD CONSTRAINT "EMPLEADO_fk" FOREIGN KEY ("num_empleado_EMPLEADO")
REFERENCES public."EMPLEADO" (num_empleado) MATCH FULL
ON DELETE RESTRICT ON UPDATE CASCADE;
-- ddl-end --

-- object: "EMPLEADO_fk" | type: CONSTRAINT --
-- ALTER TABLE public."ORDEN" DROP CONSTRAINT IF EXISTS "EMPLEADO_fk" CASCADE;
ALTER TABLE public."ORDEN" ADD CONSTRAINT "EMPLEADO_fk" FOREIGN KEY ("num_empleado_EMPLEADO")
REFERENCES public."EMPLEADO" (num_empleado) MATCH FULL
ON DELETE RESTRICT ON UPDATE CASCADE;
-- ddl-end --

-- object: public."many_ORDEN_has_many_ALIMENTO" | type: TABLE --
-- DROP TABLE IF EXISTS public."many_ORDEN_has_many_ALIMENTO" CASCADE;
CREATE TABLE public."many_ORDEN_has_many_ALIMENTO" (
	"folio_orden_ORDEN" varchar(8) NOT NULL,
	"id_alimento_ALIMENTO" varchar(10) NOT NULL,
	precio_art money NOT NULL,
	cant_art money NOT NULL,
	CONSTRAINT "many_ORDEN_has_many_ALIMENTO_pk" PRIMARY KEY ("folio_orden_ORDEN","id_alimento_ALIMENTO")

);
-- ddl-end --

-- object: "ORDEN_fk" | type: CONSTRAINT --
-- ALTER TABLE public."many_ORDEN_has_many_ALIMENTO" DROP CONSTRAINT IF EXISTS "ORDEN_fk" CASCADE;
ALTER TABLE public."many_ORDEN_has_many_ALIMENTO" ADD CONSTRAINT "ORDEN_fk" FOREIGN KEY ("folio_orden_ORDEN")
REFERENCES public."ORDEN" (folio_orden) MATCH FULL
ON DELETE RESTRICT ON UPDATE CASCADE;
-- ddl-end --

-- object: "ALIMENTO_fk" | type: CONSTRAINT --
-- ALTER TABLE public."many_ORDEN_has_many_ALIMENTO" DROP CONSTRAINT IF EXISTS "ALIMENTO_fk" CASCADE;
ALTER TABLE public."many_ORDEN_has_many_ALIMENTO" ADD CONSTRAINT "ALIMENTO_fk" FOREIGN KEY ("id_alimento_ALIMENTO")
REFERENCES public."ALIMENTO" (id_alimento) MATCH FULL
ON DELETE RESTRICT ON UPDATE CASCADE;
-- ddl-end --

-- object: "CLIENTE_fk" | type: CONSTRAINT --
-- ALTER TABLE public."ORDEN" DROP CONSTRAINT IF EXISTS "CLIENTE_fk" CASCADE;
ALTER TABLE public."ORDEN" ADD CONSTRAINT "CLIENTE_fk" FOREIGN KEY ("rfc_cliente_CLIENTE")
REFERENCES public."CLIENTE" (rfc_cliente) MATCH FULL
ON DELETE RESTRICT ON UPDATE CASCADE;
-- ddl-end --

-- object: "EMPLEADO_fk" | type: CONSTRAINT --
-- ALTER TABLE public.telefono DROP CONSTRAINT IF EXISTS "EMPLEADO_fk" CASCADE;
ALTER TABLE public.telefono ADD CONSTRAINT "EMPLEADO_fk" FOREIGN KEY ("num_empleado_EMPLEADO")
REFERENCES public."EMPLEADO" (num_empleado) MATCH FULL
ON DELETE RESTRICT ON UPDATE CASCADE;
-- ddl-end --


