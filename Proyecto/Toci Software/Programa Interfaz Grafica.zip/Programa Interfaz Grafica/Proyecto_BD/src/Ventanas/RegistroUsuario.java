
package Ventanas;

import Modelo.CifrarContraseña;
import Modelo.Email;
import Modelo.Estado;
import Modelo.SQLCliente;
import Modelo.SQLEmail;
import Modelo.SQLEstado;
import Modelo.Usuario;
import javax.swing.JOptionPane;

/**
 *
 * @author ianmarentes
 */
public class RegistroUsuario extends javax.swing.JFrame {

    public RegistroUsuario() {
        initComponents();
        setLocationRelativeTo(null);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        BLimpiar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        CajaRFC = new javax.swing.JTextField();
        CajaNombre = new javax.swing.JTextField();
        CajaAp = new javax.swing.JTextField();
        CajaCE = new javax.swing.JTextField();
        CajaMat = new javax.swing.JTextField();
        CajaCalle = new javax.swing.JTextField();
        CajaCol = new javax.swing.JTextField();
        CajaCp = new javax.swing.JTextField();
        CajaNum = new javax.swing.JTextField();
        CajaPass2 = new javax.swing.JPasswordField();
        CajaPass1 = new javax.swing.JPasswordField();
        BRegresar1 = new javax.swing.JButton();
        BIngresar = new javax.swing.JButton();
        CajaEstado = new javax.swing.JComboBox<>();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BLimpiar.setBackground(new java.awt.Color(255, 153, 0));
        BLimpiar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        BLimpiar.setText("Limpiar");
        BLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BLimpiarActionPerformed(evt);
            }
        });
        jPanel1.add(BLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 510, 140, -1));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("<html>Confirmar contraseña:</html>");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 450, 120, -1));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Ingrese los siguientes datos");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText(" RFC:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, -1, -1));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nombre:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Apellido paterno:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("<html>Correo electrónico:</html\n>");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, 120, -1));

        jLabel7.setBackground(new java.awt.Color(255, 153, 0));
        jLabel7.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Domicilio");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 250, 100, -1));

        jLabel8.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Número:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 340, 90, -1));

        jLabel9.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Estado:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 90, -1));

        jLabel10.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("<html>Código Postal:</html>");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 280, 80, -1));

        jLabel11.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Contraseña:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 420, 120, -1));

        jLabel12.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Colonia:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 90, -1));

        jLabel13.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Apellido materno:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 180, -1));

        jLabel14.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Calle:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, 60, -1));
        jPanel1.add(CajaRFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, 220, 30));
        jPanel1.add(CajaNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 90, 220, 30));
        jPanel1.add(CajaAp, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, 220, 30));
        jPanel1.add(CajaCE, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 220, 30));
        jPanel1.add(CajaMat, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 170, 220, 30));
        jPanel1.add(CajaCalle, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 380, 220, 30));
        jPanel1.add(CajaCol, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 340, 170, 30));
        jPanel1.add(CajaCp, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 290, 130, 30));
        jPanel1.add(CajaNum, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 340, 130, 30));
        jPanel1.add(CajaPass2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 470, 220, 30));
        jPanel1.add(CajaPass1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 420, 220, 30));

        BRegresar1.setBackground(new java.awt.Color(255, 153, 0));
        BRegresar1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BRegresar1.setForeground(new java.awt.Color(255, 255, 255));
        BRegresar1.setText("Regresar");
        BRegresar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BRegresar1ActionPerformed(evt);
            }
        });
        jPanel1.add(BRegresar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 10, -1, -1));

        BIngresar.setBackground(new java.awt.Color(255, 153, 0));
        BIngresar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BIngresar.setForeground(new java.awt.Color(255, 255, 255));
        BIngresar.setText("Registrarse");
        BIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BIngresarActionPerformed(evt);
            }
        });
        jPanel1.add(BIngresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 510, 140, -1));

        CajaEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un estado", "Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas", "Chihuahua", "Ciudad de México", "Coahuila de Zaragoza", "Colima", "Durango", "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "Estado de México", "Michoacán de Ocampo", "Morelos", "Nayarit", "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo", "San Luis Potosí", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas" }));
        jPanel1.add(CajaEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 290, 190, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imágenes/fondo_2.jpg"))); // NOI18N
        jPanel1.add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 550));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BLimpiarActionPerformed
        limpiarCajas();
    }//GEN-LAST:event_BLimpiarActionPerformed

    private void BRegresar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BRegresar1ActionPerformed
        login s1 =new login();
        s1.setVisible(true);
        this.setVisible(false); 
    }//GEN-LAST:event_BRegresar1ActionPerformed

    private void BIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BIngresarActionPerformed
        
        Usuario usuario = new Usuario();
        Estado estado = new Estado ();
        Email email = new Email ();
        
        SQLCliente sqlCliente = new SQLCliente ();
        SQLEstado sqlEstado = new SQLEstado();
        SQLEmail sqlEmail = new SQLEmail ();
        
        String contraseña = new String(CajaPass1.getPassword());
        String ConfirmarContraseña = new String(CajaPass2.getPassword());
        
        if (CajaRFC.getText().equals("") || CajaNombre.getText().equals("") || CajaAp.getText().equals("") || CajaMat.getText().equals("") || CajaCE.getText().equals("") || CajaEstado.getSelectedItem().toString().equals("Seleccione un estado") || CajaCp.getText().equals("") || CajaCol.getText().equals("") || CajaCalle.getText().equals("") || CajaNum.getText().equals("") || contraseña.equals("") || ConfirmarContraseña.equals("")){
            JOptionPane.showMessageDialog(null, "Ingrese todos los datos.");
        }else{
            if (contraseña.equals(ConfirmarContraseña)){
                String nuevaContraseña = CifrarContraseña.md5(contraseña);//Cifrado de contraseña
                
                estado.setCodigo_postal(Integer.parseInt(CajaCp.getText()));
                estado.setEstado(CajaEstado.getSelectedItem().toString());
                
                usuario.setRfc(CajaRFC.getText());
                usuario.setNombre_pila(CajaNombre.getText());
                usuario.setApellido_paterno(CajaAp.getText());
                usuario.setApellido_materno(CajaMat.getText());
                usuario.setCalle(CajaCalle.getText());
                usuario.setNumero(Integer.parseInt(CajaNum.getText()));
                usuario.setColonia(CajaCol.getText());
                usuario.setCodigo_postal(Integer.parseInt(CajaCp.getText()));
                usuario.setPassword(nuevaContraseña);
                
                email.setEmail(CajaCE.getText());
                email.setRfc(CajaRFC.getText());
                
                if (sqlEstado.registrar(estado)){
                    if (sqlCliente.registrar(usuario)){
                        if (sqlEmail.registrar(email)){
                            JOptionPane.showMessageDialog(null, "Se registraron correctamente sus datos!!!");
                            String rfcUsuario = usuario.getRfc();
                            Inicio s1 = new Inicio();
                            
                            s1.setVisible(true);
                            this.dispose();
                            
                        }else{
                            JOptionPane.showMessageDialog(null, "Hubo un error al registrar su correo.");
                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Hubo un error al registrar sus datos personales.");
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Hubo un error al registrar su domicilio.");
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden");
            }
        }
        
    }//GEN-LAST:event_BIngresarActionPerformed

    public void limpiarCajas(){
        CajaRFC.setText(null);
        CajaAp.setText(null);
        CajaCalle.setText(null);
        CajaNum.setText(null);
        CajaCol.setText(null);
        CajaCp.setText(null);
        CajaCE.setText(null);
        CajaNombre.setText(null);
        CajaPass1.setText(null);
        CajaPass2.setText(null);
        CajaEstado.setSelectedIndex(0);
    }
    
    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BIngresar;
    private javax.swing.JButton BLimpiar;
    private javax.swing.JButton BRegresar1;
    private javax.swing.JTextField CajaAp;
    private javax.swing.JTextField CajaCE;
    private javax.swing.JTextField CajaCalle;
    private javax.swing.JTextField CajaCol;
    private javax.swing.JTextField CajaCp;
    private javax.swing.JComboBox<String> CajaEstado;
    private javax.swing.JTextField CajaMat;
    private javax.swing.JTextField CajaNombre;
    private javax.swing.JTextField CajaNum;
    private javax.swing.JPasswordField CajaPass1;
    private javax.swing.JPasswordField CajaPass2;
    private javax.swing.JTextField CajaRFC;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
