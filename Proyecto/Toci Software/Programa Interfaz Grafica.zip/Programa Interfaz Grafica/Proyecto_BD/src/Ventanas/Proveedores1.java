package Ventanas;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author ianmarentes
 */
public class Proveedores1 extends javax.swing.JFrame {

    public static final String URL = "jdbc:postgresql://localhost:5432/proyecto1";
    public static final String usuario = "postgres";
    public static final String contraseña = "1033255";
    PreparedStatement ps, ps1, ps2;
    ResultSet rs, rs1, rs2;
    
    public Proveedores1() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        BRegresar = new javax.swing.JButton();
        BLimpiar = new javax.swing.JButton();
        BBuscar1 = new javax.swing.JButton();
        BInsertar = new javax.swing.JButton();
        BMod = new javax.swing.JButton();
        Beliminar = new javax.swing.JButton();
        EtiquetaUsuario = new javax.swing.JLabel();
        cajaCP = new javax.swing.JTextField();
        EtiquetaUsuario1 = new javax.swing.JLabel();
        EtiquetaUsuario2 = new javax.swing.JLabel();
        EtiquetaUsuario3 = new javax.swing.JLabel();
        EtiquetaUsuario4 = new javax.swing.JLabel();
        EtiquetaUsuario5 = new javax.swing.JLabel();
        EtiquetaUsuario6 = new javax.swing.JLabel();
        EtiquetaUsuario7 = new javax.swing.JLabel();
        EtiquetaUsuario8 = new javax.swing.JLabel();
        cajaBuscar = new javax.swing.JTextField();
        cajaRS = new javax.swing.JTextField();
        cajaTel = new javax.swing.JTextField();
        cajaNombre = new javax.swing.JTextField();
        cajaCalle = new javax.swing.JTextField();
        cajaNumero = new javax.swing.JTextField();
        cajaColonia = new javax.swing.JTextField();
        cajaEstado = new javax.swing.JComboBox<>();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BRegresar.setBackground(new java.awt.Color(255, 153, 0));
        BRegresar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BRegresar.setForeground(new java.awt.Color(255, 255, 255));
        BRegresar.setText("Regresar");
        BRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(BRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 10, -1, -1));

        BLimpiar.setBackground(new java.awt.Color(255, 153, 0));
        BLimpiar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        BLimpiar.setText("Limpiar");
        BLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BLimpiarActionPerformed(evt);
            }
        });
        jPanel1.add(BLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 540, -1, -1));

        BBuscar1.setBackground(new java.awt.Color(255, 153, 0));
        BBuscar1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BBuscar1.setForeground(new java.awt.Color(255, 255, 255));
        BBuscar1.setText("Buscar");
        BBuscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BBuscar1ActionPerformed(evt);
            }
        });
        jPanel1.add(BBuscar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 70, 100, -1));

        BInsertar.setBackground(new java.awt.Color(255, 153, 0));
        BInsertar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BInsertar.setForeground(new java.awt.Color(255, 255, 255));
        BInsertar.setText("Insertar");
        BInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BInsertarActionPerformed(evt);
            }
        });
        jPanel1.add(BInsertar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 540, -1, -1));

        BMod.setBackground(new java.awt.Color(255, 153, 0));
        BMod.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BMod.setForeground(new java.awt.Color(255, 255, 255));
        BMod.setText("Modificar");
        BMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BModActionPerformed(evt);
            }
        });
        jPanel1.add(BMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 540, -1, -1));

        Beliminar.setBackground(new java.awt.Color(255, 153, 0));
        Beliminar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Beliminar.setForeground(new java.awt.Color(255, 255, 255));
        Beliminar.setText("Eliminar");
        Beliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BeliminarActionPerformed(evt);
            }
        });
        jPanel1.add(Beliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 540, -1, -1));

        EtiquetaUsuario.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        EtiquetaUsuario.setForeground(new java.awt.Color(255, 255, 255));
        EtiquetaUsuario.setText("C.P. :");
        jPanel1.add(EtiquetaUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 470, 60, -1));

        cajaCP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaCPActionPerformed(evt);
            }
        });
        jPanel1.add(cajaCP, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 470, 120, 30));

        EtiquetaUsuario1.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        EtiquetaUsuario1.setForeground(new java.awt.Color(255, 255, 255));
        EtiquetaUsuario1.setText("Razón social");
        jPanel1.add(EtiquetaUsuario1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, 130, -1));

        EtiquetaUsuario2.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        EtiquetaUsuario2.setForeground(new java.awt.Color(255, 255, 255));
        EtiquetaUsuario2.setText("Teléfono:");
        jPanel1.add(EtiquetaUsuario2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, 90, -1));

        EtiquetaUsuario3.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        EtiquetaUsuario3.setForeground(new java.awt.Color(255, 255, 255));
        EtiquetaUsuario3.setText("Nombre:");
        jPanel1.add(EtiquetaUsuario3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 90, -1));

        EtiquetaUsuario4.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        EtiquetaUsuario4.setForeground(new java.awt.Color(255, 255, 255));
        EtiquetaUsuario4.setText("Domicilio");
        jPanel1.add(EtiquetaUsuario4, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 280, 100, -1));

        EtiquetaUsuario5.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        EtiquetaUsuario5.setForeground(new java.awt.Color(255, 255, 255));
        EtiquetaUsuario5.setText("Calle:");
        jPanel1.add(EtiquetaUsuario5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, 60, -1));

        EtiquetaUsuario6.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        EtiquetaUsuario6.setForeground(new java.awt.Color(255, 255, 255));
        EtiquetaUsuario6.setText("Número:");
        jPanel1.add(EtiquetaUsuario6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 360, 90, -1));

        EtiquetaUsuario7.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        EtiquetaUsuario7.setForeground(new java.awt.Color(255, 255, 255));
        EtiquetaUsuario7.setText("Colonia:");
        jPanel1.add(EtiquetaUsuario7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 400, 80, -1));

        EtiquetaUsuario8.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        EtiquetaUsuario8.setForeground(new java.awt.Color(255, 255, 255));
        EtiquetaUsuario8.setText("Estado:");
        jPanel1.add(EtiquetaUsuario8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 80, -1));

        cajaBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaBuscarActionPerformed(evt);
            }
        });
        jPanel1.add(cajaBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 220, 30));

        cajaRS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaRSActionPerformed(evt);
            }
        });
        jPanel1.add(cajaRS, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, 220, 30));

        cajaTel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaTelActionPerformed(evt);
            }
        });
        jPanel1.add(cajaTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 220, 30));

        cajaNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaNombreActionPerformed(evt);
            }
        });
        jPanel1.add(cajaNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 220, 30));

        cajaCalle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaCalleActionPerformed(evt);
            }
        });
        jPanel1.add(cajaCalle, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 310, 220, 30));

        cajaNumero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaNumeroActionPerformed(evt);
            }
        });
        jPanel1.add(cajaNumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 360, 220, 30));

        cajaColonia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaColoniaActionPerformed(evt);
            }
        });
        jPanel1.add(cajaColonia, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 400, 220, 30));

        cajaEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un estado", "Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas", "Chihuahua", "Ciudad de México", "Coahuila de Zaragoza", "Colima", "Durango", "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "Estado de México", "Michoacán de Ocampo", "Morelos", "Nayarit", "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo", "San Luis Potosí", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas" }));
        jPanel1.add(cajaEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 470, 190, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imágenes/fondo_3.JPG"))); // NOI18N
        jPanel1.add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 600));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BRegresarActionPerformed
        Inicio2 s1 =new Inicio2();
        s1.setVisible(true);
        this.setVisible(false); 
    }//GEN-LAST:event_BRegresarActionPerformed

    private void BLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BLimpiarActionPerformed
        // TODO add your handling code here:
        limpiarCajas();
    }//GEN-LAST:event_BLimpiarActionPerformed

    private void cajaCPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaCPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaCPActionPerformed

    private void cajaBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaBuscarActionPerformed

    private void cajaRSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaRSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaRSActionPerformed

    private void cajaTelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaTelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaTelActionPerformed

    private void cajaNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaNombreActionPerformed

    private void cajaCalleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaCalleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaCalleActionPerformed

    private void cajaNumeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaNumeroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaNumeroActionPerformed

    private void cajaColoniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaColoniaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaColoniaActionPerformed

    private void BBuscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BBuscar1ActionPerformed
        // TODO add your handling code here:
        Connection conexion = null;
        Connection conexion1 = null;
        Connection conexion2 = null;
        
        try {
            conexion = getConnection();
            
            ps = conexion.prepareStatement(
                    "SELECT P.razon_social, P.nombre, P.calle, P.numero, P.colonia, P.codigo_postal, E.estado FROM proveedor AS P, estado AS E where P.nombre=?"
            );
            ps.setString(1, cajaBuscar.getText());
            rs = ps.executeQuery(); //Se obtiene la información de la BD.
            
            if (rs.next()){ //Si se obtiene la información de la consulta, regresa un TRUE
                
                cajaRS.setText(rs.getString("razon_social"));
                cajaNombre.setText(rs.getString("nombre"));
                cajaCalle.setText(rs.getString("calle"));
                cajaNumero.setText(String.valueOf(rs.getInt("numero")));
                cajaColonia.setText(rs.getString("colonia"));
                cajaCP.setText(String.valueOf(rs.getInt("codigo_postal")));
                
            }else{
                JOptionPane.showMessageDialog(null, "No existe un proveedor con ese nombre.");
            }
            conexion.close();
        }catch (Exception ex){
            System.err.println ("Error: " + ex);
        }
        
        try{
            conexion1 = getConnection();
            int campo = Integer.valueOf(cajaCP.getText());
            
            conexion1 = getConnection();
            ps1 = conexion1.prepareStatement("SELECT estado FROM estado where codigo_postal = " + campo);
            rs1 = ps1.executeQuery();
            
            if (rs1.next()){
                cajaEstado.setSelectedItem(rs1.getString("estado"));
            }else{
                JOptionPane.showMessageDialog(null, "No existe un estado con ese Código Postal.");
            }
            conexion1.close();
        }catch (Exception e){
        System.err.println("Error: " + e);
    }
        try{
            conexion2 = getConnection();
            String campo = cajaRS.getText();
            String where = "where razon_social = '" + campo + "'";
            
            ps2 = conexion2.prepareStatement("SELECT telefono FROM telefonoprov " + where);
            rs2 = ps2.executeQuery();
            
            if (rs2.next()){
                cajaTel.setText(rs2.getString("telefono"));
                
            }else{
                //JOptionPane.showMessageDialog(null, "No se cuenta con el teléfono del proveedor.");
            }
            
            
            conexion2.close();
        }catch (Exception e){
        System.err.println("Error: " + e);
    }
             
    }//GEN-LAST:event_BBuscar1ActionPerformed

    private void BInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BInsertarActionPerformed
        
        Connection conexion = null;
        Connection conexion1 = null;
        Connection conexion2 = null;
      
        try{
            conexion1 = getConnection();
            ps1 = conexion1.prepareStatement("INSERT INTO estado (codigo_postal, estado) values (?, ?)");
            ps1.setInt(1, Integer.parseInt(cajaCP.getText()));
            ps1.setString(2, cajaEstado.getSelectedItem().toString());
            int res = ps1.executeUpdate(); //Se realiza la inserción en la BD

            conexion1.close();
        }catch (Exception e){
        System.err.println("Error: " + e);
        }
        
        try{
            conexion = getConnection();
            ps = conexion.prepareStatement("insert into proveedor (razon_social, nombre, calle, numero, colonia, codigo_postal) values (?,?,?,?,?,?)");
            ps.setString(1, cajaRS.getText());
            ps.setString(2, cajaNombre.getText());
            ps.setString(3, cajaCalle.getText());
            ps.setInt(4, Integer.parseInt(cajaNumero.getText()));
            ps.setString(5, cajaColonia.getText());
            ps.setInt(6, Integer.parseInt(cajaCP.getText()));
            int res = ps.executeUpdate(); //Se realiza la inserción en la BD
            
            conexion.close();
            
        }catch (Exception ex){
            System.err.println("Error, "+ ex);
        }
        
        try{
            
            conexion2 = getConnection();
            ps2 = conexion2.prepareStatement("INSERT INTO telefonoprov (telefono, razon_social) values (?, ?)");
            ps2.setString(1, cajaTel.getText());
            ps2.setString(2, cajaRS.getText());
            int res = ps2.executeUpdate(); //Se realiza la inserción en la BD
            if (res > 0){
                JOptionPane.showMessageDialog(null, "Se ingresaron los datos correctamente!!!");
               
            }else{
                JOptionPane.showMessageDialog(null, "Hubo un error al ingresar los datos");
            }
            
            
            conexion2.close();
        }catch (Exception e){
        System.err.println("Error: " + e);
    }
           
    }//GEN-LAST:event_BInsertarActionPerformed

    private void BModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BModActionPerformed
        
        Connection conexion = null;
        Connection conexion1 = null;
        Connection conexion2 = null;
      
        try{
            //Actualización de los datos de la tabla estado
            /*
            Se puede cambiar la PK únicamente si ya existe, es decir, cambiar de un código postal
            a otro código postal ya existente.
            */
            int campo = Integer.valueOf(cajaCP.getText());
            conexion1 = getConnection();
            ps1 = conexion1.prepareStatement("update estado set codigo_postal = ?, estado = ? where codigo_postal = " + campo);
            ps1.setInt(1, Integer.parseInt(cajaCP.getText()));
            ps1.setString(2, cajaEstado.getSelectedItem().toString());
            int res = ps1.executeUpdate(); //Se realiza la inserción en la BD
            if (res > 0){
                //JOptionPane.showMessageDialog(null, "Se modificó el domicilio correctamente!");
                
            }else{
                JOptionPane.showMessageDialog(null, "Hubo un error al cambiar los datos.");
                
            }
            conexion1.close();
        }catch (Exception e){
            System.err.println("Error: " + e);
        }
        
        
        try{
            conexion = getConnection();
            String campo1 = cajaRS.getText();
            ps = conexion.prepareStatement("update proveedor set razon_social=?, nombre=?, calle=?, numero=?, colonia=?, codigo_postal=? where razon_social = '" + campo1 + "'");
            ps.setString(1, cajaRS.getText());
            ps.setString(2, cajaNombre.getText());
            ps.setString(3, cajaCalle.getText());
            ps.setInt(4, Integer.parseInt(cajaNumero.getText()));
            ps.setString(5, cajaColonia.getText());
            ps.setInt(6, Integer.parseInt(cajaCP.getText()));
            int res = ps.executeUpdate(); //Se realiza la inserción en la BD
            
            if (res > 0){
                JOptionPane.showMessageDialog(null, "Se modifcaron los datos correctamente!!!");
                
            }else{
                JOptionPane.showMessageDialog(null, "Hubo un error al cambiar los datos.");
                
            }
            conexion.close();
            
        }catch (Exception ex){
            System.err.println("Error, "+ ex);
        }
        
      
    }//GEN-LAST:event_BModActionPerformed

    private void BeliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BeliminarActionPerformed
        //Eliminación de registros de la tabla
       Connection conexion = null;
       
       try{
            conexion = getConnection();
            ps = conexion.prepareStatement("DELETE FROM proveedor WHERE nombre = ?");
            ps.setString(1, cajaNombre.getText());
            int res = ps.executeUpdate(); //Se elimina el registro de la BD
            
            if (res > 0){
                JOptionPane.showMessageDialog(null, "Se eliminó la información correctamente!!!");
                
            }else{
                JOptionPane.showMessageDialog(null, "Hubo un error al eliminar los datos.");
                
            }
            conexion.close();
       }catch (Exception ex){
           System.err.println("Error: " + ex);
       }
    }//GEN-LAST:event_BeliminarActionPerformed

    public Connection getConnection(){
        Connection Conexion = null;
        
        try{
            
            Conexion = DriverManager.getConnection (URL, usuario, contraseña);
            //Conexion = (Connection) DriverManager.getConnection(URL, usuario, contraseña);
            //JOptionPane.showMessageDialog(null, "Conexión exitosa a la base de datos.");
        }catch(Exception ex){
            System.err.println("Error: " + ex);
        }
        return Conexion;
    }
    
    public void limpiarCajas (){
        cajaBuscar.setText (null);
        cajaRS.setText (null);
        cajaTel.setText (null);
        cajaCalle.setText (null);
        cajaNombre.setText (null);
        cajaNumero.setText (null);
        cajaColonia.setText (null);
        cajaEstado.setSelectedIndex(0);
        cajaCP.setText (null);
        
    }
    
    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Proveedores1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BBuscar1;
    private javax.swing.JButton BInsertar;
    private javax.swing.JButton BLimpiar;
    private javax.swing.JButton BMod;
    private javax.swing.JButton BRegresar;
    private javax.swing.JButton Beliminar;
    private javax.swing.JLabel EtiquetaUsuario;
    private javax.swing.JLabel EtiquetaUsuario1;
    private javax.swing.JLabel EtiquetaUsuario2;
    private javax.swing.JLabel EtiquetaUsuario3;
    private javax.swing.JLabel EtiquetaUsuario4;
    private javax.swing.JLabel EtiquetaUsuario5;
    private javax.swing.JLabel EtiquetaUsuario6;
    private javax.swing.JLabel EtiquetaUsuario7;
    private javax.swing.JLabel EtiquetaUsuario8;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField cajaBuscar;
    private javax.swing.JTextField cajaCP;
    private javax.swing.JTextField cajaCalle;
    private javax.swing.JTextField cajaColonia;
    private javax.swing.JComboBox<String> cajaEstado;
    private javax.swing.JTextField cajaNombre;
    private javax.swing.JTextField cajaNumero;
    private javax.swing.JTextField cajaRS;
    private javax.swing.JTextField cajaTel;
    private javax.swing.JLabel fondo;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
