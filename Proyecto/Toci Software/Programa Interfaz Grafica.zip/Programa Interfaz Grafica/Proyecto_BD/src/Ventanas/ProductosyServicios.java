
package Ventanas;

import Modelo.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.naming.spi.DirStateFactory.Result;
import javax.swing.table.DefaultTableModel;
import Modelo.SQLCliente;
import Modelo.Usuario;
/**
 *
 * @author ianmarentes
 */
public class ProductosyServicios extends javax.swing.JFrame {

    public ProductosyServicios() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        BBuscarE = new javax.swing.JButton();
        BComprar = new javax.swing.JButton();
        BRegresar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaProductos = new javax.swing.JTable();
        Opciones = new javax.swing.JComboBox<>();
        CajaBuscar = new javax.swing.JTextField();
        CajaNombre = new javax.swing.JTextField();
        CajaMarca = new javax.swing.JTextField();
        CajaPrecio = new javax.swing.JTextField();
        jTextField1 = new javax.swing.JTextField();
        CajaCant = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        BCarrito = new javax.swing.JButton();
        BLimpiar = new javax.swing.JButton();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BBuscarE.setBackground(new java.awt.Color(255, 153, 0));
        BBuscarE.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BBuscarE.setForeground(new java.awt.Color(255, 255, 255));
        BBuscarE.setText("Mostrar productos");
        BBuscarE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BBuscarEActionPerformed(evt);
            }
        });
        jPanel1.add(BBuscarE, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 90, -1, -1));

        BComprar.setBackground(new java.awt.Color(255, 153, 0));
        BComprar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BComprar.setForeground(new java.awt.Color(255, 255, 255));
        BComprar.setText("Finalizar compra");
        BComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BComprarActionPerformed(evt);
            }
        });
        jPanel1.add(BComprar, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 440, -1, -1));

        BRegresar.setBackground(new java.awt.Color(255, 153, 0));
        BRegresar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BRegresar.setForeground(new java.awt.Color(255, 255, 255));
        BRegresar.setText("Regresar");
        BRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(BRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 10, -1, -1));

        TablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Precio", "En stock", "Marca", "Código"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TablaProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaProductosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaProductos);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 610, 170));

        Opciones.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "codigo_barras", "descripcion", "precio_unidad", "marca" }));
        jPanel1.add(Opciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 130, -1));

        CajaBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaBuscarActionPerformed(evt);
            }
        });
        jPanel1.add(CajaBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 380, 30));
        jPanel1.add(CajaNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 320, 180, 30));
        jPanel1.add(CajaMarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 360, 180, 30));
        jPanel1.add(CajaPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 180, 30));

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 480, 180, 30));

        CajaCant.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "1", "2", "3", "4", "5" }));
        jPanel1.add(CajaCant, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 440, 190, -1));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cantidad: ");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 440, -1, -1));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("<html>Total a pagar:</html>");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 470, 100, -1));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Marca:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Precio:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, -1, -1));

        BCarrito.setBackground(new java.awt.Color(255, 153, 0));
        BCarrito.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BCarrito.setForeground(new java.awt.Color(255, 255, 255));
        BCarrito.setText("Añadir al carrito");
        BCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BCarritoActionPerformed(evt);
            }
        });
        jPanel1.add(BCarrito, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 440, -1, -1));

        BLimpiar.setBackground(new java.awt.Color(255, 153, 0));
        BLimpiar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        BLimpiar.setText("Limpiar");
        BLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BLimpiarActionPerformed(evt);
            }
        });
        jPanel1.add(BLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 490, 110, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imágenes/Fondobueno.jpeg"))); // NOI18N
        jPanel1.add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 630, 550));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BRegresarActionPerformed
        
        
    }//GEN-LAST:event_BRegresarActionPerformed

    private void BComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BComprarActionPerformed
        
        
    }//GEN-LAST:event_BComprarActionPerformed

    private void CajaBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaBuscarActionPerformed

    private void BBuscarEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BBuscarEActionPerformed
        // TODO add your handling code here:
                
        DefaultTableModel modeloTabla = new DefaultTableModel();
        TablaProductos.setModel(modeloTabla);
        String campo = CajaBuscar.getText();
        String where = "";
        String opc = Opciones.getSelectedItem().toString();
        
        if (!"Seleccionar".equals(opc)){ //Si el usuario seleccionó una opción de búsqueda
            if (!"".equals(campo)){ //y el campo de búsqueda no está vacío ...
                where = "where " + opc + " = '" + campo + "'";
            }
        }
        
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try{
            Conexion con = new Conexion();
            Connection conexion = con.getConnection();
            
            ps = conexion.prepareStatement("SELECT P.descripcion, P.precio_unidad, P.stock, P.marca, P.codigo_barras FROM producto AS P " + where);
            rs = ps.executeQuery();
            
            modeloTabla.addColumn("Nombre");
            modeloTabla.addColumn("Precio");
            modeloTabla.addColumn("En stock");
            modeloTabla.addColumn("Marca");
            modeloTabla.addColumn("Código");
            
            ResultSetMetaData  rsMD = rs.getMetaData();
            int cantidadColumns = rsMD.getColumnCount(); //Se realiza el conteo del número de columnas en la tabla
            int anchos[] = {220, 50, 30, 80, 50};
            
            for (int  i = 0; i < cantidadColumns ; i ++){
                TablaProductos.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]); //Se definen los anchos de las columnas
            }
            
            while (rs.next()){
                Object fila [] = new Object [cantidadColumns];
                for ( int i = 0; i < cantidadColumns; i++){
                    fila[i] = rs.getObject(i + 1);
                }
                
                modeloTabla.addRow(fila);
            }
            
        }catch (Exception ex){
            System.err.println("Error: " + ex);
        }
        
        
    }//GEN-LAST:event_BBuscarEActionPerformed

    private void TablaProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaProductosMouseClicked
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try{
            Conexion con = new Conexion();
            Connection conexion = con.getConnection();
            
            int fila = TablaProductos.getSelectedRow(); //Se obtiene la fila seleciconada
            String nombreP = TablaProductos.getValueAt(fila, 0).toString();
            
            ps = conexion.prepareStatement("SELECT descripcion, precio_unidad, marca FROM producto where descripcion = ? ");
            ps.setString(1, nombreP);
            rs=ps.executeQuery();
            
            while (rs.next()){
                CajaNombre.setText(rs.getString("descripcion"));
                CajaPrecio.setText(String.valueOf(rs.getDouble("precio_unidad")));
                CajaMarca.setText(rs.getString("marca"));
                
            }
            
        }catch (Exception ex){
            System.err.println("Error: " + ex);
        }
    }//GEN-LAST:event_TablaProductosMouseClicked

    private void BLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BLimpiarActionPerformed
        // TODO add your handling code here:
        limpiarCajas();
    }//GEN-LAST:event_BLimpiarActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void BCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BCarritoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BCarritoActionPerformed
    
    public void limpiarCajas(){
        CajaNombre.setText(null);
        CajaPrecio.setText(null);
        CajaMarca.setText(null);
        CajaCant.setSelectedIndex(0);
        
    }

    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProductosyServicios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BBuscarE;
    private javax.swing.JButton BCarrito;
    private javax.swing.JButton BComprar;
    private javax.swing.JButton BLimpiar;
    private javax.swing.JButton BRegresar;
    private javax.swing.JTextField CajaBuscar;
    private javax.swing.JComboBox<String> CajaCant;
    private javax.swing.JTextField CajaMarca;
    private javax.swing.JTextField CajaNombre;
    private javax.swing.JTextField CajaPrecio;
    private javax.swing.JComboBox<String> Opciones;
    private javax.swing.JTable TablaProductos;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
