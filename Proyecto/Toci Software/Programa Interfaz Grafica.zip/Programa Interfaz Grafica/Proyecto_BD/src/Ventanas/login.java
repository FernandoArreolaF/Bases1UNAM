package Ventanas;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;




public class login extends javax.swing.JFrame {
    public static final String URL = "jdbc:postgresql://localhost:5432/proyecto1";
    public static final String usuario = "postgres";
    public static final String contraseña = "1033255";
            
    public login() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Panel = new javax.swing.JPanel();
        BSalir = new javax.swing.JButton();
        BIniciarS = new javax.swing.JButton();
        BNuevoU = new javax.swing.JButton();
        Fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BSalir.setBackground(new java.awt.Color(255, 153, 0));
        BSalir.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BSalir.setForeground(new java.awt.Color(255, 255, 255));
        BSalir.setText("Salir ");
        BSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BSalirActionPerformed(evt);
            }
        });
        Panel.add(BSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, -1, -1));

        BIniciarS.setBackground(new java.awt.Color(255, 153, 0));
        BIniciarS.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BIniciarS.setForeground(new java.awt.Color(255, 255, 255));
        BIniciarS.setText("Iniciar sesión\n");
        BIniciarS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BIniciarSActionPerformed(evt);
            }
        });
        Panel.add(BIniciarS, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 420, 130, 30));

        BNuevoU.setBackground(new java.awt.Color(255, 153, 0));
        BNuevoU.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BNuevoU.setForeground(new java.awt.Color(255, 255, 255));
        BNuevoU.setText("Nuevo usuario");
        BNuevoU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BNuevoUActionPerformed(evt);
            }
        });
        Panel.add(BNuevoU, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 420, 130, 30));

        Fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imágenes/Fondo_1.jpg"))); // NOI18N
        Panel.add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSalirActionPerformed
        System.exit(0);
        
    }//GEN-LAST:event_BSalirActionPerformed

    private void BIniciarSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BIniciarSActionPerformed
        Connection conexion = getConnection();
        
        Login1 s1 =new Login1();
        s1.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BIniciarSActionPerformed

    private void BNuevoUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BNuevoUActionPerformed
        
        RegistroUsuario s1 =new RegistroUsuario();
        s1.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BNuevoUActionPerformed
    
    public Connection getConnection(){
        Connection Conexion = null;
        
        try{
            
            Conexion = DriverManager.getConnection (URL, usuario, contraseña);
            //Conexion = (Connection) DriverManager.getConnection(URL, usuario, contraseña);
            JOptionPane.showMessageDialog(null, "Conexión exitosa a la base de datos.");
        }catch(Exception ex){
            System.err.println("Error: " + ex);
        }
        return Conexion;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BIniciarS;
    private javax.swing.JButton BNuevoU;
    private javax.swing.JButton BSalir;
    private javax.swing.JLabel Fondo;
    private javax.swing.JPanel Panel;
    // End of variables declaration//GEN-END:variables
}
