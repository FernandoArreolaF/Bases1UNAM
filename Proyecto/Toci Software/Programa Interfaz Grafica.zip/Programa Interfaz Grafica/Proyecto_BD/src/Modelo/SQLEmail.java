
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author ianmarentes
 */
public class SQLEmail {
    
    public boolean registrar(Email email){
        Conexion con = new Conexion();
        PreparedStatement ps = null;
        
        try{
            
            Connection conexion = con.getConnection();
            ps = conexion.prepareStatement("INSERT INTO emailcliente (email, rfc) values (?, ?)");
            ps.setString(1, email.getEmail());
            ps.setString(2, email.getRfc());
            ps.executeUpdate(); //Se realiza la inserción en la BD
            
            return true;
            
            
        }catch (Exception ex){
            System.err.println("Error en " + ex);
            return false;
        }
        
    }
    
}
