package Modelo;

/**
 *
 * @author ianmarentes
 */
public class Usuario {
    private String rfc;
    private String nombre_pila;
    private String ap_paterno;
    private String ap_materno;
    private String calle;
    private int numero;
    private String colonia;
    private int codigo_postal;
    private String passwd;

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getNombre_pila() {
        return nombre_pila;
    }

    public void setNombre_pila(String nombre_pila) {
        this.nombre_pila = nombre_pila;
    }

    public String getApellido_paterno() {
        return ap_paterno;
    }

    public void setApellido_paterno(String apellido_paterno) {
        this.ap_paterno = apellido_paterno;
    }

    public String getApellido_materno() {
        return ap_materno;
    }

    public void setApellido_materno(String apellido_materno) {
        this.ap_materno = apellido_materno;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public int getCodigo_postal() {
        return codigo_postal;
    }

    public void setCodigo_postal(int codigo_postal) {
        this.codigo_postal = codigo_postal;
    }

    public String getPassword() {
        return passwd;
    }

    public void setPassword(String password) {
        this.passwd = password;
    }
    
    
    
}
