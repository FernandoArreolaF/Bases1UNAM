
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author ianmarentes
 */
public class SQLEstado {
    
    public boolean registrar(Estado estado){
        Conexion con = new Conexion();
        PreparedStatement ps = null;
        
        try{
            
            Connection conexion = con.getConnection();
            ps = conexion.prepareStatement("INSERT INTO estado (codigo_postal, estado) values (?, ?)");
            ps.setInt(1, estado.getCodigo_postal());
            ps.setString(2, estado.getEstado());
            ps.executeUpdate(); //Se realiza la inserción en la BD
            
            return true;
            
        }catch (Exception ex){
            System.err.println("Error en " + ex);
            return false;
        }
        
    }
    
}
