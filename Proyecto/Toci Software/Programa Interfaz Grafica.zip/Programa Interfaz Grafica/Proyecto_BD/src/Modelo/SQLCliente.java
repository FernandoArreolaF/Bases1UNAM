package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author ianmarentes
 */
public class SQLCliente {
    
    public boolean registrar(Usuario usuario){
        Conexion con = new Conexion();
        PreparedStatement ps = null;
        
        
        try{
            
            Connection conexion = con.getConnection();
            ps = conexion.prepareStatement("insert into cliente (rfc, nombre_pila, ap_paterno, ap_materno, calle, numero, colonia, codigo_postal, passwd) values (?,?,?,?,?,?,?,?,?)");
            ps.setString(1, usuario.getRfc());
            ps.setString(2, usuario.getNombre_pila());
            ps.setString(3, usuario.getApellido_paterno());
            ps.setString(4, usuario.getApellido_materno());
            ps.setString(5, usuario.getCalle());
            ps.setInt(6, usuario.getNumero());
            ps.setString(7, usuario.getColonia());
            ps.setInt(8, usuario.getCodigo_postal());
            ps.setString(9, usuario.getPassword());
            ps.executeUpdate(); //Se realiza la inserción en la BD
            
            return true;
            
            
        }catch (Exception ex){
            System.err.println("Error en " + ex);
            return false;
        }
        
    }
    //Función que se encarga de validar si existe ya un usuario
    public int verificarUsuario(String usuario){
        Conexion con = new Conexion();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try{
            
            Connection conexion = con.getConnection();
            ps = conexion.prepareStatement("select count (rfc) from cliente where nombre_pila=?");
            ps.setString(1, usuario);
            rs = ps.executeQuery(); //Se realiza la inserción en la BD
            
            if (rs.next()){
                return rs.getInt(1);
            }
            return 1;
            
        }catch (Exception ex){
            System.err.println("Error en " + ex);
            return 1;
        }
        
    }
    
    public boolean iniciarSesion(Usuario usuario){
        Conexion con = new Conexion();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            Connection conexion = con.getConnection();
            ps = conexion.prepareStatement("select rfc, nombre_pila, passwd from cliente where nombre_pila = ?");
            ps.setString(1, usuario.getNombre_pila());
            rs = ps.executeQuery(); //Se realiza la inserción en la BD
            
            if (rs.next()){
                if (usuario.getPassword().equals(rs.getString("passwd"))){
                    usuario.setRfc(rs.getString("rfc"));
                    usuario.setNombre_pila(rs.getString("nombre_pila"));
                    return true;
                }else{
                    return false;
                }
            }
            return false;
        }catch (Exception ex){
            System.err.println("Error en: " + ex);
            return false;
        }
        
    }
    
    
    
}
