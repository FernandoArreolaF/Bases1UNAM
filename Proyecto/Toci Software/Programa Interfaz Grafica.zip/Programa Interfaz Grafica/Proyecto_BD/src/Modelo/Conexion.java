
package Modelo;

/**
 *
 * @author ianmarentes
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Conexion {
    
    public static final String URL = "jdbc:postgresql://localhost:5432/proyecto1";
    public static final String usuario = "postgres";
    public static final String contraseña = "1033255";
    
    public Connection getConnection(){
        
        Connection Conexion = null;
        
        try{
            
            Conexion = DriverManager.getConnection (URL, usuario, contraseña);
            //Conexion = (Connection) DriverManager.getConnection(URL, usuario, contraseña);
            //JOptionPane.showMessageDialog(null, "Conexión exitosa a la base de datos.");
        }catch(Exception ex){
            System.err.println("Error: " + ex);
        }
        return Conexion;
    }
}
